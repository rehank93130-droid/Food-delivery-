/**
 * QuickBite - Food Delivery App
 * Main Hono application entry point
 * Routes for all pages of the application
 */
import { Hono } from 'hono'
import { serveStatic } from 'hono/cloudflare-workers'
import { cors } from 'hono/cors'

// Import page renderers
import { renderHome } from './pages/home'
import { renderLogin, renderSignup } from './pages/auth'
import { renderRestaurant } from './pages/restaurant'
import { renderCart } from './pages/cart'
import { renderCheckout } from './pages/checkout'
import { renderTracking } from './pages/tracking'
import { renderOrders } from './pages/orders'
import { renderProfile } from './pages/profile'
import { renderAdmin } from './pages/admin'
import { renderSearch } from './pages/search'

const app = new Hono()

// Enable CORS for API routes
app.use('/api/*', cors())

// Serve static files
app.use('/static/*', serveStatic({ root: './' }))

// ─── Page Routes ────────────────────────────────────────────────────────────

/** Home page - restaurant listings */
app.get('/', (c) => c.html(renderHome()))

/** Authentication pages */
app.get('/login', (c) => c.html(renderLogin()))
app.get('/signup', (c) => c.html(renderSignup()))

/** Search / filter restaurants */
app.get('/search', (c) => c.html(renderSearch()))

/** Restaurant detail + menu */
app.get('/restaurant/:id', (c) => {
  const id = c.req.param('id')
  return c.html(renderRestaurant(id))
})

/** Shopping cart */
app.get('/cart', (c) => c.html(renderCart()))

/** Checkout with payment options */
app.get('/checkout', (c) => c.html(renderCheckout()))

/** Real-time order tracking */
app.get('/tracking', (c) => c.html(renderTracking()))
app.get('/tracking/:orderId', (c) => {
  const orderId = c.req.param('orderId')
  return c.html(renderTracking(orderId))
})

/** Order history */
app.get('/orders', (c) => c.html(renderOrders()))

/** User profile */
app.get('/profile', (c) => c.html(renderProfile()))

/** Admin panel */
app.get('/admin', (c) => c.html(renderAdmin()))
app.get('/admin/:section', (c) => {
  const section = c.req.param('section')
  return c.html(renderAdmin(section))
})

// ─── API Routes (mock data) ──────────────────────────────────────────────────

/** Get all restaurants */
app.get('/api/restaurants', (c) => {
  return c.json({ success: true, data: getMockRestaurants() })
})

/** Get restaurant by ID */
app.get('/api/restaurants/:id', (c) => {
  const id = c.req.param('id')
  const restaurant = getMockRestaurants().find(r => r.id === id)
  if (!restaurant) return c.json({ success: false, error: 'Not found' }, 404)
  return c.json({ success: true, data: restaurant })
})

/** Search restaurants */
app.get('/api/search', (c) => {
  const q = c.req.query('q') || ''
  const veg = c.req.query('veg')
  const results = getMockRestaurants().filter(r =>
    r.name.toLowerCase().includes(q.toLowerCase()) ||
    r.cuisine.toLowerCase().includes(q.toLowerCase())
  )
  return c.json({ success: true, data: results })
})

/** Validate promo code */
app.post('/api/promo', async (c) => {
  const { code } = await c.req.json()
  const promoCodes: Record<string, number> = {
    'QUICKBITE10': 10,
    'FIRST50': 50,
    'SAVE20': 20,
    'WELCOME30': 30,
  }
  const discount = promoCodes[code?.toUpperCase()]
  if (discount) {
    return c.json({ success: true, discount, message: `${discount}% off applied!` })
  }
  return c.json({ success: false, message: 'Invalid promo code' })
})

/** Place order */
app.post('/api/orders', async (c) => {
  const body = await c.req.json()
  const orderId = 'QB' + Date.now().toString().slice(-6)
  return c.json({
    success: true,
    orderId,
    estimatedTime: Math.floor(Math.random() * 20) + 25,
    message: 'Order placed successfully!'
  })
})

/** Submit review */
app.post('/api/reviews', async (c) => {
  const body = await c.req.json()
  return c.json({ success: true, message: 'Review submitted!' })
})

/** Admin: Get analytics */
app.get('/api/admin/analytics', (c) => {
  return c.json({
    success: true,
    data: {
      totalSales: 45678,
      totalOrders: 1243,
      activeOrders: 18,
      newUsers: 89,
      topRestaurants: ['Burger Palace', 'Pizza Heaven', 'Sushi World'],
      monthlySales: [12000, 15000, 18000, 14000, 20000, 22000, 19000, 25000, 23000, 28000, 30000, 35000]
    }
  })
})

// ─── Mock Data ───────────────────────────────────────────────────────────────

function getMockRestaurants() {
  return [
    {
      id: '1',
      name: 'Burger Palace',
      cuisine: 'American, Burgers',
      rating: 4.5,
      reviews: 1243,
      deliveryTime: '20-30 min',
      deliveryFee: 2.99,
      minOrder: 10,
      distance: '1.2 km',
      priceRange: '$$',
      isVeg: false,
      promoted: true,
      discount: '20% OFF',
      image: '🍔',
      tags: ['Burgers', 'Fast Food', 'American'],
      menu: [
        { category: 'Burgers', items: [
          { id: 'b1', name: 'Classic Cheeseburger', price: 8.99, desc: 'Juicy beef patty with melted cheese', isVeg: false, rating: 4.6, calories: 520 },
          { id: 'b2', name: 'BBQ Bacon Burger', price: 11.99, desc: 'Smoky BBQ sauce with crispy bacon', isVeg: false, rating: 4.8, calories: 680 },
          { id: 'b3', name: 'Veggie Delight', price: 9.99, desc: 'Fresh veggie patty with lettuce', isVeg: true, rating: 4.3, calories: 420 },
          { id: 'b4', name: 'Double Stack', price: 13.99, desc: 'Double beef patty loaded with toppings', isVeg: false, rating: 4.7, calories: 820 },
        ]},
        { category: 'Sides', items: [
          { id: 's1', name: 'Crispy Fries', price: 3.99, desc: 'Golden crispy fries with seasoning', isVeg: true, rating: 4.4, calories: 320 },
          { id: 's2', name: 'Onion Rings', price: 4.49, desc: 'Beer-battered onion rings', isVeg: true, rating: 4.2, calories: 380 },
          { id: 's3', name: 'Coleslaw', price: 2.99, desc: 'Creamy homemade coleslaw', isVeg: true, rating: 4.0, calories: 180 },
        ]},
        { category: 'Drinks', items: [
          { id: 'd1', name: 'Classic Cola', price: 2.49, desc: 'Chilled classic cola', isVeg: true, rating: 4.0, calories: 150 },
          { id: 'd2', name: 'Vanilla Milkshake', price: 5.49, desc: 'Thick creamy vanilla shake', isVeg: true, rating: 4.7, calories: 480 },
        ]},
      ]
    },
    {
      id: '2',
      name: 'Pizza Heaven',
      cuisine: 'Italian, Pizza',
      rating: 4.7,
      reviews: 2156,
      deliveryTime: '25-35 min',
      deliveryFee: 1.99,
      minOrder: 12,
      distance: '0.8 km',
      priceRange: '$$',
      isVeg: false,
      promoted: false,
      discount: 'Free Delivery',
      image: '🍕',
      tags: ['Pizza', 'Italian', 'Pasta'],
      menu: [
        { category: 'Pizzas', items: [
          { id: 'p1', name: 'Margherita', price: 12.99, desc: 'Classic tomato and mozzarella', isVeg: true, rating: 4.8, calories: 680 },
          { id: 'p2', name: 'Pepperoni', price: 14.99, desc: 'Loaded with premium pepperoni', isVeg: false, rating: 4.9, calories: 820 },
          { id: 'p3', name: 'BBQ Chicken', price: 15.99, desc: 'Smoky BBQ with tender chicken', isVeg: false, rating: 4.6, calories: 780 },
          { id: 'p4', name: 'Veggie Supreme', price: 13.99, desc: 'Loaded with fresh vegetables', isVeg: true, rating: 4.5, calories: 620 },
        ]},
        { category: 'Pasta', items: [
          { id: 'pa1', name: 'Spaghetti Bolognese', price: 11.99, desc: 'Rich meat sauce pasta', isVeg: false, rating: 4.7, calories: 680 },
          { id: 'pa2', name: 'Penne Arrabbiata', price: 10.99, desc: 'Spicy tomato sauce', isVeg: true, rating: 4.4, calories: 580 },
        ]},
      ]
    },
    {
      id: '3',
      name: 'Sushi World',
      cuisine: 'Japanese, Sushi',
      rating: 4.8,
      reviews: 987,
      deliveryTime: '30-45 min',
      deliveryFee: 3.99,
      minOrder: 20,
      distance: '2.1 km',
      priceRange: '$$$',
      isVeg: false,
      promoted: true,
      discount: '15% OFF',
      image: '🍱',
      tags: ['Sushi', 'Japanese', 'Healthy'],
      menu: [
        { category: 'Rolls', items: [
          { id: 'r1', name: 'California Roll', price: 12.99, desc: 'Crab, avocado, cucumber', isVeg: false, rating: 4.7, calories: 340 },
          { id: 'r2', name: 'Spicy Tuna', price: 14.99, desc: 'Fresh tuna with spicy mayo', isVeg: false, rating: 4.9, calories: 380 },
          { id: 'r3', name: 'Avocado Roll', price: 10.99, desc: 'Creamy avocado roll', isVeg: true, rating: 4.5, calories: 280 },
        ]},
        { category: 'Sashimi', items: [
          { id: 'sa1', name: 'Salmon Sashimi', price: 18.99, desc: '8 pieces of fresh salmon', isVeg: false, rating: 4.8, calories: 280 },
          { id: 'sa2', name: 'Tuna Sashimi', price: 19.99, desc: '8 pieces of premium tuna', isVeg: false, rating: 4.9, calories: 260 },
        ]},
      ]
    },
    {
      id: '4',
      name: 'Taco Fiesta',
      cuisine: 'Mexican, Tacos',
      rating: 4.3,
      reviews: 654,
      deliveryTime: '15-25 min',
      deliveryFee: 0,
      minOrder: 8,
      distance: '0.5 km',
      priceRange: '$',
      isVeg: false,
      promoted: false,
      discount: 'Free Delivery',
      image: '🌮',
      tags: ['Tacos', 'Mexican', 'Burritos'],
      menu: [
        { category: 'Tacos', items: [
          { id: 't1', name: 'Chicken Taco', price: 3.99, desc: 'Grilled chicken with salsa', isVeg: false, rating: 4.4, calories: 280 },
          { id: 't2', name: 'Beef Taco', price: 4.49, desc: 'Seasoned beef with toppings', isVeg: false, rating: 4.5, calories: 320 },
          { id: 't3', name: 'Bean Taco', price: 3.49, desc: 'Black beans with guacamole', isVeg: true, rating: 4.2, calories: 240 },
        ]},
        { category: 'Burritos', items: [
          { id: 'bu1', name: 'Super Burrito', price: 9.99, desc: 'Loaded burrito with rice and beans', isVeg: false, rating: 4.6, calories: 680 },
          { id: 'bu2', name: 'Veggie Burrito', price: 8.99, desc: 'Grilled veggies with guacamole', isVeg: true, rating: 4.3, calories: 560 },
        ]},
      ]
    },
    {
      id: '5',
      name: 'Green Bowl',
      cuisine: 'Healthy, Salads',
      rating: 4.6,
      reviews: 432,
      deliveryTime: '20-30 min',
      deliveryFee: 2.49,
      minOrder: 15,
      distance: '1.8 km',
      priceRange: '$$',
      isVeg: true,
      promoted: false,
      discount: '10% OFF',
      image: '🥗',
      tags: ['Healthy', 'Salads', 'Vegan'],
      menu: [
        { category: 'Salads', items: [
          { id: 'sl1', name: 'Caesar Salad', price: 10.99, desc: 'Romaine, croutons, parmesan', isVeg: true, rating: 4.6, calories: 320 },
          { id: 'sl2', name: 'Greek Salad', price: 11.99, desc: 'Feta, olives, cucumber', isVeg: true, rating: 4.7, calories: 280 },
          { id: 'sl3', name: 'Quinoa Bowl', price: 13.99, desc: 'Protein-packed quinoa with veggies', isVeg: true, rating: 4.8, calories: 420 },
        ]},
        { category: 'Bowls', items: [
          { id: 'bw1', name: 'Buddha Bowl', price: 14.99, desc: 'Nutritious mixed grain bowl', isVeg: true, rating: 4.7, calories: 480 },
          { id: 'bw2', name: 'Poke Bowl', price: 16.99, desc: 'Hawaiian style poke bowl', isVeg: false, rating: 4.8, calories: 520 },
        ]},
      ]
    },
    {
      id: '6',
      name: 'Curry House',
      cuisine: 'Indian, Curry',
      rating: 4.7,
      reviews: 1876,
      deliveryTime: '30-40 min',
      deliveryFee: 1.99,
      minOrder: 15,
      distance: '1.5 km',
      priceRange: '$$',
      isVeg: false,
      promoted: true,
      discount: '25% OFF',
      image: '🍛',
      tags: ['Indian', 'Curry', 'Spicy'],
      menu: [
        { category: 'Curries', items: [
          { id: 'c1', name: 'Butter Chicken', price: 14.99, desc: 'Creamy tomato-based chicken curry', isVeg: false, rating: 4.9, calories: 580 },
          { id: 'c2', name: 'Paneer Tikka Masala', price: 13.99, desc: 'Rich paneer in spiced sauce', isVeg: true, rating: 4.7, calories: 520 },
          { id: 'c3', name: 'Lamb Rogan Josh', price: 16.99, desc: 'Slow-cooked aromatic lamb', isVeg: false, rating: 4.8, calories: 620 },
          { id: 'c4', name: 'Dal Makhani', price: 11.99, desc: 'Creamy black lentils', isVeg: true, rating: 4.6, calories: 420 },
        ]},
        { category: 'Breads & Rice', items: [
          { id: 'br1', name: 'Garlic Naan', price: 3.49, desc: 'Soft garlic flatbread', isVeg: true, rating: 4.8, calories: 280 },
          { id: 'br2', name: 'Biryani Rice', price: 8.99, desc: 'Fragrant basmati rice', isVeg: true, rating: 4.7, calories: 380 },
        ]},
      ]
    },
  ]
}

export default app
