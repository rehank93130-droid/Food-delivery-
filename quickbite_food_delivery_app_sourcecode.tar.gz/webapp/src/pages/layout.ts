/**
 * QuickBite - Shared Layout
 * Common HTML shell with CSS variables, animations, and global styles
 */

export function getSharedStyles(): string {
  return `
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
      /* ── CSS Variables & Theming ─────────────────────────── */
      :root {
        --primary: #E53E3E;
        --primary-dark: #C53030;
        --primary-light: #FEB2B2;
        --primary-gradient: linear-gradient(135deg, #E53E3E 0%, #C53030 100%);
        --secondary: #FF6B35;
        --accent: #FFD700;
        --bg: #F7F8FC;
        --surface: #FFFFFF;
        --surface-2: #F1F3F9;
        --text: #1A202C;
        --text-secondary: #718096;
        --text-muted: #A0AEC0;
        --border: #E2E8F0;
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.08);
        --shadow: 0 4px 16px rgba(0,0,0,0.08);
        --shadow-md: 0 8px 32px rgba(0,0,0,0.12);
        --shadow-lg: 0 20px 60px rgba(0,0,0,0.15);
        --radius-sm: 8px;
        --radius: 12px;
        --radius-lg: 16px;
        --radius-xl: 24px;
        --radius-full: 9999px;
        --transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        --header-height: 64px;
        --success: #38A169;
        --warning: #D69E2E;
        --info: #3182CE;
      }
      [data-theme="dark"] {
        --bg: #0F1117;
        --surface: #1A1D26;
        --surface-2: #252836;
        --text: #F7FAFC;
        --text-secondary: #A0AEC0;
        --text-muted: #718096;
        --border: #2D3748;
        --shadow: 0 4px 16px rgba(0,0,0,0.4);
        --shadow-md: 0 8px 32px rgba(0,0,0,0.5);
        --shadow-lg: 0 20px 60px rgba(0,0,0,0.6);
      }

      /* ── Reset & Base ───────────────────────────────────── */
      *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
      html { scroll-behavior: smooth; font-size: 16px; }
      body {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        background: var(--bg);
        color: var(--text);
        line-height: 1.6;
        min-height: 100vh;
        transition: background 0.3s, color 0.3s;
        -webkit-font-smoothing: antialiased;
      }
      a { text-decoration: none; color: inherit; }
      button { cursor: pointer; border: none; outline: none; font-family: inherit; }
      input, textarea, select { font-family: inherit; outline: none; }
      img { max-width: 100%; }

      /* ── Scrollbar ──────────────────────────────────────── */
      ::-webkit-scrollbar { width: 6px; height: 6px; }
      ::-webkit-scrollbar-track { background: var(--bg); }
      ::-webkit-scrollbar-thumb { background: var(--primary-light); border-radius: 3px; }

      /* ── Typography ─────────────────────────────────────── */
      h1, h2, h3, h4, h5, h6 { font-weight: 700; line-height: 1.3; color: var(--text); }
      h1 { font-size: clamp(1.8rem, 4vw, 2.5rem); }
      h2 { font-size: clamp(1.4rem, 3vw, 2rem); }
      h3 { font-size: clamp(1.1rem, 2vw, 1.4rem); }
      p { color: var(--text-secondary); }

      /* ── Header ─────────────────────────────────────────── */
      .header {
        position: fixed; top: 0; left: 0; right: 0; z-index: 1000;
        height: var(--header-height);
        background: var(--surface);
        box-shadow: var(--shadow-sm);
        display: flex; align-items: center;
        padding: 0 20px;
        gap: 16px;
        backdrop-filter: blur(20px);
        border-bottom: 1px solid var(--border);
        transition: var(--transition);
      }
      .header-logo {
        display: flex; align-items: center; gap: 8px;
        font-size: 1.4rem; font-weight: 800; color: var(--primary);
        text-decoration: none;
        flex-shrink: 0;
      }
      .header-logo .logo-icon {
        width: 36px; height: 36px;
        background: var(--primary-gradient);
        border-radius: 10px;
        display: flex; align-items: center; justify-content: center;
        color: white; font-size: 18px;
      }
      .header-location {
        display: flex; align-items: center; gap: 6px;
        color: var(--text-secondary);
        font-size: 0.85rem;
        cursor: pointer;
        padding: 6px 12px;
        border-radius: var(--radius-sm);
        background: var(--surface-2);
        transition: var(--transition);
        white-space: nowrap;
      }
      .header-location:hover { background: var(--primary-light); color: var(--primary); }
      .header-location i { color: var(--primary); font-size: 14px; }
      .header-search {
        flex: 1; max-width: 400px;
        position: relative;
        display: flex; align-items: center;
      }
      .header-search input {
        width: 100%; padding: 10px 16px 10px 42px;
        border: 1.5px solid var(--border);
        border-radius: var(--radius-full);
        background: var(--surface-2);
        color: var(--text);
        font-size: 0.9rem;
        transition: var(--transition);
      }
      .header-search input:focus { border-color: var(--primary); background: var(--surface); box-shadow: 0 0 0 3px rgba(229,62,62,0.1); }
      .header-search .search-icon {
        position: absolute; left: 14px;
        color: var(--text-muted); font-size: 14px;
        pointer-events: none;
      }
      .header-nav { display: flex; align-items: center; gap: 8px; margin-left: auto; }
      .nav-btn {
        display: flex; align-items: center; gap: 6px;
        padding: 8px 16px; border-radius: var(--radius-full);
        font-size: 0.85rem; font-weight: 600;
        transition: var(--transition); color: var(--text-secondary);
        background: transparent;
        white-space: nowrap;
      }
      .nav-btn:hover { background: var(--surface-2); color: var(--text); }
      .nav-btn.primary { background: var(--primary); color: white; }
      .nav-btn.primary:hover { background: var(--primary-dark); transform: translateY(-1px); }
      .nav-btn .badge {
        background: var(--accent); color: #1A202C;
        width: 18px; height: 18px; border-radius: 50%;
        font-size: 11px; font-weight: 700;
        display: flex; align-items: center; justify-content: center;
      }
      .theme-toggle {
        width: 40px; height: 40px;
        border-radius: 50%; border: 1.5px solid var(--border);
        background: var(--surface);
        display: flex; align-items: center; justify-content: center;
        font-size: 16px; transition: var(--transition); cursor: pointer;
      }
      .theme-toggle:hover { background: var(--surface-2); transform: rotate(15deg); }

      /* ── Mobile Nav ─────────────────────────────────────── */
      .mobile-nav {
        display: none;
        position: fixed; bottom: 0; left: 0; right: 0; z-index: 999;
        background: var(--surface);
        border-top: 1px solid var(--border);
        padding: 8px 0 12px;
        box-shadow: 0 -4px 20px rgba(0,0,0,0.08);
      }
      .mobile-nav-inner { display: flex; justify-content: space-around; }
      .mobile-nav-item {
        display: flex; flex-direction: column; align-items: center; gap: 2px;
        padding: 6px 12px; border-radius: var(--radius-sm);
        font-size: 10px; font-weight: 600; color: var(--text-muted);
        cursor: pointer; transition: var(--transition); background: none;
        position: relative;
      }
      .mobile-nav-item i { font-size: 20px; }
      .mobile-nav-item.active { color: var(--primary); }
      .mobile-nav-item .mob-badge {
        position: absolute; top: 4px; right: 10px;
        background: var(--primary); color: white;
        width: 16px; height: 16px; border-radius: 50%;
        font-size: 10px; font-weight: 700;
        display: flex; align-items: center; justify-content: center;
      }
      @media (max-width: 768px) {
        .mobile-nav { display: block; }
        .header-nav .nav-btn:not(.mobile-show) { display: none; }
        .header-location { display: none; }
        body { padding-bottom: 70px; }
      }
      @media (max-width: 480px) {
        .header { padding: 0 12px; gap: 10px; }
        .header-search { max-width: none; }
      }

      /* ── Main Content ────────────────────────────────────── */
      .main { padding-top: var(--header-height); min-height: 100vh; }
      .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
      @media (max-width: 480px) { .container { padding: 0 12px; } }

      /* ── Cards ───────────────────────────────────────────── */
      .card {
        background: var(--surface);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow);
        overflow: hidden;
        transition: var(--transition);
        border: 1px solid var(--border);
      }
      .card:hover { transform: translateY(-4px); box-shadow: var(--shadow-md); }
      .card-body { padding: 16px; }

      /* ── Buttons ─────────────────────────────────────────── */
      .btn {
        display: inline-flex; align-items: center; justify-content: center; gap: 8px;
        padding: 10px 20px;
        border-radius: var(--radius-full);
        font-size: 0.9rem; font-weight: 600;
        transition: var(--transition);
        cursor: pointer; border: none;
      }
      .btn-primary { background: var(--primary-gradient); color: white; }
      .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(229,62,62,0.4); }
      .btn-outline { background: transparent; border: 2px solid var(--primary); color: var(--primary); }
      .btn-outline:hover { background: var(--primary); color: white; }
      .btn-ghost { background: var(--surface-2); color: var(--text); }
      .btn-ghost:hover { background: var(--border); }
      .btn-success { background: linear-gradient(135deg, #38A169, #2F855A); color: white; }
      .btn-success:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(56,161,105,0.4); }
      .btn-lg { padding: 14px 28px; font-size: 1rem; }
      .btn-sm { padding: 6px 14px; font-size: 0.8rem; }
      .btn-full { width: 100%; }
      .btn:disabled { opacity: 0.5; cursor: not-allowed; transform: none !important; }

      /* ── Form Elements ───────────────────────────────────── */
      .form-group { margin-bottom: 16px; }
      .form-label { display: block; font-size: 0.85rem; font-weight: 600; color: var(--text); margin-bottom: 6px; }
      .form-input {
        width: 100%; padding: 12px 16px;
        border: 1.5px solid var(--border);
        border-radius: var(--radius);
        background: var(--surface-2);
        color: var(--text);
        font-size: 0.9rem;
        transition: var(--transition);
      }
      .form-input:focus { border-color: var(--primary); background: var(--surface); box-shadow: 0 0 0 3px rgba(229,62,62,0.1); }
      .form-input::placeholder { color: var(--text-muted); }
      .input-group { position: relative; }
      .input-group .input-icon { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: var(--text-muted); }
      .input-group .form-input { padding-left: 42px; }
      .input-group .input-icon-right { position: absolute; right: 14px; top: 50%; transform: translateY(-50%); color: var(--text-muted); cursor: pointer; }

      /* ── Tags / Badges ───────────────────────────────────── */
      .tag {
        display: inline-flex; align-items: center; gap: 4px;
        padding: 3px 10px;
        border-radius: var(--radius-full);
        font-size: 0.75rem; font-weight: 600;
        background: var(--surface-2); color: var(--text-secondary);
      }
      .tag-primary { background: rgba(229,62,62,0.1); color: var(--primary); }
      .tag-success { background: rgba(56,161,105,0.12); color: var(--success); }
      .tag-warning { background: rgba(214,158,46,0.12); color: var(--warning); }
      .tag-info { background: rgba(49,130,206,0.12); color: var(--info); }

      /* ── Stars ───────────────────────────────────────────── */
      .stars { display: flex; align-items: center; gap: 2px; }
      .star { color: var(--accent); font-size: 14px; }
      .star.empty { color: var(--border); }

      /* ── Qty Control ─────────────────────────────────────── */
      .qty-control {
        display: flex; align-items: center; gap: 0;
        background: var(--surface-2);
        border-radius: var(--radius-full);
        overflow: hidden;
        border: 1.5px solid var(--border);
      }
      .qty-btn {
        width: 32px; height: 32px;
        display: flex; align-items: center; justify-content: center;
        background: transparent; color: var(--text);
        font-size: 16px; font-weight: 700;
        transition: var(--transition); cursor: pointer; border: none;
      }
      .qty-btn:hover { background: var(--primary); color: white; }
      .qty-val {
        min-width: 32px; text-align: center;
        font-size: 0.9rem; font-weight: 700; color: var(--text);
      }

      /* ── Toast Notifications ─────────────────────────────── */
      .toast-container {
        position: fixed; top: 80px; right: 20px; z-index: 9999;
        display: flex; flex-direction: column; gap: 8px;
      }
      .toast {
        display: flex; align-items: center; gap: 10px;
        padding: 12px 16px; border-radius: var(--radius);
        background: var(--surface);
        box-shadow: var(--shadow-md);
        border-left: 4px solid var(--primary);
        min-width: 280px; max-width: 360px;
        animation: toastIn 0.3s ease, toastOut 0.3s ease forwards;
        animation-delay: 0s, 3.5s;
      }
      .toast.success { border-left-color: var(--success); }
      .toast.error { border-left-color: #E53E3E; }
      .toast.info { border-left-color: var(--info); }
      .toast-icon { font-size: 18px; flex-shrink: 0; }
      .toast-msg { font-size: 0.875rem; font-weight: 500; color: var(--text); }
      @keyframes toastIn {
        from { opacity: 0; transform: translateX(100%); }
        to { opacity: 1; transform: translateX(0); }
      }
      @keyframes toastOut {
        from { opacity: 1; transform: translateX(0); }
        to { opacity: 0; transform: translateX(100%); }
      }

      /* ── Loading Spinner ─────────────────────────────────── */
      .spinner {
        width: 40px; height: 40px;
        border: 3px solid var(--border);
        border-top-color: var(--primary);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
        margin: 0 auto;
      }
      @keyframes spin { to { transform: rotate(360deg); } }

      /* ── Skeleton Loading ────────────────────────────────── */
      .skeleton {
        background: linear-gradient(90deg, var(--surface-2) 25%, var(--border) 50%, var(--surface-2) 75%);
        background-size: 200% 100%;
        animation: skeleton 1.5s infinite;
        border-radius: var(--radius-sm);
      }
      @keyframes skeleton {
        0% { background-position: 200% 0; }
        100% { background-position: -200% 0; }
      }

      /* ── Rating Stars ────────────────────────────────────── */
      .rating-input { display: flex; gap: 4px; }
      .rating-star { font-size: 28px; cursor: pointer; color: var(--border); transition: color 0.15s; }
      .rating-star.active, .rating-star:hover { color: var(--accent); }

      /* ── Progress Bar ────────────────────────────────────── */
      .progress-bar { width: 100%; height: 8px; background: var(--border); border-radius: var(--radius-full); overflow: hidden; }
      .progress-fill { height: 100%; background: var(--primary-gradient); border-radius: var(--radius-full); transition: width 0.8s ease; }

      /* ── Modals ──────────────────────────────────────────── */
      .modal-overlay {
        position: fixed; inset: 0; z-index: 2000;
        background: rgba(0,0,0,0.6);
        backdrop-filter: blur(4px);
        display: flex; align-items: center; justify-content: center;
        padding: 20px;
        opacity: 0; pointer-events: none;
        transition: opacity 0.25s;
      }
      .modal-overlay.open { opacity: 1; pointer-events: all; }
      .modal {
        background: var(--surface);
        border-radius: var(--radius-xl);
        box-shadow: var(--shadow-lg);
        width: 100%; max-width: 500px;
        transform: scale(0.95) translateY(20px);
        transition: transform 0.25s ease;
        overflow: hidden;
      }
      .modal-overlay.open .modal { transform: scale(1) translateY(0); }
      .modal-header {
        padding: 20px 24px;
        border-bottom: 1px solid var(--border);
        display: flex; align-items: center; justify-content: space-between;
      }
      .modal-header h3 { font-size: 1.1rem; }
      .modal-close { width: 32px; height: 32px; border-radius: 50%; background: var(--surface-2); display: flex; align-items: center; justify-content: center; cursor: pointer; border: none; color: var(--text); font-size: 16px; }
      .modal-body { padding: 24px; }
      .modal-footer { padding: 16px 24px; border-top: 1px solid var(--border); display: flex; gap: 12px; justify-content: flex-end; }

      /* ── Chips / Filter Pills ────────────────────────────── */
      .chip {
        display: inline-flex; align-items: center; gap: 6px;
        padding: 6px 14px;
        border-radius: var(--radius-full);
        font-size: 0.82rem; font-weight: 600;
        background: var(--surface); color: var(--text-secondary);
        border: 1.5px solid var(--border);
        cursor: pointer; transition: var(--transition);
        white-space: nowrap;
      }
      .chip:hover { border-color: var(--primary); color: var(--primary); background: rgba(229,62,62,0.05); }
      .chip.active { background: var(--primary); color: white; border-color: var(--primary); }
      .chip i { font-size: 12px; }

      /* ── Section Header ──────────────────────────────────── */
      .section-header {
        display: flex; align-items: center; justify-content: space-between;
        margin-bottom: 20px; padding-top: 24px;
      }
      .section-header h2 { font-size: 1.3rem; }
      .see-all { font-size: 0.875rem; font-weight: 600; color: var(--primary); cursor: pointer; transition: var(--transition); }
      .see-all:hover { opacity: 0.7; }

      /* ── Grid Layouts ────────────────────────────────────── */
      .grid-2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
      .grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
      .grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
      @media (max-width: 1024px) { .grid-4 { grid-template-columns: repeat(3, 1fr); } }
      @media (max-width: 768px) { .grid-3, .grid-4 { grid-template-columns: repeat(2, 1fr); } }
      @media (max-width: 480px) { .grid-2, .grid-3, .grid-4 { grid-template-columns: 1fr; } }

      /* ── Animations ──────────────────────────────────────── */
      .fade-in { animation: fadeIn 0.4s ease forwards; }
      .slide-up { animation: slideUp 0.4s ease forwards; }
      .bounce-in { animation: bounceIn 0.5s ease forwards; }
      @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
      @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes bounceIn {
        0% { transform: scale(0.7); opacity: 0; }
        60% { transform: scale(1.1); opacity: 1; }
        100% { transform: scale(1); }
      }
      .stagger-1 { animation-delay: 0.05s; }
      .stagger-2 { animation-delay: 0.1s; }
      .stagger-3 { animation-delay: 0.15s; }
      .stagger-4 { animation-delay: 0.2s; }
      .stagger-5 { animation-delay: 0.25s; }
    </style>
  `
}

export function getHeader(activePage: string = 'home', cartCount: number = 0): string {
  return `
  <header class="header">
    <a href="/" class="header-logo">
      <div class="logo-icon">🍔</div>
      QuickBite
    </a>
    <div class="header-location" onclick="showLocationModal()">
      <i class="fas fa-map-marker-alt"></i>
      <span id="location-text">New York, NY</span>
      <i class="fas fa-chevron-down" style="font-size:10px;margin-left:2px;"></i>
    </div>
    <div class="header-search">
      <i class="fas fa-search search-icon"></i>
      <input type="text" placeholder="Search restaurants or food..." id="header-search"
        onkeydown="if(event.key==='Enter') window.location.href='/search?q='+this.value"
        value="">
    </div>
    <nav class="header-nav">
      <button class="theme-toggle" id="theme-toggle" onclick="toggleTheme()" title="Toggle dark mode">
        <i class="fas fa-moon" id="theme-icon"></i>
      </button>
      <a href="/orders" class="nav-btn ${activePage === 'orders' ? 'active' : ''}">
        <i class="fas fa-receipt"></i> <span class="hide-mobile">Orders</span>
      </a>
      <a href="/cart" class="nav-btn mobile-show" style="position:relative;">
        <i class="fas fa-shopping-cart"></i>
        <span id="cart-badge" class="badge" style="display:${cartCount > 0 ? 'flex' : 'none'}">${cartCount}</span>
        <span class="hide-mobile">Cart</span>
      </a>
      <a href="/login" class="nav-btn primary mobile-show">
        <i class="fas fa-user"></i> <span class="hide-mobile">Sign In</span>
      </a>
      <a href="/profile" class="nav-btn" style="display:none;" id="profile-btn">
        <img id="profile-avatar" src="" style="width:28px;height:28px;border-radius:50%;object-fit:cover;">
      </a>
    </nav>
  </header>

  <!-- Mobile Bottom Nav -->
  <nav class="mobile-nav">
    <div class="mobile-nav-inner">
      <button class="mobile-nav-item ${activePage === 'home' ? 'active' : ''}" onclick="window.location.href='/'">
        <i class="fas fa-home"></i> Home
      </button>
      <button class="mobile-nav-item ${activePage === 'search' ? 'active' : ''}" onclick="window.location.href='/search'">
        <i class="fas fa-search"></i> Search
      </button>
      <button class="mobile-nav-item ${activePage === 'orders' ? 'active' : ''}" onclick="window.location.href='/orders'">
        <i class="fas fa-receipt"></i> Orders
      </button>
      <button class="mobile-nav-item ${activePage === 'cart' ? 'active' : ''}" onclick="window.location.href='/cart'" style="position:relative;">
        <i class="fas fa-shopping-cart"></i>
        <span id="mob-cart-badge" class="mob-badge" style="display:none">0</span>
        Cart
      </button>
      <button class="mobile-nav-item ${activePage === 'profile' ? 'active' : ''}" onclick="window.location.href='/profile'">
        <i class="fas fa-user"></i> Profile
      </button>
    </div>
  </nav>

  <!-- Toast Container -->
  <div class="toast-container" id="toast-container"></div>

  <!-- Location Modal -->
  <div class="modal-overlay" id="location-modal">
    <div class="modal">
      <div class="modal-header">
        <h3><i class="fas fa-map-marker-alt" style="color:var(--primary);margin-right:8px;"></i>Choose Delivery Location</h3>
        <button class="modal-close" onclick="closeModal('location-modal')"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <div class="input-group">
            <i class="fas fa-search input-icon"></i>
            <input class="form-input" placeholder="Search your location..." id="location-input">
          </div>
        </div>
        <div style="margin-top:12px;">
          <p style="font-size:0.8rem;color:var(--text-muted);margin-bottom:10px;font-weight:600;">SAVED ADDRESSES</p>
          <div class="saved-addresses">
            ${['🏠 Home — 123 Main St, New York', '🏢 Work — 456 Office Ave, Brooklyn', '⭐ Mom\'s — 789 Park Rd, Queens'].map(addr => `
              <div class="address-option" onclick="setLocation('${addr.replace(/'/g, "&#39;").split('—')[1]?.trim() || addr}')"
                style="padding:12px;border-radius:var(--radius);cursor:pointer;transition:var(--transition);display:flex;align-items:center;gap:10px;border:1.5px solid var(--border);margin-bottom:8px;">
                <span style="font-size:1.1rem;">${addr.split(' ')[0]}</span>
                <span style="font-size:0.875rem;font-weight:500;">${addr.split('—')[1]?.trim() || addr}</span>
              </div>
            `).join('')}
          </div>
          <button class="btn btn-outline btn-full" style="margin-top:12px;" onclick="useCurrentLocation()">
            <i class="fas fa-crosshairs"></i> Use Current Location
          </button>
        </div>
      </div>
    </div>
  </div>
  `
}

export function getGlobalScripts(): string {
  return `
  <script>
    // ── Cart Store ─────────────────────────────────────────
    const QB = {
      get cart() { try { return JSON.parse(localStorage.getItem('qb_cart') || '[]'); } catch { return []; } },
      set cart(v) { localStorage.setItem('qb_cart', JSON.stringify(v)); QB.updateCartUI(); },
      get cartCount() { return QB.cart.reduce((s,i) => s + i.qty, 0); },
      get cartTotal() { return QB.cart.reduce((s,i) => s + i.price * i.qty, 0); },
      get user() { try { return JSON.parse(localStorage.getItem('qb_user') || 'null'); } catch { return null; } },
      set user(v) { localStorage.setItem('qb_user', JSON.stringify(v)); },
      get theme() { return localStorage.getItem('qb_theme') || 'light'; },
      set theme(v) { localStorage.setItem('qb_theme', v); },

      addToCart(item) {
        const cart = QB.cart;
        const idx = cart.findIndex(i => i.id === item.id);
        if (idx > -1) {
          cart[idx].qty++;
        } else {
          cart.push({ ...item, qty: 1 });
        }
        QB.cart = cart;
        QB.showToast('🛒 Added to cart!', 'success');
      },

      removeFromCart(id) {
        QB.cart = QB.cart.filter(i => i.id !== id);
        QB.showToast('Removed from cart', 'info');
      },

      updateQty(id, delta) {
        const cart = QB.cart;
        const idx = cart.findIndex(i => i.id === id);
        if (idx > -1) {
          cart[idx].qty += delta;
          if (cart[idx].qty <= 0) cart.splice(idx, 1);
          QB.cart = cart;
        }
      },

      clearCart() { QB.cart = []; },

      updateCartUI() {
        const count = QB.cartCount;
        const badge = document.getElementById('cart-badge');
        const mobBadge = document.getElementById('mob-cart-badge');
        if (badge) { badge.style.display = count > 0 ? 'flex' : 'none'; badge.textContent = count; }
        if (mobBadge) { mobBadge.style.display = count > 0 ? 'flex' : 'none'; mobBadge.textContent = count; }
      },

      showToast(msg, type = 'info', duration = 4000) {
        const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
        const container = document.getElementById('toast-container');
        if (!container) return;
        const toast = document.createElement('div');
        toast.className = 'toast ' + type;
        toast.innerHTML = '<span class="toast-icon">' + (icons[type]||'ℹ️') + '</span><span class="toast-msg">' + msg + '</span>';
        container.appendChild(toast);
        setTimeout(() => toast.remove(), duration);
      },

      formatPrice(p) { return '$' + p.toFixed(2); },
    };

    // ── Theme ──────────────────────────────────────────────
    function applyTheme(t) {
      document.documentElement.setAttribute('data-theme', t);
      const icon = document.getElementById('theme-icon');
      if (icon) icon.className = t === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
    function toggleTheme() {
      const newTheme = QB.theme === 'dark' ? 'light' : 'dark';
      QB.theme = newTheme; applyTheme(newTheme);
    }

    // ── Modals ─────────────────────────────────────────────
    function openModal(id) { document.getElementById(id)?.classList.add('open'); }
    function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }
    function showLocationModal() { openModal('location-modal'); }
    function setLocation(loc) {
      document.getElementById('location-text').textContent = loc.trim().split(',')[0];
      closeModal('location-modal');
      QB.showToast('📍 Location updated!', 'success');
    }
    function useCurrentLocation() {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(() => {
          setLocation('Your Location');
        }, () => QB.showToast('Location access denied', 'error'));
      }
    }

    // ── Auth Check ─────────────────────────────────────────
    function checkAuth() {
      const user = QB.user;
      const profileBtn = document.getElementById('profile-btn');
      if (user && profileBtn) {
        profileBtn.style.display = 'flex';
        const avatar = document.getElementById('profile-avatar');
        if (avatar) avatar.src = user.avatar || 'https://ui-avatars.com/api/?name='+encodeURIComponent(user.name)+'&background=E53E3E&color=fff';
      }
    }

    // ── Init ───────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', () => {
      applyTheme(QB.theme);
      QB.updateCartUI();
      checkAuth();
      // Close modals on overlay click
      document.querySelectorAll('.modal-overlay').forEach(el => {
        el.addEventListener('click', e => { if (e.target === el) el.classList.remove('open'); });
      });
      // Address hover effect
      document.querySelectorAll('.address-option').forEach(el => {
        el.addEventListener('mouseenter', () => { el.style.borderColor = 'var(--primary)'; el.style.background = 'rgba(229,62,62,0.05)'; });
        el.addEventListener('mouseleave', () => { el.style.borderColor = 'var(--border)'; el.style.background = ''; });
      });
    });
  </script>
  `
}

export function pageShell(title: string, content: string, activePage: string = 'home', scripts: string = ''): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title} | QuickBite</title>
  <meta name="description" content="QuickBite - Order food from your favorite restaurants">
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🍔</text></svg>">
  ${getSharedStyles()}
</head>
<body>
  ${getHeader(activePage)}
  <main class="main">
    ${content}
  </main>
  ${getGlobalScripts()}
  ${scripts}
</body>
</html>`
}
