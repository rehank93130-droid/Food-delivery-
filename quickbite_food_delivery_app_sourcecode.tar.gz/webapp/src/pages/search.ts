/**
 * QuickBite - Search Page
 * Search restaurants with filters, sorting, and live results
 */
import { pageShell } from './layout'

export function renderSearch(): string {
  const content = `
  <div class="container" style="padding-top:24px;padding-bottom:40px;">
    <h2 style="margin-bottom:16px;"><i class="fas fa-search" style="color:var(--primary);margin-right:8px;"></i>Search Restaurants</h2>

    <!-- Search Bar -->
    <div style="position:relative;margin-bottom:20px;">
      <input type="text" id="search-input" class="form-input" style="padding:14px 16px 14px 48px;font-size:1rem;border-radius:var(--radius-lg);"
        placeholder="Search for restaurants, cuisines, or dishes..."
        oninput="performSearch(this.value)">
      <i class="fas fa-search" style="position:absolute;left:16px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:18px;"></i>
      <button id="clear-search" onclick="clearSearch()" style="position:absolute;right:16px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-muted);font-size:16px;cursor:pointer;display:none;">
        <i class="fas fa-times"></i>
      </button>
    </div>

    <!-- Filter Chips -->
    <div style="display:flex;gap:8px;overflow-x:auto;padding-bottom:12px;scrollbar-width:none;margin-bottom:20px;flex-wrap:wrap;">
      <button class="chip active" id="f-all" onclick="setFilter('all')"><i class="fas fa-border-all"></i> All</button>
      <button class="chip" id="f-veg" onclick="setFilter('veg')"><i class="fas fa-leaf" style="color:#38A169;"></i> Veg Only</button>
      <button class="chip" id="f-rating" onclick="setFilter('rating')"><i class="fas fa-star" style="color:#D69E2E;"></i> 4.5+</button>
      <button class="chip" id="f-fast" onclick="setFilter('fast')"><i class="fas fa-bolt"></i> Under 30 min</button>
      <button class="chip" id="f-free" onclick="setFilter('free')"><i class="fas fa-motorcycle"></i> Free Delivery</button>
      <button class="chip" id="f-budget" onclick="setFilter('budget')"><i class="fas fa-dollar-sign"></i> Budget</button>
      <button class="chip" id="f-promo" onclick="setFilter('promo')"><i class="fas fa-percent"></i> Offers</button>
      <button class="chip" id="f-near" onclick="setFilter('near')"><i class="fas fa-map-marker-alt"></i> Nearby</button>
    </div>

    <!-- Sort + Results Count -->
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
      <p style="font-size:0.875rem;color:var(--text-muted);" id="search-count">Showing <strong>6</strong> results</p>
      <div style="display:flex;gap:8px;align-items:center;">
        <span style="font-size:0.82rem;color:var(--text-muted);">Sort by:</span>
        <select class="form-input" style="padding:6px 12px;font-size:0.82rem;width:auto;" onchange="sortResults(this.value)">
          <option value="relevance">Relevance</option>
          <option value="rating">Rating ↓</option>
          <option value="time">Fastest</option>
          <option value="distance">Nearest</option>
          <option value="fee">Lowest Fee</option>
        </select>
        <button class="btn btn-ghost btn-sm" onclick="toggleView()" id="view-toggle" title="Toggle view">
          <i class="fas fa-th-large" id="view-icon"></i>
        </button>
      </div>
    </div>

    <!-- Restaurant Results -->
    <div class="grid-3" id="search-grid">
      <!-- Populated by JS -->
    </div>

    <!-- No Results -->
    <div id="no-results" style="display:none;text-align:center;padding:80px 20px;">
      <div style="font-size:80px;margin-bottom:16px;">😔</div>
      <h3 style="margin-bottom:8px;">No results found</h3>
      <p style="color:var(--text-muted);margin-bottom:20px;">Try different keywords or remove some filters</p>
      <button class="btn btn-primary" onclick="clearAll()"><i class="fas fa-redo"></i> Clear All Filters</button>
    </div>

    <!-- Popular Searches -->
    <div id="popular-section">
      <div class="section-header">
        <h3><i class="fas fa-fire" style="color:var(--primary);margin-right:8px;"></i>Trending Searches</h3>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        ${['🍔 Burgers','🍕 Pizza','🍜 Noodles','🌮 Tacos','🥗 Salads','🍛 Curry','🍣 Sushi','🍗 Chicken'].map(t => `
          <button class="chip" onclick="quickSearch('${t.split(' ').slice(1).join(' ')}')">${t}</button>
        `).join('')}
      </div>
    </div>
  </div>
  `

  const scripts = `
  <script>
    const ALL_RESTAURANTS = [
      { id:'1', name:'Burger Palace', cuisine:'American · Burgers', rating:4.5, reviews:1243, time:'20-30', timeParsed:25, fee:2.99, dist:'1.2', price:'$$', veg:false, promo:true, discount:'20% OFF', emoji:'🍔' },
      { id:'2', name:'Pizza Heaven', cuisine:'Italian · Pizza', rating:4.7, reviews:2156, time:'25-35', timeParsed:30, fee:1.99, dist:'0.8', price:'$$', veg:false, promo:false, discount:'Free Delivery', emoji:'🍕' },
      { id:'3', name:'Sushi World', cuisine:'Japanese · Sushi', rating:4.8, reviews:987, time:'30-45', timeParsed:37, fee:3.99, dist:'2.1', price:'$$$', veg:false, promo:true, discount:'15% OFF', emoji:'🍱' },
      { id:'4', name:'Taco Fiesta', cuisine:'Mexican · Tacos', rating:4.3, reviews:654, time:'15-25', timeParsed:20, fee:0, dist:'0.5', price:'$', veg:false, promo:false, discount:'Free Delivery', emoji:'🌮' },
      { id:'5', name:'Green Bowl', cuisine:'Healthy · Salads', rating:4.6, reviews:432, time:'20-30', timeParsed:25, fee:2.49, dist:'1.8', price:'$$', veg:true, promo:false, discount:'10% OFF', emoji:'🥗' },
      { id:'6', name:'Curry House', cuisine:'Indian · Curry', rating:4.7, reviews:1876, time:'30-40', timeParsed:35, fee:1.99, dist:'1.5', price:'$$', veg:false, promo:true, discount:'25% OFF', emoji:'🍛' },
    ];

    let currentFilter = 'all';
    let currentQuery = '';
    let isGrid = true;

    function renderCard(r) {
      return \`
        <div class="card" style="cursor:pointer;overflow:hidden;transition:var(--transition);" onclick="window.location.href='/restaurant/\${r.id}'" onmouseenter="this.style.transform='translateY(-4px)';this.style.boxShadow='var(--shadow-md)'" onmouseleave="this.style.transform='';this.style.boxShadow=''">
          <div style="height:140px;background:linear-gradient(135deg,#1a202c,#2d3748);display:flex;align-items:center;justify-content:center;position:relative;">
            <span style="font-size:56px;">\${r.emoji}</span>
            \${r.promo ? \`<div style="position:absolute;top:10px;left:10px;background:var(--primary-gradient);color:white;padding:3px 8px;border-radius:var(--radius-full);font-size:0.72rem;font-weight:700;">\${r.discount}</div>\` : ''}
            \${r.fee===0 ? \`<div style="position:absolute;top:10px;right:10px;background:rgba(56,161,105,0.9);color:white;padding:3px 8px;border-radius:var(--radius-full);font-size:0.7rem;font-weight:700;">FREE DELIVERY</div>\` : ''}
          </div>
          <div class="card-body">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:6px;">
              <div><h3 style="font-size:0.95rem;margin-bottom:2px;">\${r.name}</h3><p style="font-size:0.78rem;color:var(--text-muted);">\${r.cuisine}</p></div>
              <div style="display:flex;align-items:center;gap:3px;background:rgba(56,161,105,0.1);padding:3px 7px;border-radius:var(--radius-full);">
                <i class="fas fa-star" style="color:#38A169;font-size:11px;"></i>
                <span style="font-size:0.8rem;font-weight:700;color:#38A169;">\${r.rating}</span>
              </div>
            </div>
            <div style="display:flex;gap:10px;font-size:0.75rem;color:var(--text-muted);">
              <span><i class="fas fa-clock" style="color:var(--primary);"></i> \${r.time} min</span>
              <span><i class="fas fa-motorcycle" style="color:var(--info);"></i> \${r.fee===0 ? 'Free' : '$'+r.fee.toFixed(2)}</span>
              <span><i class="fas fa-map-pin" style="color:var(--success);"></i> \${r.dist} km</span>
            </div>
            \${r.veg ? '<div style="margin-top:6px;"><span class="tag tag-success" style="font-size:0.7rem;"><i class="fas fa-leaf"></i> Veg</span></div>' : ''}
          </div>
        </div>
      \`;
    }

    function applyFiltersAndSearch() {
      let data = [...ALL_RESTAURANTS];
      if (currentQuery) {
        data = data.filter(r =>
          r.name.toLowerCase().includes(currentQuery.toLowerCase()) ||
          r.cuisine.toLowerCase().includes(currentQuery.toLowerCase())
        );
      }
      if (currentFilter === 'veg') data = data.filter(r => r.veg);
      else if (currentFilter === 'rating') data = data.filter(r => r.rating >= 4.5);
      else if (currentFilter === 'fast') data = data.filter(r => r.timeParsed <= 30);
      else if (currentFilter === 'free') data = data.filter(r => r.fee === 0);
      else if (currentFilter === 'budget') data = data.filter(r => r.price === '$');
      else if (currentFilter === 'promo') data = data.filter(r => r.promo);
      else if (currentFilter === 'near') data = data.filter(r => parseFloat(r.dist) <= 1.5);

      const grid = document.getElementById('search-grid');
      const noRes = document.getElementById('no-results');
      const countEl = document.getElementById('search-count');
      const popSection = document.getElementById('popular-section');

      if (data.length === 0) {
        grid.innerHTML = '';
        noRes.style.display = 'block';
        countEl.innerHTML = 'Showing <strong>0</strong> results';
      } else {
        noRes.style.display = 'none';
        grid.innerHTML = data.map(renderCard).join('');
        countEl.innerHTML = 'Showing <strong>' + data.length + '</strong> results';
      }
      if (currentQuery || currentFilter !== 'all') {
        popSection.style.display = 'none';
      } else {
        popSection.style.display = '';
      }
    }

    function performSearch(q) {
      currentQuery = q;
      document.getElementById('clear-search').style.display = q ? 'block' : 'none';
      applyFiltersAndSearch();
    }

    function clearSearch() {
      currentQuery = '';
      document.getElementById('search-input').value = '';
      document.getElementById('clear-search').style.display = 'none';
      applyFiltersAndSearch();
    }

    function setFilter(f) {
      currentFilter = f;
      document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
      document.getElementById('f-' + f)?.classList.add('active');
      applyFiltersAndSearch();
    }

    function clearAll() {
      clearSearch();
      setFilter('all');
    }

    function quickSearch(q) {
      document.getElementById('search-input').value = q;
      performSearch(q);
    }

    function sortResults(val) {
      const grid = document.getElementById('search-grid');
      let data = [...ALL_RESTAURANTS];
      if (val === 'rating') data.sort((a,b) => b.rating - a.rating);
      else if (val === 'time') data.sort((a,b) => a.timeParsed - b.timeParsed);
      else if (val === 'distance') data.sort((a,b) => parseFloat(a.dist) - parseFloat(b.dist));
      else if (val === 'fee') data.sort((a,b) => a.fee - b.fee);
      grid.innerHTML = data.map(renderCard).join('');
    }

    function toggleView() {
      isGrid = !isGrid;
      const grid = document.getElementById('search-grid');
      const icon = document.getElementById('view-icon');
      if (isGrid) {
        grid.className = 'grid-3';
        icon.className = 'fas fa-th-large';
      } else {
        grid.className = '';
        grid.style.display = 'flex';
        grid.style.flexDirection = 'column';
        grid.style.gap = '12px';
        icon.className = 'fas fa-th-list';
      }
    }

    // Init
    document.addEventListener('DOMContentLoaded', () => {
      const urlParams = new URLSearchParams(window.location.search);
      const q = urlParams.get('q');
      if (q) {
        document.getElementById('search-input').value = q;
        performSearch(q);
      } else {
        applyFiltersAndSearch();
      }
    });
  </script>
  `

  return pageShell('Search Restaurants', content, 'search', scripts)
}
