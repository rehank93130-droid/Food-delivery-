/**
 * QuickBite - Checkout Page
 * Payment options: UPI, Card, COD + order confirmation
 */
import { pageShell } from './layout'

export function renderCheckout(): string {
  const content = `
  <div class="container" style="padding-top:24px;padding-bottom:40px;">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px;">
      <button onclick="history.back()" style="width:36px;height:36px;border-radius:50%;border:1.5px solid var(--border);background:var(--surface);cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--text);transition:var(--transition);" onmouseenter="this.style.background='var(--surface-2)'" onmouseleave="this.style.background='var(--surface)'">
        <i class="fas fa-arrow-left"></i>
      </button>
      <h2 style="font-size:1.4rem;">Checkout</h2>
    </div>

    <!-- Progress Steps -->
    <div style="display:flex;align-items:center;justify-content:center;margin-bottom:32px;gap:0;">
      ${[['fa-shopping-cart','Cart'],['fa-credit-card','Payment'],['fa-check','Confirm']].map((step, i) => `
        <div style="display:flex;align-items:center;">
          <div style="display:flex;flex-direction:column;align-items:center;gap:4px;">
            <div style="width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;background:${i <= 1 ? 'var(--primary-gradient)' : 'var(--surface-2)'};color:${i <= 1 ? 'white' : 'var(--text-muted)'};box-shadow:${i <= 1 ? '0 2px 8px rgba(229,62,62,0.3)' : 'none'};">
              <i class="fas ${step[0]}"></i>
            </div>
            <span style="font-size:0.72rem;font-weight:600;color:${i <= 1 ? 'var(--primary)' : 'var(--text-muted)'};">${step[1]}</span>
          </div>
          ${i < 2 ? `<div style="width:60px;height:2px;background:${i === 0 ? 'var(--primary)' : 'var(--border)'};margin:0 8px;margin-bottom:20px;"></div>` : ''}
        </div>
      `).join('')}
    </div>

    <div style="display:grid;grid-template-columns:1fr 360px;gap:24px;" id="checkout-layout">
      <!-- Left: Payment Form -->
      <div>
        <!-- Delivery Address Summary -->
        <div class="card" style="margin-bottom:16px;">
          <div class="card-body">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
              <h4 style="display:flex;align-items:center;gap:8px;"><i class="fas fa-map-marker-alt" style="color:var(--primary);"></i>Delivering to</h4>
              <a href="/cart" style="font-size:0.82rem;color:var(--primary);font-weight:600;">Change</a>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
              <div style="width:36px;height:36px;border-radius:var(--radius-sm);background:rgba(229,62,62,0.1);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <i class="fas fa-home" style="color:var(--primary);"></i>
              </div>
              <div>
                <p style="font-weight:600;font-size:0.875rem;">Home</p>
                <p style="font-size:0.8rem;color:var(--text-muted);">123 Main St, Apt 4B, New York, NY 10001</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Payment Methods -->
        <div class="card">
          <div class="card-body">
            <h4 style="margin-bottom:20px;display:flex;align-items:center;gap:8px;"><i class="fas fa-lock" style="color:var(--primary);"></i>Payment Method</h4>

            <!-- Payment Tabs -->
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:24px;">
              ${[
                { id:'upi', label:'UPI', icon:'fas fa-mobile-alt', sub:'Instant payment' },
                { id:'card', label:'Card', icon:'far fa-credit-card', sub:'Debit/Credit' },
                { id:'cod', label:'Cash on Delivery', icon:'fas fa-money-bill-wave', sub:'Pay at door' },
              ].map((pm, i) => `
                <button id="pm-${pm.id}" onclick="selectPayment('${pm.id}')"
                  style="padding:12px 8px;border-radius:var(--radius);border:1.5px solid ${i === 0 ? 'var(--primary)' : 'var(--border)'};background:${i === 0 ? 'rgba(229,62,62,0.05)' : 'var(--surface)'};cursor:pointer;transition:var(--transition);display:flex;flex-direction:column;align-items:center;gap:6px;">
                  <i class="${pm.icon}" style="font-size:22px;color:${i === 0 ? 'var(--primary)' : 'var(--text-muted)'};" id="pm-icon-${pm.id}"></i>
                  <span style="font-size:0.8rem;font-weight:700;color:${i === 0 ? 'var(--primary)' : 'var(--text)'};" id="pm-label-${pm.id}">${pm.label}</span>
                  <span style="font-size:0.68rem;color:var(--text-muted);">${pm.sub}</span>
                </button>
              `).join('')}
            </div>

            <!-- UPI Form -->
            <div id="form-upi">
              <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:20px;">
                ${[
                  { icon:'https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/googlepay.svg', name:'Google Pay', color:'#1A73E8', id:'gpay' },
                  { icon:'https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/phonepe.svg', name:'PhonePe', color:'#6739B7', id:'phonepe' },
                  { icon:'https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/paytm.svg', name:'Paytm', color:'#002970', id:'paytm' },
                ].map((upi, i) => `
                  <label style="display:flex;align-items:center;gap:12px;padding:14px;border-radius:var(--radius);border:1.5px solid ${i === 0 ? 'var(--primary)' : 'var(--border)'};cursor:pointer;transition:var(--transition);background:${i === 0 ? 'rgba(229,62,62,0.02)' : 'var(--surface)'};" onclick="selectUPI('${upi.id}',this)">
                    <input type="radio" name="upi-app" value="${upi.id}" ${i === 0 ? 'checked' : ''} style="accent-color:var(--primary);">
                    <div style="width:36px;height:36px;border-radius:var(--radius-sm);background:#f5f5f5;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">💳</div>
                    <span style="font-weight:600;font-size:0.875rem;">${upi.name}</span>
                    ${i === 0 ? '<span class="tag tag-success" style="margin-left:auto;font-size:0.7rem;">Recommended</span>' : ''}
                  </label>
                `).join('')}
              </div>
              <div class="form-group">
                <label class="form-label">Or enter UPI ID</label>
                <div class="input-group">
                  <i class="fas fa-at input-icon"></i>
                  <input type="text" class="form-input" placeholder="yourname@upi" id="upi-id">
                </div>
              </div>
            </div>

            <!-- Card Form -->
            <div id="form-card" style="display:none;">
              <div class="form-group">
                <label class="form-label">Card Number</label>
                <div class="input-group">
                  <i class="far fa-credit-card input-icon"></i>
                  <input type="text" class="form-input" placeholder="1234 5678 9012 3456" id="card-number" maxlength="19" oninput="formatCard(this)">
                  <span style="position:absolute;right:14px;top:50%;transform:translateY(-50%);" id="card-type-icon">💳</span>
                </div>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group">
                  <label class="form-label">Expiry Date</label>
                  <input type="text" class="form-input" placeholder="MM / YY" id="card-expiry" maxlength="7" oninput="formatExpiry(this)">
                </div>
                <div class="form-group">
                  <label class="form-label">CVV</label>
                  <div class="input-group">
                    <input type="password" class="form-input" placeholder="•••" id="card-cvv" maxlength="4">
                    <i class="fas fa-question-circle input-icon-right" onclick="QB.showToast('CVV is the 3-4 digit code on back of your card','info')"></i>
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Cardholder Name</label>
                <input type="text" class="form-input" placeholder="John Doe" id="card-name">
              </div>
              <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer;color:var(--text-secondary);">
                <input type="checkbox" style="accent-color:var(--primary);"> Save card for future payments
              </label>
            </div>

            <!-- COD Form -->
            <div id="form-cod" style="display:none;">
              <div style="background:rgba(56,161,105,0.08);border-radius:var(--radius-lg);padding:20px;text-align:center;border:1px solid rgba(56,161,105,0.2);">
                <div style="font-size:48px;margin-bottom:12px;">💵</div>
                <h4 style="margin-bottom:8px;color:var(--success);">Cash on Delivery</h4>
                <p style="font-size:0.875rem;color:var(--text-secondary);">Keep the exact amount ready when the delivery arrives at your doorstep.</p>
                <div style="display:flex;justify-content:center;gap:16px;margin-top:16px;flex-wrap:wrap;">
                  <span style="font-size:0.78rem;color:var(--text-muted);display:flex;align-items:center;gap:4px;"><i class="fas fa-check-circle" style="color:var(--success);"></i> No extra charges</span>
                  <span style="font-size:0.78rem;color:var(--text-muted);display:flex;align-items:center;gap:4px;"><i class="fas fa-check-circle" style="color:var(--success);"></i> Pay at delivery</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Right: Order Summary -->
      <div>
        <div style="position:sticky;top:80px;">
          <div class="card">
            <div class="card-body">
              <h3 style="margin-bottom:16px;font-size:1rem;"><i class="fas fa-receipt" style="color:var(--primary);margin-right:8px;"></i>Order Summary</h3>

              <!-- Items List -->
              <div id="checkout-items" style="max-height:220px;overflow-y:auto;margin-bottom:16px;">
                <!-- Populated by JS -->
              </div>

              <div style="border-top:1px solid var(--border);padding-top:12px;">
                <div style="display:flex;justify-content:space-between;font-size:0.82rem;color:var(--text-secondary);margin-bottom:6px;">
                  <span>Subtotal</span><span id="co-subtotal">$0.00</span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:0.82rem;color:var(--text-secondary);margin-bottom:6px;">
                  <span>Delivery fee</span><span id="co-delivery">$2.99</span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:0.82rem;color:var(--text-secondary);margin-bottom:6px;">
                  <span>Tax (8%)</span><span id="co-tax">$0.00</span>
                </div>
                <div id="co-discount-row" style="display:none;flex-direction:row;justify-content:space-between;font-size:0.82rem;color:var(--success);margin-bottom:6px;">
                  <span><i class="fas fa-tag"></i> Promo</span><span id="co-discount">-$0.00</span>
                </div>
                <div style="display:flex;justify-content:space-between;font-weight:700;font-size:1rem;padding-top:10px;border-top:1px solid var(--border);color:var(--text);">
                  <span>Total</span><span id="co-total" style="color:var(--primary);">$0.00</span>
                </div>
              </div>

              <!-- Estimated Time -->
              <div style="margin-top:16px;padding:12px;background:rgba(49,130,206,0.08);border-radius:var(--radius);border:1px solid rgba(49,130,206,0.2);display:flex;align-items:center;gap:10px;">
                <i class="fas fa-clock" style="color:var(--info);font-size:20px;"></i>
                <div>
                  <p style="font-size:0.78rem;font-weight:600;color:var(--info);">Estimated Delivery</p>
                  <p style="font-size:0.82rem;color:var(--text-secondary);">25-35 minutes from order</p>
                </div>
              </div>

              <button class="btn btn-success btn-full btn-lg" style="margin-top:16px;" onclick="placeOrder()">
                <i class="fas fa-check-circle"></i> Place Order
              </button>

              <p style="font-size:0.72rem;color:var(--text-muted);text-align:center;margin-top:10px;">
                <i class="fas fa-shield-alt" style="color:var(--success);"></i>
                Your payment is 100% secure & encrypted
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Order Success Modal -->
  <div class="modal-overlay" id="success-modal">
    <div class="modal">
      <div class="modal-body" style="text-align:center;padding:40px;">
        <div style="width:80px;height:80px;background:linear-gradient(135deg,#38A169,#2F855A);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;box-shadow:0 8px 24px rgba(56,161,105,0.4);animation:bounceIn 0.5s ease;">
          <i class="fas fa-check" style="color:white;font-size:32px;"></i>
        </div>
        <h2 style="color:var(--success);margin-bottom:8px;">Order Placed! 🎉</h2>
        <p style="margin-bottom:8px;">Your order has been confirmed.</p>
        <div style="background:var(--surface-2);border-radius:var(--radius);padding:14px;margin:16px 0;">
          <p style="font-size:0.8rem;color:var(--text-muted);">Order ID</p>
          <p style="font-size:1.2rem;font-weight:800;color:var(--primary);" id="order-id-display">QB000000</p>
        </div>
        <p style="font-size:0.875rem;color:var(--text-secondary);margin-bottom:20px;">
          Estimated delivery: <strong id="delivery-time-display">30</strong> minutes
        </p>
        <button class="btn btn-primary btn-full btn-lg" onclick="trackOrder()">
          <i class="fas fa-map-marker-alt"></i> Track Your Order
        </button>
        <button class="btn btn-ghost btn-full" style="margin-top:8px;" onclick="window.location.href='/'">
          Continue Shopping
        </button>
      </div>
    </div>
  </div>
  `

  const scripts = `
  <script>
    let selectedPayment = 'upi';

    function selectPayment(type) {
      selectedPayment = type;
      ['upi','card','cod'].forEach(t => {
        const btn = document.getElementById('pm-' + t);
        const icon = document.getElementById('pm-icon-' + t);
        const label = document.getElementById('pm-label-' + t);
        const active = t === type;
        btn.style.borderColor = active ? 'var(--primary)' : 'var(--border)';
        btn.style.background = active ? 'rgba(229,62,62,0.05)' : 'var(--surface)';
        if (icon) icon.style.color = active ? 'var(--primary)' : 'var(--text-muted)';
        if (label) label.style.color = active ? 'var(--primary)' : 'var(--text)';
        document.getElementById('form-' + t).style.display = active ? 'block' : 'none';
      });
    }

    function selectUPI(id, el) {
      document.querySelectorAll('[name="upi-app"]').forEach(r => {
        const parent = r.parentElement;
        parent.style.borderColor = 'var(--border)';
        parent.style.background = 'var(--surface)';
      });
      el.style.borderColor = 'var(--primary)';
      el.style.background = 'rgba(229,62,62,0.02)';
    }

    function formatCard(input) {
      let val = input.value.replace(/\\D/g,'').substring(0,16);
      input.value = val.replace(/(\\d{4})/g,'$1 ').trim();
      const icon = document.getElementById('card-type-icon');
      if (val.startsWith('4')) icon.textContent = '💳 Visa';
      else if (val.startsWith('5')) icon.textContent = '💳 MC';
      else if (val.startsWith('3')) icon.textContent = '💳 Amex';
      else icon.textContent = '💳';
    }

    function formatExpiry(input) {
      let val = input.value.replace(/\\D/g,'');
      if (val.length >= 2) val = val.substring(0,2) + ' / ' + val.substring(2,4);
      input.value = val;
    }

    function renderCheckoutItems() {
      const cart = QB.cart;
      const el = document.getElementById('checkout-items');
      if (!el) return;
      if (cart.length === 0) {
        window.location.href = '/cart';
        return;
      }
      el.innerHTML = cart.map(item => \`
        <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border);">
          <span style="font-size:22px;">\${item.image}</span>
          <div style="flex:1;min-width:0;">
            <p style="font-size:0.82rem;font-weight:600;color:var(--text);">\${item.name}</p>
            <p style="font-size:0.75rem;color:var(--text-muted);">x\${item.qty}</p>
          </div>
          <span style="font-weight:700;font-size:0.82rem;color:var(--text);">$\${(item.price * item.qty).toFixed(2)}</span>
        </div>
      \`).join('');

      const subtotal = QB.cartTotal;
      const deliveryFee = parseFloat(localStorage.getItem('qb_delivery_fee') || '2.99');
      const discount = subtotal * (parseFloat(localStorage.getItem('qb_promo_discount') || '0') / 100);
      const tax = subtotal * 0.08;
      const total = subtotal + deliveryFee + tax - discount;

      document.getElementById('co-subtotal').textContent = '$' + subtotal.toFixed(2);
      document.getElementById('co-delivery').textContent = '$' + deliveryFee.toFixed(2);
      document.getElementById('co-tax').textContent = '$' + tax.toFixed(2);
      document.getElementById('co-total').textContent = '$' + total.toFixed(2);

      if (discount > 0) {
        document.getElementById('co-discount-row').style.display = 'flex';
        document.getElementById('co-discount').textContent = '-$' + discount.toFixed(2);
      }
    }

    async function placeOrder() {
      if (selectedPayment === 'card') {
        const num = document.getElementById('card-number').value.replace(/\\s/g,'');
        if (num.length < 16) { QB.showToast('Please enter a valid card number', 'error'); return; }
        const cvv = document.getElementById('card-cvv').value;
        if (cvv.length < 3) { QB.showToast('Please enter a valid CVV', 'error'); return; }
      }

      const btn = document.querySelector('[onclick="placeOrder()"]');
      btn.innerHTML = '<div class="spinner" style="width:20px;height:20px;border-width:2px;"></div> Processing...';
      btn.disabled = true;

      try {
        const res = await fetch('/api/orders', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({ items: QB.cart, paymentMethod: selectedPayment })
        });
        const data = await res.json();

        if (data.success) {
          localStorage.setItem('qb_last_order', data.orderId);
          localStorage.setItem('qb_order_time', Date.now());
          document.getElementById('order-id-display').textContent = data.orderId;
          document.getElementById('delivery-time-display').textContent = data.estimatedTime;
          openModal('success-modal');
          QB.clearCart();
        }
      } catch (e) {
        // Demo fallback
        const orderId = 'QB' + Date.now().toString().slice(-6);
        localStorage.setItem('qb_last_order', orderId);
        localStorage.setItem('qb_order_time', Date.now());
        document.getElementById('order-id-display').textContent = orderId;
        document.getElementById('delivery-time-display').textContent = '28';
        openModal('success-modal');
        QB.clearCart();
      }
    }

    function trackOrder() {
      const orderId = localStorage.getItem('qb_last_order') || '';
      window.location.href = '/tracking/' + orderId;
    }

    document.addEventListener('DOMContentLoaded', () => {
      renderCheckoutItems();
      if (window.innerWidth <= 768) {
        document.getElementById('checkout-layout').style.gridTemplateColumns = '1fr';
      }
    });
    window.addEventListener('resize', () => {
      const cl = document.getElementById('checkout-layout');
      if (cl) cl.style.gridTemplateColumns = window.innerWidth <= 768 ? '1fr' : '1fr 360px';
    });
  </script>
  `

  return pageShell('Checkout', content, 'checkout', scripts)
}
