/**
 * QuickBite - Home Page
 * Hero section, categories, featured & all restaurants, banners
 */
import { pageShell } from './layout'

const RESTAURANTS = [
  { id:'1', name:'Burger Palace', cuisine:'American · Burgers', rating:4.5, reviews:1243, time:'20-30 min', fee:2.99, dist:'1.2 km', price:'$$', veg:false, promo:true, discount:'20% OFF', emoji:'🍔', tags:['Fast Food','Trending'] },
  { id:'2', name:'Pizza Heaven', cuisine:'Italian · Pizza', rating:4.7, reviews:2156, time:'25-35 min', fee:1.99, dist:'0.8 km', price:'$$', veg:false, promo:false, discount:'Free Delivery', emoji:'🍕', tags:['Popular'] },
  { id:'3', name:'Sushi World', cuisine:'Japanese · Sushi', rating:4.8, reviews:987, time:'30-45 min', fee:3.99, dist:'2.1 km', price:'$$$', veg:false, promo:true, discount:'15% OFF', emoji:'🍱', tags:['Premium','Healthy'] },
  { id:'4', name:'Taco Fiesta', cuisine:'Mexican · Tacos', rating:4.3, reviews:654, time:'15-25 min', fee:0, dist:'0.5 km', price:'$', veg:false, promo:false, discount:'Free Delivery', emoji:'🌮', tags:['Fast Delivery'] },
  { id:'5', name:'Green Bowl', cuisine:'Healthy · Salads', rating:4.6, reviews:432, time:'20-30 min', fee:2.49, dist:'1.8 km', price:'$$', veg:true, promo:false, discount:'10% OFF', emoji:'🥗', tags:['Vegan','Healthy'] },
  { id:'6', name:'Curry House', cuisine:'Indian · Curry', rating:4.7, reviews:1876, time:'30-40 min', fee:1.99, dist:'1.5 km', price:'$$', veg:false, promo:true, discount:'25% OFF', emoji:'🍛', tags:['Spicy','Trending'] },
]

const CATEGORIES = [
  { name:'Burgers', emoji:'🍔', color:'#FF6B35' },
  { name:'Pizza', emoji:'🍕', color:'#E53E3E' },
  { name:'Sushi', emoji:'🍣', color:'#3182CE' },
  { name:'Tacos', emoji:'🌮', color:'#D69E2E' },
  { name:'Healthy', emoji:'🥗', color:'#38A169' },
  { name:'Curry', emoji:'🍛', color:'#805AD5' },
  { name:'Noodles', emoji:'🍜', color:'#DD6B20' },
  { name:'Desserts', emoji:'🍰', color:'#D53F8C' },
  { name:'Drinks', emoji:'🧋', color:'#0694A2' },
  { name:'Chicken', emoji:'🍗', color:'#C05621' },
]

function renderRestaurantCard(r: typeof RESTAURANTS[0], featured = false): string {
  return `
    <div class="card restaurant-card slide-up" style="cursor:pointer;" onclick="window.location.href='/restaurant/${r.id}'">
      <!-- Image Area -->
      <div style="position:relative;height:${featured ? '180px' : '160px'};background:linear-gradient(135deg, #1a202c 0%, #2d3748 100%);display:flex;align-items:center;justify-content:center;overflow:hidden;">
        <span style="font-size:${featured ? '72px' : '60px'};filter:drop-shadow(0 4px 12px rgba(0,0,0,0.3));transition:transform 0.3s;" class="rest-emoji">${r.emoji}</span>
        ${r.promo ? `<div style="position:absolute;top:12px;left:12px;background:var(--primary-gradient);color:white;padding:4px 10px;border-radius:var(--radius-full);font-size:0.75rem;font-weight:700;box-shadow:0 2px 8px rgba(229,62,62,0.4);">${r.discount}</div>` : ''}
        ${r.fee === 0 ? `<div style="position:absolute;top:12px;right:12px;background:rgba(56,161,105,0.9);color:white;padding:4px 10px;border-radius:var(--radius-full);font-size:0.72rem;font-weight:700;">FREE DELIVERY</div>` : ''}
        <button onclick="event.stopPropagation();toggleFavorite('${r.id}',this)" style="position:absolute;bottom:12px;right:12px;width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,0.15);backdrop-filter:blur(8px);border:none;color:white;font-size:15px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:var(--transition);" id="fav-${r.id}">
          <i class="far fa-heart"></i>
        </button>
      </div>
      <!-- Info -->
      <div class="card-body">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:6px;">
          <div>
            <h3 style="font-size:1rem;margin-bottom:2px;">${r.name}</h3>
            <p style="font-size:0.8rem;color:var(--text-muted);">${r.cuisine}</p>
          </div>
          <div style="display:flex;align-items:center;gap:4px;background:${r.rating >= 4.5 ? 'rgba(56,161,105,0.1)' : 'rgba(214,158,46,0.1)'};padding:3px 8px;border-radius:var(--radius-full);flex-shrink:0;">
            <i class="fas fa-star" style="color:${r.rating >= 4.5 ? '#38A169' : '#D69E2E'};font-size:12px;"></i>
            <span style="font-size:0.82rem;font-weight:700;color:${r.rating >= 4.5 ? '#38A169' : '#D69E2E'};">${r.rating}</span>
            <span style="font-size:0.75rem;color:var(--text-muted);">(${r.reviews >= 1000 ? (r.reviews/1000).toFixed(1)+'k' : r.reviews})</span>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:12px;font-size:0.78rem;color:var(--text-muted);">
          <span><i class="fas fa-clock" style="color:var(--primary);margin-right:3px;"></i>${r.time}</span>
          <span><i class="fas fa-motorcycle" style="color:var(--info);margin-right:3px;"></i>${r.fee === 0 ? 'Free' : '$'+r.fee.toFixed(2)}</span>
          <span><i class="fas fa-map-marker-alt" style="color:var(--success);margin-right:3px;"></i>${r.dist}</span>
        </div>
        <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap;">
          ${r.veg ? '<span class="tag tag-success"><i class="fas fa-leaf"></i> Veg</span>' : ''}
          ${r.tags.slice(0,2).map(t => `<span class="tag">${t}</span>`).join('')}
        </div>
      </div>
    </div>
  `
}

export function renderHome(): string {
  const content = `
  <div class="container">
    <!-- Hero Section -->
    <div style="padding:32px 0 24px;" class="fade-in">
      <div style="background:var(--primary-gradient);border-radius:var(--radius-xl);padding:32px;position:relative;overflow:hidden;margin-bottom:8px;">
        <!-- Background decoration -->
        <div style="position:absolute;right:-20px;bottom:-20px;font-size:150px;opacity:0.15;transform:rotate(-15deg);pointer-events:none;">🍔</div>
        <div style="position:absolute;right:160px;top:-30px;font-size:80px;opacity:0.1;transform:rotate(20deg);pointer-events:none;">🍕</div>
        <div style="position:relative;z-index:1;max-width:600px;">
          <div style="display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,0.2);padding:4px 12px;border-radius:var(--radius-full);font-size:0.78rem;font-weight:600;color:white;margin-bottom:12px;">
            <i class="fas fa-bolt"></i> Fast delivery in 30 mins!
          </div>
          <h1 id="hero-greeting" style="color:white;font-size:clamp(1.6rem,4vw,2.2rem);margin-bottom:8px;line-height:1.2;">
            Order your favorite food! 🍔
          </h1>
          <p style="color:rgba(255,255,255,0.85);margin-bottom:20px;font-size:0.95rem;">
            Discover the best restaurants near you with lightning-fast delivery
          </p>
          <div style="display:flex;gap:12px;flex-wrap:wrap;">
            <button class="btn" style="background:white;color:var(--primary);font-weight:700;" onclick="document.getElementById('restaurants-section').scrollIntoView({behavior:'smooth'})">
              <i class="fas fa-utensils"></i> Order Now
            </button>
            <button class="btn" style="background:rgba(255,255,255,0.2);color:white;border:2px solid rgba(255,255,255,0.5);" onclick="window.location.href='/search'">
              <i class="fas fa-search"></i> Search Food
            </button>
          </div>
        </div>
        <div style="position:absolute;right:24px;top:50%;transform:translateY(-50%);font-size:100px;display:none;" id="hero-emoji" class="d-md-block">🛵</div>
      </div>

      <!-- Stats Bar -->
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:16px;">
        ${[
          { icon:'fa-store', label:'Restaurants', val:'200+', color:'var(--primary)' },
          { icon:'fa-utensils', label:'Menu Items', val:'5000+', color:'var(--info)' },
          { icon:'fa-star', label:'Avg Rating', val:'4.6★', color:'var(--warning)' },
          { icon:'fa-clock', label:'Avg Delivery', val:'28 min', color:'var(--success)' },
        ].map(s => `
          <div style="background:var(--surface);border-radius:var(--radius);padding:14px;text-align:center;border:1px solid var(--border);box-shadow:var(--shadow-sm);">
            <i class="fas ${s.icon}" style="color:${s.color};font-size:20px;margin-bottom:6px;display:block;"></i>
            <div style="font-size:1rem;font-weight:800;color:var(--text);">${s.val}</div>
            <div style="font-size:0.72rem;color:var(--text-muted);">${s.label}</div>
          </div>
        `).join('')}
      </div>
    </div>

    <!-- Promotional Banners -->
    <div style="display:flex;gap:12px;overflow-x:auto;padding-bottom:4px;scrollbar-width:none;margin-bottom:8px;" class="slide-up stagger-1">
      ${[
        { bg:'linear-gradient(135deg,#667eea,#764ba2)', title:'🎉 Get 50% OFF', sub:'on your first order!', code:'FIRST50' },
        { bg:'linear-gradient(135deg,#f093fb,#f5576c)', title:'🚀 Free Delivery', sub:'Orders above $20', code:'FREEDEL' },
        { bg:'linear-gradient(135deg,#4facfe,#00f2fe)', title:'🍕 Buy 2 Get 1', sub:'On selected pizzas', code:'PIZZA21' },
      ].map(b => `
        <div style="min-width:260px;background:${b.bg};border-radius:var(--radius-lg);padding:16px 20px;cursor:pointer;flex-shrink:0;position:relative;overflow:hidden;" onclick="copyPromo('${b.code}')">
          <h4 style="color:white;font-size:1rem;margin-bottom:4px;">${b.title}</h4>
          <p style="color:rgba(255,255,255,0.85);font-size:0.8rem;margin-bottom:8px;">${b.sub}</p>
          <div style="display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,0.25);padding:4px 10px;border-radius:var(--radius-full);font-size:0.78rem;font-weight:700;color:white;">
            <i class="fas fa-tag"></i> ${b.code}
            <i class="fas fa-copy" style="font-size:10px;"></i>
          </div>
          <div style="position:absolute;right:-10px;bottom:-10px;font-size:60px;opacity:0.2;">🎁</div>
        </div>
      `).join('')}
    </div>

    <!-- Food Categories -->
    <div class="slide-up stagger-2">
      <div class="section-header">
        <h2><i class="fas fa-th-large" style="color:var(--primary);margin-right:8px;"></i>What's on your mind?</h2>
        <span class="see-all" onclick="window.location.href='/search'">See all →</span>
      </div>
      <div style="display:flex;gap:12px;overflow-x:auto;padding-bottom:8px;scrollbar-width:none;">
        ${CATEGORIES.map(cat => `
          <div style="flex-shrink:0;text-align:center;cursor:pointer;" onclick="filterByCategory('${cat.name}')">
            <div style="width:72px;height:72px;border-radius:var(--radius-lg);background:${cat.color}20;border:2px solid ${cat.color}30;display:flex;align-items:center;justify-content:center;font-size:28px;margin-bottom:6px;transition:var(--transition);box-shadow:0 2px 8px ${cat.color}20;" class="cat-icon" onmouseenter="this.style.transform='scale(1.1)';this.style.boxShadow='0 6px 20px ${cat.color}40';" onmouseleave="this.style.transform='';this.style.boxShadow='0 2px 8px ${cat.color}20';">
              ${cat.emoji}
            </div>
            <p style="font-size:0.72rem;font-weight:600;color:var(--text-secondary);white-space:nowrap;">${cat.name}</p>
          </div>
        `).join('')}
      </div>
    </div>

    <!-- Filter Bar -->
    <div id="restaurants-section" class="slide-up stagger-3">
      <div class="section-header" style="flex-wrap:wrap;gap:12px;">
        <h2><i class="fas fa-fire" style="color:var(--primary);margin-right:8px;"></i>Nearby Restaurants</h2>
      </div>
      <div style="display:flex;gap:8px;overflow-x:auto;padding-bottom:12px;scrollbar-width:none;margin-bottom:20px;">
        <button class="chip active" id="filter-all" onclick="filterRestaurants('all')"><i class="fas fa-border-all"></i> All</button>
        <button class="chip" id="filter-veg" onclick="filterRestaurants('veg')"><i class="fas fa-leaf" style="color:#38A169;"></i> Pure Veg</button>
        <button class="chip" id="filter-rating" onclick="filterRestaurants('rating')"><i class="fas fa-star" style="color:#D69E2E;"></i> Top Rated</button>
        <button class="chip" id="filter-fast" onclick="filterRestaurants('fast')"><i class="fas fa-bolt" style="color:#DD6B20;"></i> Fast Delivery</button>
        <button class="chip" id="filter-free" onclick="filterRestaurants('free')"><i class="fas fa-motorcycle" style="color:#3182CE;"></i> Free Delivery</button>
        <button class="chip" id="filter-budget" onclick="filterRestaurants('budget')"><i class="fas fa-dollar-sign" style="color:#38A169;"></i> Budget</button>
        <button class="chip" id="filter-promo" onclick="filterRestaurants('promo')"><i class="fas fa-percent" style="color:var(--primary);"></i> Offers</button>
      </div>

      <!-- Sort bar -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:8px;">
        <p style="font-size:0.85rem;color:var(--text-muted);" id="results-count">Showing <strong>${RESTAURANTS.length}</strong> restaurants</p>
        <div style="display:flex;align-items:center;gap:8px;">
          <span style="font-size:0.82rem;color:var(--text-muted);">Sort:</span>
          <select id="sort-select" class="form-input" style="padding:6px 12px;font-size:0.82rem;width:auto;" onchange="sortRestaurants(this.value)">
            <option value="relevance">Relevance</option>
            <option value="rating">Rating</option>
            <option value="time">Delivery Time</option>
            <option value="fee">Delivery Fee</option>
          </select>
        </div>
      </div>

      <!-- Restaurant Grid -->
      <div class="grid-3" id="restaurants-grid">
        ${RESTAURANTS.map(r => renderRestaurantCard(r)).join('')}
      </div>

      <!-- No results -->
      <div id="no-results" style="display:none;text-align:center;padding:60px 20px;">
        <div style="font-size:60px;margin-bottom:16px;">🔍</div>
        <h3 style="margin-bottom:8px;">No restaurants found</h3>
        <p style="color:var(--text-muted);">Try different filters</p>
        <button class="btn btn-primary" style="margin-top:16px;" onclick="filterRestaurants('all')">Show All</button>
      </div>
    </div>

    <!-- Recently Viewed -->
    <div class="slide-up stagger-4">
      <div class="section-header">
        <h2><i class="fas fa-history" style="color:var(--primary);margin-right:8px;"></i>Recently Ordered</h2>
      </div>
      <div style="display:flex;gap:12px;overflow-x:auto;padding-bottom:8px;scrollbar-width:none;">
        ${[
          { name:'Butter Chicken', rest:'Curry House', price:'$14.99', emoji:'🍛', rating:4.9 },
          { name:'Pepperoni Pizza', rest:'Pizza Heaven', price:'$14.99', emoji:'🍕', rating:4.9 },
          { name:'Classic Burger', rest:'Burger Palace', price:'$8.99', emoji:'🍔', rating:4.6 },
          { name:'California Roll', rest:'Sushi World', price:'$12.99', emoji:'🍱', rating:4.7 },
        ].map(item => `
          <div style="flex-shrink:0;width:160px;background:var(--surface);border-radius:var(--radius-lg);overflow:hidden;border:1px solid var(--border);cursor:pointer;transition:var(--transition);" onmouseenter="this.style.transform='translateY(-4px)';this.style.boxShadow='var(--shadow-md)';" onmouseleave="this.style.transform='';this.style.boxShadow='';" onclick="QB.showToast('Opening ${item.rest}...','info');setTimeout(()=>window.location.href='/restaurant/1',500)">
            <div style="height:90px;background:linear-gradient(135deg,#1a202c,#2d3748);display:flex;align-items:center;justify-content:center;font-size:44px;">${item.emoji}</div>
            <div style="padding:10px;">
              <p style="font-size:0.82rem;font-weight:700;color:var(--text);margin-bottom:2px;">${item.name}</p>
              <p style="font-size:0.72rem;color:var(--text-muted);">${item.rest}</p>
              <div style="display:flex;align-items:center;justify-content:space-between;margin-top:6px;">
                <span style="font-size:0.8rem;font-weight:700;color:var(--primary);">${item.price}</span>
                <span style="font-size:0.72rem;color:#D69E2E;"><i class="fas fa-star"></i> ${item.rating}</span>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>

    <!-- App Download Banner -->
    <div style="background:var(--surface);border-radius:var(--radius-xl);border:1px solid var(--border);padding:24px;margin:24px 0;display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;">
      <div>
        <h3 style="margin-bottom:6px;">📱 Get the QuickBite App</h3>
        <p style="font-size:0.875rem;color:var(--text-secondary);margin-bottom:12px;">Get exclusive app-only deals and track your orders in real-time!</p>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          <button class="btn btn-ghost" style="border:1.5px solid var(--border);" onclick="QB.showToast('App Store link coming soon!','info')">
            <i class="fab fa-apple"></i> App Store
          </button>
          <button class="btn btn-ghost" style="border:1.5px solid var(--border);" onclick="QB.showToast('Play Store link coming soon!','info')">
            <i class="fab fa-google-play" style="color:#01875F;"></i> Google Play
          </button>
        </div>
      </div>
      <div style="font-size:80px;opacity:0.7;">📲</div>
    </div>

    <div style="height:24px;"></div>
  </div>
  `

  const scripts = `
  <script>
    // Greeting based on time
    const hour = new Date().getHours();
    const greetings = [
      [5, 'Good morning! Ready for breakfast? ☀️'],
      [12, 'Good afternoon! Time for lunch! 🌤️'],
      [17, "Good evening! What's for dinner? 🌆"],
      [21, "Late night cravings? We got you! 🌙"],
      [24, 'Midnight snack time! 🌙'],
    ];
    const g = greetings.find(([h]) => hour < h);
    if (g) document.getElementById('hero-greeting').textContent = g[1];

    // Personalized greeting
    const user = QB.user;
    if (user) {
      const name = user.name.split(' ')[0];
      document.getElementById('hero-greeting').textContent = 'Hey ' + name + '! What are you craving? 😋';
    }

    // Filter
    function filterRestaurants(type) {
      document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
      document.getElementById('filter-' + type)?.classList.add('active');
      const cards = document.querySelectorAll('.restaurant-card');
      const data = ${JSON.stringify(RESTAURANTS)};
      let filtered;
      if (type === 'veg') filtered = data.filter(r => r.veg);
      else if (type === 'rating') filtered = data.filter(r => r.rating >= 4.6);
      else if (type === 'fast') filtered = data.filter(r => parseInt(r.time) <= 25);
      else if (type === 'free') filtered = data.filter(r => r.fee === 0);
      else if (type === 'budget') filtered = data.filter(r => r.price === '$');
      else if (type === 'promo') filtered = data.filter(r => r.promo);
      else filtered = data;

      const grid = document.getElementById('restaurants-grid');
      const noResults = document.getElementById('no-results');
      const count = document.getElementById('results-count');

      if (filtered.length === 0) {
        grid.style.display = 'none';
        noResults.style.display = 'block';
      } else {
        noResults.style.display = 'none';
        grid.style.display = 'grid';
        count.innerHTML = 'Showing <strong>' + filtered.length + '</strong> restaurants';
      }

      cards.forEach(card => {
        const restName = card.querySelector('h3').textContent;
        const match = filtered.some(r => r.name === restName);
        card.style.display = match ? '' : 'none';
      });
    }

    function filterByCategory(cat) {
      QB.showToast('Filtering by ' + cat + '...', 'info');
      window.location.href = '/search?q=' + encodeURIComponent(cat);
    }

    function sortRestaurants(val) {
      const grid = document.getElementById('restaurants-grid');
      const cards = [...grid.querySelectorAll('.restaurant-card')];
      const data = ${JSON.stringify(RESTAURANTS)};
      const sorted = [...data];
      if (val === 'rating') sorted.sort((a,b) => b.rating - a.rating);
      else if (val === 'time') sorted.sort((a,b) => parseInt(a.time) - parseInt(b.time));
      else if (val === 'fee') sorted.sort((a,b) => a.fee - b.fee);
      sorted.forEach((r, i) => {
        const card = cards.find(c => c.querySelector('h3').textContent === r.name);
        if (card) grid.appendChild(card);
      });
    }

    function toggleFavorite(id, btn) {
      const icon = btn.querySelector('i');
      const isFav = icon.classList.contains('fas');
      icon.className = isFav ? 'far fa-heart' : 'fas fa-heart';
      icon.style.color = isFav ? '' : '#E53E3E';
      QB.showToast(isFav ? 'Removed from favorites' : '❤️ Added to favorites!', isFav ? 'info' : 'success');
    }

    function copyPromo(code) {
      navigator.clipboard?.writeText(code).catch(() => {});
      QB.showToast('🎉 Promo code "' + code + '" copied!', 'success');
    }

    // Card hover emoji animation
    document.querySelectorAll('.restaurant-card').forEach(card => {
      card.addEventListener('mouseenter', () => {
        card.querySelector('.rest-emoji').style.transform = 'scale(1.15) rotate(-5deg)';
      });
      card.addEventListener('mouseleave', () => {
        card.querySelector('.rest-emoji').style.transform = '';
      });
    });
  </script>
  `

  return pageShell('Home - Order Food Online', content, 'home', scripts)
}
