/**
 * QuickBite - User Profile Page
 * Edit profile, saved addresses, preferences, notifications
 */
import { pageShell } from './layout'

export function renderProfile(): string {
  const content = `
  <div class="container" style="padding-top:24px;padding-bottom:40px;max-width:900px;">

    <!-- Profile Header -->
    <div style="background:var(--primary-gradient);border-radius:var(--radius-xl);padding:28px;margin-bottom:24px;position:relative;overflow:hidden;">
      <div style="position:absolute;right:-20px;bottom:-20px;font-size:120px;opacity:0.1;">👤</div>
      <div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;">
        <div style="position:relative;flex-shrink:0;">
          <div style="width:88px;height:88px;border-radius:50%;background:rgba(255,255,255,0.2);border:3px solid rgba(255,255,255,0.4);display:flex;align-items:center;justify-content:center;font-size:40px;overflow:hidden;" id="avatar-container">
            <img id="profile-img" src="" alt="Profile" style="width:100%;height:100%;object-fit:cover;display:none;">
            <span id="avatar-initials">👤</span>
          </div>
          <button onclick="document.getElementById('avatar-upload').click()" style="position:absolute;bottom:0;right:0;width:28px;height:28px;border-radius:50%;background:white;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:var(--shadow);">
            <i class="fas fa-camera" style="font-size:12px;color:var(--primary);"></i>
          </button>
          <input type="file" id="avatar-upload" accept="image/*" style="display:none;" onchange="handleAvatarChange(this)">
        </div>
        <div style="flex:1;">
          <h2 style="color:white;margin-bottom:4px;" id="profile-name-display">Demo User</h2>
          <p style="color:rgba(255,255,255,0.8);font-size:0.875rem;" id="profile-email-display">demo@quickbite.com</p>
          <div style="display:flex;gap:12px;margin-top:10px;flex-wrap:wrap;">
            ${[
              { label:'23', sub:'Orders' },
              { label:'4.8★', sub:'My Rating' },
              { label:'$284', sub:'Total Spent' },
            ].map(s => `
              <div style="text-align:center;">
                <p style="color:white;font-weight:700;font-size:1rem;">${s.label}</p>
                <p style="color:rgba(255,255,255,0.7);font-size:0.72rem;">${s.sub}</p>
              </div>
            `).join('')}
          </div>
        </div>
        <div>
          <span class="tag" style="background:rgba(255,255,255,0.2);color:white;font-size:0.78rem;"><i class="fas fa-crown" style="color:#ECC94B;"></i> Gold Member</span>
        </div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:240px 1fr;gap:20px;" id="profile-layout">

      <!-- Sidebar -->
      <div>
        <div class="card" style="overflow:hidden;">
          ${[
            { id:'personal', icon:'fa-user', label:'Personal Info' },
            { id:'addresses', icon:'fa-map-marker-alt', label:'Saved Addresses' },
            { id:'payment', icon:'fa-credit-card', label:'Payment Methods' },
            { id:'notifications', icon:'fa-bell', label:'Notifications' },
            { id:'preferences', icon:'fa-sliders-h', label:'Preferences' },
            { id:'security', icon:'fa-shield-alt', label:'Security' },
          ].map((item, i) => `
            <div id="nav-${item.id}" onclick="showSection('${item.id}')"
              style="display:flex;align-items:center;gap:12px;padding:14px 16px;cursor:pointer;transition:var(--transition);border-bottom:1px solid var(--border);${i === 0 ? 'background:rgba(229,62,62,0.05);border-left:3px solid var(--primary);' : ''}">
              <i class="fas ${item.icon}" style="width:16px;color:${i === 0 ? 'var(--primary)' : 'var(--text-muted)'};"></i>
              <span style="font-size:0.875rem;font-weight:600;color:${i === 0 ? 'var(--primary)' : 'var(--text)'};">${item.label}</span>
              <i class="fas fa-chevron-right" style="margin-left:auto;font-size:11px;color:var(--text-muted);"></i>
            </div>
          `).join('')}
          <div style="padding:16px;border-top:1px solid var(--border);">
            <button class="btn btn-ghost btn-full" style="color:var(--primary);border:1.5px solid rgba(229,62,62,0.3);justify-content:center;" onclick="logout()">
              <i class="fas fa-sign-out-alt"></i> Sign Out
            </button>
          </div>
        </div>
      </div>

      <!-- Content Sections -->
      <div>
        <!-- Personal Info -->
        <div id="section-personal" class="card">
          <div class="card-body">
            <h3 style="margin-bottom:20px;font-size:1.1rem;"><i class="fas fa-user" style="color:var(--primary);margin-right:8px;"></i>Personal Information</h3>
            <form onsubmit="saveProfile(event)">
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group" style="margin-bottom:0;">
                  <label class="form-label">First Name</label>
                  <input type="text" class="form-input" id="prof-first" placeholder="John" value="Demo">
                </div>
                <div class="form-group" style="margin-bottom:0;">
                  <label class="form-label">Last Name</label>
                  <input type="text" class="form-input" id="prof-last" placeholder="Doe" value="User">
                </div>
              </div>
              <div class="form-group" style="margin-top:12px;">
                <label class="form-label">Email Address</label>
                <div class="input-group">
                  <i class="fas fa-envelope input-icon"></i>
                  <input type="email" class="form-input" id="prof-email" value="demo@quickbite.com">
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Phone Number</label>
                <div style="display:flex;gap:8px;">
                  <select class="form-input" style="width:90px;flex-shrink:0;"><option>🇺🇸 +1</option></select>
                  <input type="tel" class="form-input" id="prof-phone" placeholder="(555) 000-0000" value="(555) 123-4567" style="flex:1;">
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Date of Birth</label>
                <input type="date" class="form-input" id="prof-dob" value="1990-01-15">
              </div>
              <div class="form-group">
                <label class="form-label">Gender</label>
                <div style="display:flex;gap:10px;">
                  ${['Male','Female','Other','Prefer not to say'].map((g, i) => `
                    <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:0.875rem;">
                      <input type="radio" name="gender" value="${g.toLowerCase()}" ${i === 0 ? 'checked' : ''} style="accent-color:var(--primary);">
                      ${g}
                    </label>
                  `).join('')}
                </div>
              </div>
              <button type="submit" class="btn btn-primary btn-lg">
                <i class="fas fa-save"></i> Save Changes
              </button>
            </form>
          </div>
        </div>

        <!-- Addresses -->
        <div id="section-addresses" class="card" style="display:none;">
          <div class="card-body">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
              <h3 style="font-size:1.1rem;"><i class="fas fa-map-marker-alt" style="color:var(--primary);margin-right:8px;"></i>Saved Addresses</h3>
              <button class="btn btn-primary btn-sm" onclick="openModal('add-address-modal')"><i class="fas fa-plus"></i> Add New</button>
            </div>
            <div style="display:flex;flex-direction:column;gap:10px;" id="addresses-list">
              ${[
                { type:'Home', icon:'fa-home', addr:'123 Main St, Apt 4B, New York, NY 10001', default:true },
                { type:'Work', icon:'fa-building', addr:'456 Park Ave, Floor 12, New York, NY 10022', default:false },
                { type:"Mom's Place", icon:'fa-heart', addr:'789 Oak Rd, Queens, NY 11375', default:false },
              ].map(a => `
                <div style="padding:16px;border-radius:var(--radius-lg);border:1.5px solid ${a.default ? 'var(--primary)' : 'var(--border)'};background:${a.default ? 'rgba(229,62,62,0.02)' : 'var(--surface)'};">
                  <div style="display:flex;align-items:flex-start;gap:12px;">
                    <div style="width:36px;height:36px;border-radius:var(--radius-sm);background:${a.default ? 'rgba(229,62,62,0.1)' : 'var(--surface-2)'};display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                      <i class="fas ${a.icon}" style="color:${a.default ? 'var(--primary)' : 'var(--text-muted)'};"></i>
                    </div>
                    <div style="flex:1;">
                      <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
                        <p style="font-weight:600;font-size:0.875rem;">${a.type}</p>
                        ${a.default ? '<span class="tag tag-primary" style="font-size:0.7rem;">Default</span>' : ''}
                      </div>
                      <p style="font-size:0.8rem;color:var(--text-muted);">${a.addr}</p>
                    </div>
                    <div style="display:flex;gap:6px;flex-shrink:0;">
                      <button class="btn btn-ghost btn-sm" onclick="QB.showToast('Edit address feature coming soon!','info')"><i class="fas fa-edit"></i></button>
                      ${!a.default ? `<button class="btn btn-ghost btn-sm" style="color:var(--primary);" onclick="QB.showToast('Address deleted','info')"><i class="fas fa-trash"></i></button>` : ''}
                    </div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>

        <!-- Payment Methods -->
        <div id="section-payment" class="card" style="display:none;">
          <div class="card-body">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
              <h3 style="font-size:1.1rem;"><i class="fas fa-credit-card" style="color:var(--primary);margin-right:8px;"></i>Payment Methods</h3>
              <button class="btn btn-primary btn-sm" onclick="QB.showToast('Add payment method coming soon!','info')"><i class="fas fa-plus"></i> Add</button>
            </div>
            ${[
              { type:'Visa', num:'•••• •••• •••• 4242', exp:'12/26', icon:'💳', color:'#1A56DB' },
              { type:'Mastercard', num:'•••• •••• •••• 5555', exp:'09/25', icon:'💳', color:'#E53E3E' },
            ].map((card, i) => `
              <div style="padding:16px;border-radius:var(--radius-lg);border:1.5px solid ${i === 0 ? 'var(--primary)' : 'var(--border)'};margin-bottom:10px;background:${i === 0 ? 'rgba(229,62,62,0.02)' : 'var(--surface)'};">
                <div style="display:flex;align-items:center;gap:12px;">
                  <span style="font-size:28px;">${card.icon}</span>
                  <div style="flex:1;">
                    <p style="font-weight:600;font-size:0.875rem;">${card.type}</p>
                    <p style="font-size:0.8rem;color:var(--text-muted);font-family:monospace;">${card.num}</p>
                    <p style="font-size:0.75rem;color:var(--text-muted);">Expires ${card.exp}</p>
                  </div>
                  ${i === 0 ? '<span class="tag tag-primary" style="font-size:0.7rem;">Default</span>' : ''}
                  <button class="btn btn-ghost btn-sm" style="color:var(--primary);" onclick="QB.showToast('Card removed','info')"><i class="fas fa-trash"></i></button>
                </div>
              </div>
            `).join('')}
            <div style="padding:16px;border-radius:var(--radius-lg);border:1.5px dashed var(--border);text-align:center;cursor:pointer;transition:var(--transition);" onmouseenter="this.style.borderColor='var(--primary)'" onmouseleave="this.style.borderColor='var(--border)'" onclick="QB.showToast('Add UPI/wallet coming soon!','info')">
              <i class="fas fa-plus" style="color:var(--text-muted);font-size:20px;margin-bottom:8px;display:block;"></i>
              <p style="font-size:0.875rem;color:var(--text-muted);">Add UPI / Wallet</p>
            </div>
          </div>
        </div>

        <!-- Notifications -->
        <div id="section-notifications" class="card" style="display:none;">
          <div class="card-body">
            <h3 style="margin-bottom:20px;font-size:1.1rem;"><i class="fas fa-bell" style="color:var(--primary);margin-right:8px;"></i>Notification Preferences</h3>
            ${[
              { label:'Order Updates', sub:'Get notified about your order status', on:true },
              { label:'Promotions & Deals', sub:'Exclusive offers and discount notifications', on:true },
              { label:'New Restaurants', sub:'Know when new restaurants join QuickBite', on:false },
              { label:'Weekly Digest', sub:'Summary of your orders and savings', on:true },
              { label:'Push Notifications', sub:'Browser/app push notifications', on:true },
              { label:'SMS Alerts', sub:'Text messages for order updates', on:false },
            ].map(n => `
              <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 0;border-bottom:1px solid var(--border);">
                <div>
                  <p style="font-weight:600;font-size:0.875rem;">${n.label}</p>
                  <p style="font-size:0.78rem;color:var(--text-muted);">${n.sub}</p>
                </div>
                <label style="position:relative;width:48px;height:26px;cursor:pointer;flex-shrink:0;">
                  <input type="checkbox" ${n.on ? 'checked' : ''} style="opacity:0;width:0;height:0;" onchange="QB.showToast('Preference saved!','success')">
                  <span style="position:absolute;inset:0;background:${n.on ? 'var(--primary)' : 'var(--border)'};border-radius:var(--radius-full);transition:0.3s;" id="toggle-bg-${n.label.replace(/\s/g,'')}"></span>
                  <span style="position:absolute;width:20px;height:20px;border-radius:50%;background:white;top:3px;left:${n.on ? '25' : '3'}px;transition:0.3s;box-shadow:var(--shadow-sm);" id="toggle-dot-${n.label.replace(/\s/g,'')}"></span>
                </label>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Preferences -->
        <div id="section-preferences" class="card" style="display:none;">
          <div class="card-body">
            <h3 style="margin-bottom:20px;font-size:1.1rem;"><i class="fas fa-sliders-h" style="color:var(--primary);margin-right:8px;"></i>App Preferences</h3>
            <div class="form-group">
              <label class="form-label">Default Delivery Address</label>
              <select class="form-input"><option>Home — 123 Main St</option><option>Work — 456 Park Ave</option></select>
            </div>
            <div class="form-group">
              <label class="form-label">Food Preferences</label>
              <div style="display:flex;gap:8px;flex-wrap:wrap;">
                ${['Vegetarian','Non-Vegetarian','Vegan','Gluten-Free','Halal','Spicy'].map((p, i) => `
                  <button class="chip ${i < 2 ? 'active' : ''}" onclick="this.classList.toggle('active')">${p}</button>
                `).join('')}
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Language</label>
              <select class="form-input"><option>English</option><option>Spanish</option><option>French</option></select>
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 0;border-top:1px solid var(--border);">
              <div>
                <p style="font-weight:600;font-size:0.875rem;">Dark Mode</p>
                <p style="font-size:0.78rem;color:var(--text-muted);">Toggle dark/light theme</p>
              </div>
              <button class="btn btn-ghost btn-sm" onclick="toggleTheme()"><i class="fas fa-moon" id="pref-theme-icon"></i></button>
            </div>
            <button class="btn btn-primary" onclick="QB.showToast('Preferences saved!','success')">
              <i class="fas fa-save"></i> Save Preferences
            </button>
          </div>
        </div>

        <!-- Security -->
        <div id="section-security" class="card" style="display:none;">
          <div class="card-body">
            <h3 style="margin-bottom:20px;font-size:1.1rem;"><i class="fas fa-shield-alt" style="color:var(--primary);margin-right:8px;"></i>Security Settings</h3>
            <div class="form-group">
              <label class="form-label">Current Password</label>
              <div class="input-group">
                <i class="fas fa-lock input-icon"></i>
                <input type="password" class="form-input" placeholder="Enter current password" id="cur-pw">
                <i class="fas fa-eye input-icon-right" onclick="this.previousElementSibling.type=this.previousElementSibling.type==='password'?'text':'password'"></i>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">New Password</label>
              <div class="input-group">
                <i class="fas fa-lock input-icon"></i>
                <input type="password" class="form-input" placeholder="Enter new password" id="new-pw">
                <i class="fas fa-eye input-icon-right" onclick="this.previousElementSibling.type=this.previousElementSibling.type==='password'?'text':'password'"></i>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Confirm New Password</label>
              <div class="input-group">
                <i class="fas fa-lock input-icon"></i>
                <input type="password" class="form-input" placeholder="Confirm new password" id="conf-pw">
              </div>
            </div>
            <button class="btn btn-primary" onclick="changePassword()"><i class="fas fa-key"></i> Change Password</button>
            <div style="margin-top:20px;padding-top:20px;border-top:1px solid var(--border);">
              <h4 style="margin-bottom:12px;font-size:0.9rem;color:var(--primary);">Two-Factor Authentication</h4>
              <p style="font-size:0.875rem;color:var(--text-secondary);margin-bottom:12px;">Add an extra layer of security to your account</p>
              <button class="btn btn-outline btn-sm" onclick="QB.showToast('2FA setup coming soon!','info')"><i class="fas fa-mobile-alt"></i> Setup 2FA</button>
            </div>
            <div style="margin-top:20px;padding-top:20px;border-top:1px solid var(--border);">
              <h4 style="margin-bottom:12px;font-size:0.9rem;color:#E53E3E;">Danger Zone</h4>
              <button class="btn btn-sm" style="background:rgba(229,62,62,0.1);color:var(--primary);border:1px solid rgba(229,62,62,0.3);" onclick="if(confirm('Delete account? This cannot be undone!'))QB.showToast('Account deletion requested','info')">
                <i class="fas fa-trash-alt"></i> Delete Account
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Add Address Modal -->
  <div class="modal-overlay" id="add-address-modal">
    <div class="modal">
      <div class="modal-header">
        <h3>Add New Address</h3>
        <button class="modal-close" onclick="closeModal('add-address-modal')"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Address Label</label>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            ${['Home','Work','Other'].map((l, i) => `
              <button class="chip ${i === 0 ? 'active' : ''}" onclick="document.querySelectorAll('.addr-label-chip').forEach(c=>c.classList.remove('active'));this.classList.add('active')" class="addr-label-chip">${l}</button>
            `).join('')}
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Full Address</label>
          <textarea class="form-input" rows="2" placeholder="Street, City, State, ZIP"></textarea>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          <div class="form-group" style="margin-bottom:0;"><label class="form-label">City</label><input type="text" class="form-input" placeholder="New York"></div>
          <div class="form-group" style="margin-bottom:0;"><label class="form-label">ZIP Code</label><input type="text" class="form-input" placeholder="10001"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('add-address-modal')">Cancel</button>
        <button class="btn btn-primary" onclick="QB.showToast('Address saved!','success');closeModal('add-address-modal')"><i class="fas fa-save"></i> Save Address</button>
      </div>
    </div>
  </div>
  `

  const scripts = `
  <script>
    function showSection(id) {
      // Update nav
      document.querySelectorAll('[id^="nav-"]').forEach(el => {
        const active = el.id === 'nav-' + id;
        el.style.background = active ? 'rgba(229,62,62,0.05)' : '';
        el.style.borderLeft = active ? '3px solid var(--primary)' : '';
        el.querySelector('i:first-child').style.color = active ? 'var(--primary)' : 'var(--text-muted)';
        el.querySelector('span').style.color = active ? 'var(--primary)' : 'var(--text)';
      });
      // Show/hide sections
      ['personal','addresses','payment','notifications','preferences','security'].forEach(s => {
        const el = document.getElementById('section-' + s);
        if (el) el.style.display = s === id ? 'block' : 'none';
      });
    }

    function handleAvatarChange(input) {
      const file = input.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = e => {
        const img = document.getElementById('profile-img');
        img.src = e.target.result;
        img.style.display = 'block';
        document.getElementById('avatar-initials').style.display = 'none';
        QB.showToast('Profile photo updated!', 'success');
      };
      reader.readAsDataURL(file);
    }

    function saveProfile(e) {
      e.preventDefault();
      const first = document.getElementById('prof-first').value;
      const last = document.getElementById('prof-last').value;
      const email = document.getElementById('prof-email').value;
      const user = QB.user || {};
      QB.user = { ...user, name: first + ' ' + last, email };
      document.getElementById('profile-name-display').textContent = first + ' ' + last;
      document.getElementById('profile-email-display').textContent = email;
      QB.showToast('Profile updated successfully! ✅', 'success');
    }

    function changePassword() {
      const cur = document.getElementById('cur-pw').value;
      const newPw = document.getElementById('new-pw').value;
      const conf = document.getElementById('conf-pw').value;
      if (!cur || !newPw || !conf) { QB.showToast('Please fill all fields', 'error'); return; }
      if (newPw !== conf) { QB.showToast('Passwords do not match!', 'error'); return; }
      if (newPw.length < 8) { QB.showToast('Password must be at least 8 characters', 'error'); return; }
      QB.showToast('Password changed successfully! 🔐', 'success');
      document.getElementById('cur-pw').value = '';
      document.getElementById('new-pw').value = '';
      document.getElementById('conf-pw').value = '';
    }

    function logout() {
      if (!confirm('Sign out of QuickBite?')) return;
      QB.user = null;
      QB.showToast('Signed out successfully', 'info');
      setTimeout(() => window.location.href = '/login', 800);
    }

    // Mobile layout
    function handleResize() {
      const layout = document.getElementById('profile-layout');
      if (layout) layout.style.gridTemplateColumns = window.innerWidth <= 768 ? '1fr' : '240px 1fr';
    }
    window.addEventListener('resize', handleResize);

    document.addEventListener('DOMContentLoaded', () => {
      handleResize();
      const user = QB.user;
      if (user) {
        document.getElementById('profile-name-display').textContent = user.name || 'Demo User';
        document.getElementById('profile-email-display').textContent = user.email || 'demo@quickbite.com';
        const initials = (user.name || 'DU').split(' ').map(n => n[0]).join('').toUpperCase().substring(0,2);
        document.getElementById('avatar-initials').textContent = initials;
      }
      // Toggle checkboxes
      document.querySelectorAll('input[type=checkbox]').forEach(cb => {
        cb.addEventListener('change', function() {
          const label = this.parentElement;
          const bg = label.querySelector('[id^="toggle-bg-"]') || label.querySelector('span:first-of-type');
          const dot = label.querySelector('[id^="toggle-dot-"]') || label.querySelector('span:last-of-type');
          if (bg) bg.style.background = this.checked ? 'var(--primary)' : 'var(--border)';
          if (dot) dot.style.left = this.checked ? '25px' : '3px';
        });
      });
    });
  </script>
  `

  return pageShell('My Profile', content, 'profile', scripts)
}
