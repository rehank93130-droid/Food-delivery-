/**
 * QuickBite - Authentication Pages
 * Login and Signup with email, phone, and social options
 */
import { pageShell } from './layout'

export function renderLogin(): string {
  const content = `
  <div style="min-height:calc(100vh - 64px);display:flex;align-items:center;justify-content:center;padding:20px;">
    <div style="width:100%;max-width:440px;" class="fade-in">
      <!-- Logo Area -->
      <div style="text-align:center;margin-bottom:32px;">
        <div style="width:72px;height:72px;background:var(--primary-gradient);border-radius:20px;display:inline-flex;align-items:center;justify-content:center;font-size:36px;margin-bottom:16px;box-shadow:0 8px 24px rgba(229,62,62,0.3);">🍔</div>
        <h1 style="font-size:1.8rem;margin-bottom:6px;">Welcome back!</h1>
        <p style="color:var(--text-secondary);">Sign in to continue to QuickBite</p>
      </div>

      <!-- Social Logins -->
      <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:24px;">
        <button class="btn btn-ghost btn-full" style="border:1.5px solid var(--border);justify-content:center;gap:10px;" onclick="socialLogin('google')">
          <svg width="18" height="18" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
          Continue with Google
        </button>
        <div style="display:flex;gap:10px;">
          <button class="btn btn-ghost btn-full" style="border:1.5px solid var(--border);" onclick="socialLogin('facebook')">
            <i class="fab fa-facebook" style="color:#1877F2;"></i> Facebook
          </button>
          <button class="btn btn-ghost btn-full" style="border:1.5px solid var(--border);" onclick="socialLogin('apple')">
            <i class="fab fa-apple" style="color:var(--text);"></i> Apple
          </button>
        </div>
      </div>

      <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px;">
        <div style="flex:1;height:1px;background:var(--border);"></div>
        <span style="font-size:0.8rem;color:var(--text-muted);font-weight:600;">OR CONTINUE WITH</span>
        <div style="flex:1;height:1px;background:var(--border);"></div>
      </div>

      <!-- Login Tabs -->
      <div style="display:flex;background:var(--surface-2);border-radius:var(--radius);padding:4px;margin-bottom:20px;">
        <button id="email-tab" class="tab-btn active" onclick="switchTab('email')" style="flex:1;padding:8px;border-radius:var(--radius-sm);font-size:0.85rem;font-weight:600;border:none;cursor:pointer;transition:var(--transition);background:var(--surface);color:var(--primary);box-shadow:var(--shadow-sm);">
          <i class="fas fa-envelope"></i> Email
        </button>
        <button id="phone-tab" class="tab-btn" onclick="switchTab('phone')" style="flex:1;padding:8px;border-radius:var(--radius-sm);font-size:0.85rem;font-weight:600;border:none;cursor:pointer;transition:var(--transition);background:transparent;color:var(--text-secondary);">
          <i class="fas fa-phone"></i> Phone
        </button>
      </div>

      <!-- Email Form -->
      <form id="email-form" onsubmit="handleLogin(event,'email')">
        <div class="form-group">
          <label class="form-label">Email Address</label>
          <div class="input-group">
            <i class="fas fa-envelope input-icon"></i>
            <input type="email" class="form-input" placeholder="Enter your email" id="login-email" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" style="display:flex;justify-content:space-between;">
            Password
            <a href="#" style="color:var(--primary);font-weight:600;font-size:0.82rem;" onclick="showForgotPassword()">Forgot password?</a>
          </label>
          <div class="input-group">
            <i class="fas fa-lock input-icon"></i>
            <input type="password" class="form-input" placeholder="Enter your password" id="login-password" required>
            <i class="fas fa-eye input-icon-right" onclick="togglePassword('login-password')"></i>
          </div>
        </div>
        <label style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer;font-size:0.875rem;color:var(--text-secondary);">
          <input type="checkbox" id="remember-me" style="accent-color:var(--primary);width:16px;height:16px;">
          Remember me for 30 days
        </label>
        <button type="submit" class="btn btn-primary btn-full btn-lg" id="login-btn">
          <i class="fas fa-sign-in-alt"></i> Sign In
        </button>
      </form>

      <!-- Phone Form -->
      <form id="phone-form" style="display:none;" onsubmit="handleLogin(event,'phone')">
        <div class="form-group">
          <label class="form-label">Phone Number</label>
          <div style="display:flex;gap:8px;">
            <select class="form-input" style="width:90px;flex-shrink:0;">
              <option>🇺🇸 +1</option>
              <option>🇬🇧 +44</option>
              <option>🇮🇳 +91</option>
              <option>🇦🇺 +61</option>
            </select>
            <input type="tel" class="form-input" placeholder="(555) 000-0000" id="login-phone" style="flex:1;">
          </div>
        </div>
        <button type="submit" class="btn btn-primary btn-full btn-lg">
          <i class="fas fa-sms"></i> Send OTP
        </button>
      </form>

      <!-- OTP Form (hidden) -->
      <form id="otp-form" style="display:none;" onsubmit="verifyOTP(event)">
        <p style="text-align:center;margin-bottom:16px;color:var(--text-secondary);font-size:0.875rem;">
          <i class="fas fa-check-circle" style="color:var(--success);"></i>
          OTP sent to <strong id="otp-phone-display"></strong>
        </p>
        <div class="form-group">
          <label class="form-label">Enter 6-digit OTP</label>
          <div style="display:flex;gap:8px;justify-content:center;">
            ${Array.from({length:6}).map((_,i)=>`
              <input type="text" maxlength="1" class="form-input otp-input" id="otp-${i}"
                style="width:48px;height:52px;text-align:center;font-size:1.2rem;font-weight:700;"
                oninput="moveOTP(${i}, this.value)"
                onkeydown="backOTP(event, ${i})">
            `).join('')}
          </div>
        </div>
        <p style="text-align:center;font-size:0.8rem;color:var(--text-muted);margin-bottom:20px;">
          Didn't receive? <a href="#" style="color:var(--primary);" id="resend-otp" onclick="resendOTP()">Resend in <span id="otp-timer">60</span>s</a>
        </p>
        <button type="submit" class="btn btn-primary btn-full btn-lg">
          <i class="fas fa-check"></i> Verify OTP
        </button>
      </form>

      <!-- Sign Up Link -->
      <p style="text-align:center;margin-top:24px;font-size:0.875rem;color:var(--text-secondary);">
        Don't have an account?
        <a href="/signup" style="color:var(--primary);font-weight:700;">Create Account</a>
      </p>

      <!-- Demo Hint -->
      <div style="margin-top:20px;padding:12px;background:rgba(49,130,206,0.08);border-radius:var(--radius);border:1px solid rgba(49,130,206,0.2);text-align:center;">
        <p style="font-size:0.78rem;color:var(--info);">
          <i class="fas fa-info-circle"></i>
          Demo: Use any email & password to sign in
        </p>
      </div>
    </div>
  </div>

  <!-- Forgot Password Modal -->
  <div class="modal-overlay" id="forgot-modal">
    <div class="modal">
      <div class="modal-header">
        <h3>Reset Password</h3>
        <button class="modal-close" onclick="closeModal('forgot-modal')"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <p style="margin-bottom:16px;font-size:0.875rem;color:var(--text-secondary);">
          Enter your email and we'll send you a reset link.
        </p>
        <div class="input-group">
          <i class="fas fa-envelope input-icon"></i>
          <input type="email" class="form-input" placeholder="Your email address" id="reset-email">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('forgot-modal')">Cancel</button>
        <button class="btn btn-primary" onclick="sendResetLink()">
          <i class="fas fa-paper-plane"></i> Send Link
        </button>
      </div>
    </div>
  </div>
  `

  const scripts = `
  <script>
    function switchTab(tab) {
      ['email','phone'].forEach(t => {
        const btn = document.getElementById(t+'-tab');
        const form = document.getElementById(t+'-form');
        const active = t === tab;
        btn.style.background = active ? 'var(--surface)' : 'transparent';
        btn.style.color = active ? 'var(--primary)' : 'var(--text-secondary)';
        btn.style.boxShadow = active ? 'var(--shadow-sm)' : 'none';
        form.style.display = active ? 'block' : 'none';
      });
    }

    function togglePassword(id) {
      const inp = document.getElementById(id);
      inp.type = inp.type === 'password' ? 'text' : 'password';
    }

    function handleLogin(e, type) {
      e.preventDefault();
      const btn = document.getElementById('login-btn');
      if (btn) { btn.innerHTML = '<div class="spinner" style="width:20px;height:20px;border-width:2px;"></div> Signing in...'; btn.disabled = true; }

      if (type === 'phone') {
        const phone = document.getElementById('login-phone').value;
        document.getElementById('otp-phone-display').textContent = phone;
        setTimeout(() => {
          document.getElementById('phone-form').style.display = 'none';
          document.getElementById('otp-form').style.display = 'block';
          startOTPTimer();
          QB.showToast('OTP sent! Use 123456 for demo', 'info', 5000);
        }, 1000);
        return;
      }

      // Email login simulation
      const email = document.getElementById('login-email').value;
      setTimeout(() => {
        QB.user = { name: email.split('@')[0].replace(/\\W/g,' ').replace(/\\b\\w/g,c=>c.toUpperCase()), email, role: 'user' };
        QB.showToast('Welcome back! 🎉', 'success');
        setTimeout(() => window.location.href = '/', 800);
      }, 1500);
    }

    function socialLogin(provider) {
      QB.showToast('Connecting to ' + provider + '...', 'info');
      setTimeout(() => {
        QB.user = { name: 'Demo User', email: 'demo@quickbite.com', role: 'user' };
        QB.showToast('Signed in with ' + provider + '! 🎉', 'success');
        setTimeout(() => window.location.href = '/', 800);
      }, 1200);
    }

    function moveOTP(idx, val) {
      if (val && idx < 5) document.getElementById('otp-' + (idx+1)).focus();
    }

    function backOTP(e, idx) {
      if (e.key === 'Backspace' && !document.getElementById('otp-'+idx).value && idx > 0) {
        document.getElementById('otp-' + (idx-1)).focus();
      }
    }

    function verifyOTP(e) {
      e.preventDefault();
      const otp = Array.from({length:6}).map((_,i)=>document.getElementById('otp-'+i).value).join('');
      if (otp === '123456') {
        QB.user = { name: 'Phone User', email: '', phone: document.getElementById('login-phone')?.value, role: 'user' };
        QB.showToast('Verified! Welcome to QuickBite 🎉', 'success');
        setTimeout(() => window.location.href = '/', 800);
      } else {
        QB.showToast('Invalid OTP. Try 123456 for demo', 'error');
        document.querySelectorAll('.otp-input').forEach(i => { i.style.borderColor='var(--primary)'; });
        setTimeout(() => document.querySelectorAll('.otp-input').forEach(i => { i.style.borderColor=''; }), 2000);
      }
    }

    let otpInterval;
    function startOTPTimer() {
      let sec = 60;
      const el = document.getElementById('otp-timer');
      const link = document.getElementById('resend-otp');
      otpInterval = setInterval(() => {
        sec--;
        if (el) el.textContent = sec;
        if (sec <= 0) {
          clearInterval(otpInterval);
          if (link) link.style.pointerEvents = 'auto';
          if (el) el.textContent = '0';
        }
      }, 1000);
    }

    function resendOTP() { clearInterval(otpInterval); startOTPTimer(); QB.showToast('OTP resent!', 'success'); }
    function showForgotPassword() { openModal('forgot-modal'); }
    function sendResetLink() {
      QB.showToast('Reset link sent! Check your email', 'success');
      closeModal('forgot-modal');
    }
  </script>
  `

  return pageShell('Sign In', content, 'login', scripts)
}

export function renderSignup(): string {
  const content = `
  <div style="min-height:calc(100vh - 64px);display:flex;align-items:center;justify-content:center;padding:20px;">
    <div style="width:100%;max-width:460px;" class="fade-in">
      <div style="text-align:center;margin-bottom:32px;">
        <div style="width:72px;height:72px;background:var(--primary-gradient);border-radius:20px;display:inline-flex;align-items:center;justify-content:center;font-size:36px;margin-bottom:16px;box-shadow:0 8px 24px rgba(229,62,62,0.3);">🍔</div>
        <h1 style="font-size:1.8rem;margin-bottom:6px;">Create Account</h1>
        <p style="color:var(--text-secondary);">Join QuickBite for amazing food deals!</p>
      </div>

      <!-- Social Logins -->
      <div style="margin-bottom:24px;">
        <button class="btn btn-ghost btn-full" style="border:1.5px solid var(--border);justify-content:center;gap:10px;margin-bottom:10px;" onclick="socialSignup('google')">
          <svg width="18" height="18" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
          Sign up with Google
        </button>
      </div>

      <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px;">
        <div style="flex:1;height:1px;background:var(--border);"></div>
        <span style="font-size:0.8rem;color:var(--text-muted);font-weight:600;">OR</span>
        <div style="flex:1;height:1px;background:var(--border);"></div>
      </div>

      <!-- Signup Form -->
      <form id="signup-form" onsubmit="handleSignup(event)">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:4px;">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">First Name</label>
            <input type="text" class="form-input" placeholder="John" id="signup-first" required>
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Last Name</label>
            <input type="text" class="form-input" placeholder="Doe" id="signup-last" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Email Address</label>
          <div class="input-group">
            <i class="fas fa-envelope input-icon"></i>
            <input type="email" class="form-input" placeholder="john@example.com" id="signup-email" required oninput="checkEmail(this.value)">
          </div>
          <p id="email-feedback" style="font-size:0.78rem;margin-top:4px;"></p>
        </div>
        <div class="form-group">
          <label class="form-label">Phone Number</label>
          <div style="display:flex;gap:8px;">
            <select class="form-input" style="width:90px;flex-shrink:0;">
              <option>🇺🇸 +1</option>
              <option>🇬🇧 +44</option>
              <option>🇮🇳 +91</option>
            </select>
            <input type="tel" class="form-input" placeholder="(555) 000-0000" id="signup-phone" style="flex:1;">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <div class="input-group">
            <i class="fas fa-lock input-icon"></i>
            <input type="password" class="form-input" placeholder="Min 8 characters" id="signup-password" required oninput="checkPasswordStrength(this.value)">
            <i class="fas fa-eye input-icon-right" onclick="togglePassword('signup-password')"></i>
          </div>
          <!-- Password strength meter -->
          <div style="margin-top:8px;">
            <div class="progress-bar" style="height:4px;">
              <div class="progress-fill" id="pw-strength-bar" style="width:0%;transition:width 0.3s;"></div>
            </div>
            <p id="pw-strength-text" style="font-size:0.75rem;margin-top:4px;color:var(--text-muted);"></p>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm Password</label>
          <div class="input-group">
            <i class="fas fa-lock input-icon"></i>
            <input type="password" class="form-input" placeholder="Repeat your password" id="signup-confirm" required>
          </div>
        </div>
        <label style="display:flex;align-items:flex-start;gap:10px;margin-bottom:20px;cursor:pointer;font-size:0.82rem;color:var(--text-secondary);line-height:1.5;">
          <input type="checkbox" id="terms-check" style="accent-color:var(--primary);width:16px;height:16px;margin-top:2px;flex-shrink:0;" required>
          I agree to the <a href="#" style="color:var(--primary);">Terms of Service</a> and <a href="#" style="color:var(--primary);">Privacy Policy</a>
        </label>
        <button type="submit" class="btn btn-primary btn-full btn-lg">
          <i class="fas fa-user-plus"></i> Create Account
        </button>
      </form>

      <p style="text-align:center;margin-top:24px;font-size:0.875rem;color:var(--text-secondary);">
        Already have an account?
        <a href="/login" style="color:var(--primary);font-weight:700;">Sign In</a>
      </p>
    </div>
  </div>
  `

  const scripts = `
  <script>
    function togglePassword(id) {
      const inp = document.getElementById(id);
      inp.type = inp.type === 'password' ? 'text' : 'password';
    }

    function checkEmail(val) {
      const fb = document.getElementById('email-feedback');
      if (!val) { fb.textContent=''; return; }
      const valid = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(val);
      fb.textContent = valid ? '✅ Valid email' : '❌ Invalid email format';
      fb.style.color = valid ? 'var(--success)' : 'var(--primary)';
    }

    function checkPasswordStrength(pw) {
      const bar = document.getElementById('pw-strength-bar');
      const txt = document.getElementById('pw-strength-text');
      let score = 0;
      if (pw.length >= 8) score++;
      if (/[A-Z]/.test(pw)) score++;
      if (/[0-9]/.test(pw)) score++;
      if (/[^A-Za-z0-9]/.test(pw)) score++;
      const levels = [
        { w:'20%', c:'#E53E3E', t:'Too weak' },
        { w:'40%', c:'#ED8936', t:'Weak' },
        { w:'65%', c:'#ECC94B', t:'Medium' },
        { w:'85%', c:'#48BB78', t:'Strong' },
        { w:'100%', c:'#38A169', t:'Very strong' },
      ];
      const l = levels[Math.max(0, score)];
      bar.style.width = l.w; bar.style.background = l.c;
      txt.textContent = pw ? l.t : '';
      txt.style.color = l.c;
    }

    function handleSignup(e) {
      e.preventDefault();
      const pw = document.getElementById('signup-password').value;
      const conf = document.getElementById('signup-confirm').value;
      if (pw !== conf) { QB.showToast('Passwords do not match!', 'error'); return; }
      const first = document.getElementById('signup-first').value;
      const last = document.getElementById('signup-last').value;
      const email = document.getElementById('signup-email').value;
      const btn = e.target.querySelector('button[type=submit]');
      btn.innerHTML = '<div class="spinner" style="width:20px;height:20px;border-width:2px;"></div> Creating...';
      btn.disabled = true;
      setTimeout(() => {
        QB.user = { name: first + ' ' + last, email, role: 'user' };
        QB.showToast('Account created! Welcome to QuickBite 🎉', 'success');
        setTimeout(() => window.location.href = '/', 800);
      }, 1500);
    }

    function socialSignup(p) {
      QB.showToast('Connecting to ' + p + '...', 'info');
      setTimeout(() => {
        QB.user = { name: 'Demo User', email: 'demo@quickbite.com', role: 'user' };
        QB.showToast('Account created! Welcome 🎉', 'success');
        setTimeout(() => window.location.href = '/', 800);
      }, 1200);
    }
  </script>
  `

  return pageShell('Create Account', content, 'signup', scripts)
}
