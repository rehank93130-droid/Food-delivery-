/**
 * QuickBite - Order History Page
 * All past orders with status, reorder functionality
 */
import { pageShell } from './layout'

export function renderOrders(): string {
  const content = `
  <div class="container" style="padding-top:24px;padding-bottom:40px;">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
      <h2 style="font-size:1.4rem;"><i class="fas fa-receipt" style="color:var(--primary);margin-right:10px;"></i>My Orders</h2>
      <div style="display:flex;gap:8px;">
        <button class="chip active" id="tab-all" onclick="switchOrderTab('all')">All Orders</button>
        <button class="chip" id="tab-active" onclick="switchOrderTab('active')">
          Active <span style="background:var(--primary);color:white;width:16px;height:16px;border-radius:50%;font-size:10px;display:inline-flex;align-items:center;justify-content:center;margin-left:4px;">2</span>
        </button>
        <button class="chip" id="tab-past" onclick="switchOrderTab('past')">Past</button>
      </div>
    </div>

    <!-- Active Orders Banner -->
    <div id="active-banner" style="background:linear-gradient(135deg,rgba(229,62,62,0.08),rgba(229,62,62,0.02));border:1.5px solid rgba(229,62,62,0.2);border-radius:var(--radius-lg);padding:16px;margin-bottom:20px;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
        <div style="width:10px;height:10px;border-radius:50%;background:var(--primary);animation:pulse 1.5s infinite;"></div>
        <h4 style="font-size:0.9rem;color:var(--primary);">Active Orders</h4>
      </div>
      <div style="display:flex;flex-direction:column;gap:10px;">
        <div style="background:var(--surface);border-radius:var(--radius);padding:14px;border:1px solid var(--border);display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
          <div style="width:44px;height:44px;background:linear-gradient(135deg,#1a202c,#2d3748);border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;">🍔</div>
          <div style="flex:1;min-width:0;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:2px;flex-wrap:wrap;">
              <p style="font-weight:700;font-size:0.875rem;">Burger Palace</p>
              <span class="tag" style="background:rgba(214,158,46,0.12);color:#D69E2E;font-size:0.7rem;">🍳 Preparing</span>
            </div>
            <p style="font-size:0.78rem;color:var(--text-muted);">QB${Math.floor(Math.random()*900000+100000)} · $23.48 · 2 items</p>
          </div>
          <div style="display:flex;gap:8px;flex-shrink:0;">
            <button class="btn btn-primary btn-sm" onclick="window.location.href='/tracking'"><i class="fas fa-map-marker-alt"></i> Track</button>
          </div>
        </div>
        <div style="background:var(--surface);border-radius:var(--radius);padding:14px;border:1px solid var(--border);display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
          <div style="width:44px;height:44px;background:linear-gradient(135deg,#1a202c,#2d3748);border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;">🍕</div>
          <div style="flex:1;min-width:0;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:2px;flex-wrap:wrap;">
              <p style="font-weight:700;font-size:0.875rem;">Pizza Heaven</p>
              <span class="tag" style="background:rgba(49,130,206,0.12);color:#3182CE;font-size:0.7rem;">🛵 Out for Delivery</span>
            </div>
            <p style="font-size:0.78rem;color:var(--text-muted);">QB${Math.floor(Math.random()*900000+100000)} · $16.98 · 1 item</p>
          </div>
          <div style="display:flex;gap:8px;flex-shrink:0;">
            <button class="btn btn-primary btn-sm" onclick="window.location.href='/tracking'"><i class="fas fa-map-marker-alt"></i> Track</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Past Orders List -->
    <div id="orders-list">
      ${generatePastOrders()}
    </div>

    <!-- Empty State -->
    <div id="empty-orders" style="display:none;text-align:center;padding:80px 20px;">
      <div style="font-size:72px;margin-bottom:16px;">📋</div>
      <h3 style="margin-bottom:8px;">No orders yet</h3>
      <p style="color:var(--text-muted);margin-bottom:24px;">Your order history will appear here</p>
      <button class="btn btn-primary btn-lg" onclick="window.location.href='/'">
        <i class="fas fa-utensils"></i> Order Now
      </button>
    </div>
  </div>

  <!-- Reorder Modal -->
  <div class="modal-overlay" id="reorder-modal">
    <div class="modal">
      <div class="modal-header">
        <h3><i class="fas fa-redo" style="color:var(--primary);margin-right:8px;"></i>Reorder</h3>
        <button class="modal-close" onclick="closeModal('reorder-modal')"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <p>Would you like to add the same items to your cart?</p>
        <div id="reorder-items" style="margin-top:16px;"></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('reorder-modal')">Cancel</button>
        <button class="btn btn-primary" onclick="confirmReorder()"><i class="fas fa-shopping-cart"></i> Add to Cart</button>
      </div>
    </div>
  </div>

  <!-- Rate Order Modal -->
  <div class="modal-overlay" id="rate-modal">
    <div class="modal">
      <div class="modal-header">
        <h3>Rate Your Order</h3>
        <button class="modal-close" onclick="closeModal('rate-modal')"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <div style="text-align:center;margin-bottom:20px;">
          <p style="margin-bottom:12px;color:var(--text-secondary);">How was your experience?</p>
          <div class="rating-input" style="justify-content:center;">
            ${[1,2,3,4,5].map(s => `<span class="rating-star" data-val="${s}" onclick="setRating(${s})">★</span>`).join('')}
          </div>
        </div>
        <div class="form-group">
          <textarea class="form-input" rows="3" placeholder="Tell us more..." id="rate-feedback" style="resize:none;"></textarea>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          ${['Delicious food 😋','Fast delivery 🚀','Great packaging 📦','Friendly rider 😊'].map(tag => `
            <button class="chip" onclick="this.classList.toggle('active')">${tag}</button>
          `).join('')}
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('rate-modal')">Skip</button>
        <button class="btn btn-primary" onclick="submitRating()"><i class="fas fa-paper-plane"></i> Submit Rating</button>
      </div>
    </div>
  </div>
  `

  const scripts = `
  <script>
    let ratingValue = 0;
    let currentReorderItems = [];

    function switchOrderTab(tab) {
      document.querySelectorAll('[id^="tab-"]').forEach(b => b.classList.remove('active'));
      document.getElementById('tab-' + tab)?.classList.add('active');
      const banner = document.getElementById('active-banner');
      const list = document.getElementById('orders-list');
      if (tab === 'active') {
        banner.style.display = 'block';
        list.style.display = 'none';
      } else if (tab === 'past') {
        banner.style.display = 'none';
        list.style.display = 'block';
      } else {
        banner.style.display = 'block';
        list.style.display = 'block';
      }
    }

    function setRating(v) {
      ratingValue = v;
      document.querySelectorAll('.rating-star').forEach((s, i) => {
        s.classList.toggle('active', i < v);
        s.style.color = i < v ? '#ECC94B' : 'var(--border)';
      });
    }

    function submitRating() {
      if (!ratingValue) { QB.showToast('Please select a rating', 'error'); return; }
      QB.showToast('Thank you for your feedback! 🌟', 'success');
      closeModal('rate-modal');
    }

    function openReorder(items) {
      currentReorderItems = items;
      document.getElementById('reorder-items').innerHTML = items.map(item =>
        '<div style="display:flex;justify-content:space-between;font-size:0.875rem;padding:6px 0;border-bottom:1px solid var(--border);">' +
        '<span>' + item.emoji + ' ' + item.name + ' x' + item.qty + '</span>' +
        '<span style="font-weight:600;">$' + (item.price * item.qty).toFixed(2) + '</span>' +
        '</div>'
      ).join('');
      openModal('reorder-modal');
    }

    function confirmReorder() {
      currentReorderItems.forEach(item => {
        for (let i = 0; i < item.qty; i++) QB.addToCart({ id: item.id, name: item.name, price: item.price, image: item.emoji });
      });
      closeModal('reorder-modal');
      QB.showToast('Items added to cart! 🛒', 'success');
      setTimeout(() => window.location.href = '/cart', 1000);
    }

    document.addEventListener('DOMContentLoaded', () => {});
  </script>
  `

  return pageShell('My Orders', content, 'orders', scripts)
}

function generatePastOrders(): string {
  const orders = [
    {
      id: 'QB' + Math.floor(Math.random()*900000+100000),
      restaurant: 'Curry House', emoji: '🍛',
      date: '2 days ago', status: 'Delivered',
      items: [{id:'c1',name:'Butter Chicken',price:14.99,qty:1,emoji:'🍛'},{id:'br1',name:'Garlic Naan',price:3.49,qty:2,emoji:'🫓'},{id:'d1',name:'Classic Cola',price:2.49,qty:2,emoji:'🥤'}],
      total: 28.45, rating: 5,
    },
    {
      id: 'QB' + Math.floor(Math.random()*900000+100000),
      restaurant: 'Sushi World', emoji: '🍱',
      date: '5 days ago', status: 'Delivered',
      items: [{id:'r1',name:'California Roll',price:12.99,qty:2,emoji:'🍱'},{id:'sa1',name:'Salmon Sashimi',price:18.99,qty:1,emoji:'🍣'}],
      total: 44.97, rating: 4,
    },
    {
      id: 'QB' + Math.floor(Math.random()*900000+100000),
      restaurant: 'Taco Fiesta', emoji: '🌮',
      date: '1 week ago', status: 'Delivered',
      items: [{id:'t1',name:'Chicken Taco',price:3.99,qty:3,emoji:'🌮'},{id:'bu1',name:'Super Burrito',price:9.99,qty:1,emoji:'🌯'}],
      total: 21.96, rating: 0,
    },
    {
      id: 'QB' + Math.floor(Math.random()*900000+100000),
      restaurant: 'Pizza Heaven', emoji: '🍕',
      date: '2 weeks ago', status: 'Cancelled',
      items: [{id:'p2',name:'Pepperoni',price:14.99,qty:1,emoji:'🍕'}],
      total: 16.98, rating: 0,
    },
    {
      id: 'QB' + Math.floor(Math.random()*900000+100000),
      restaurant: 'Green Bowl', emoji: '🥗',
      date: '3 weeks ago', status: 'Delivered',
      items: [{id:'bw1',name:'Buddha Bowl',price:14.99,qty:2,emoji:'🥗'},{id:'sl1',name:'Caesar Salad',price:10.99,qty:1,emoji:'🥗'}],
      total: 40.97, rating: 5,
    },
  ]

  return `
    <h4 style="font-size:0.9rem;color:var(--text-muted);margin-bottom:12px;font-weight:600;">PAST ORDERS</h4>
    ${orders.map(order => `
      <div style="background:var(--surface);border-radius:var(--radius-lg);border:1px solid var(--border);margin-bottom:12px;overflow:hidden;transition:var(--transition);" onmouseenter="this.style.boxShadow='var(--shadow-md)'" onmouseleave="this.style.boxShadow=''">
        <!-- Order Header -->
        <div style="padding:16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
          <div style="width:50px;height:50px;background:linear-gradient(135deg,#1a202c,#2d3748);border-radius:var(--radius);display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0;">${order.emoji}</div>
          <div style="flex:1;min-width:0;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:2px;flex-wrap:wrap;">
              <p style="font-weight:700;font-size:0.95rem;">${order.restaurant}</p>
              <span class="tag ${order.status === 'Delivered' ? 'tag-success' : 'tag-primary'}" style="font-size:0.7rem;">${order.status === 'Delivered' ? '✅' : '❌'} ${order.status}</span>
            </div>
            <p style="font-size:0.78rem;color:var(--text-muted);">${order.id} · ${order.date}</p>
          </div>
          <div style="text-align:right;flex-shrink:0;">
            <p style="font-weight:800;font-size:1rem;color:var(--text);">$${order.total.toFixed(2)}</p>
            <p style="font-size:0.72rem;color:var(--text-muted);">${order.items.length} item${order.items.length !== 1 ? 's' : ''}</p>
          </div>
        </div>

        <!-- Items Preview -->
        <div style="padding:12px 16px;border-bottom:1px solid var(--border);">
          <p style="font-size:0.78rem;color:var(--text-muted);">${order.items.map(i => i.emoji + ' ' + i.name + ' x' + i.qty).join(' · ')}</p>
        </div>

        <!-- Actions -->
        <div style="padding:12px 16px;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;">
          ${order.status === 'Delivered' ? `
            <div style="display:flex;gap:6px;flex-wrap:wrap;">
              ${order.rating > 0 ? `
                <div style="display:flex;align-items:center;gap:3px;">
                  ${[1,2,3,4,5].map(s => `<i class="fas fa-star" style="color:${s <= order.rating ? '#ECC94B' : 'var(--border)'};font-size:13px;"></i>`).join('')}
                  <span style="font-size:0.75rem;color:var(--text-muted);margin-left:4px;">Rated</span>
                </div>
              ` : `
                <button class="btn btn-ghost btn-sm" style="font-size:0.78rem;" onclick="openModal('rate-modal')">
                  <i class="fas fa-star" style="color:#ECC94B;"></i> Rate Order
                </button>
              `}
            </div>
            <div style="display:flex;gap:8px;">
              <button class="btn btn-outline btn-sm" onclick="openReorder(${JSON.stringify(order.items).replace(/"/g, '&quot;')})">
                <i class="fas fa-redo"></i> Reorder
              </button>
              <button class="btn btn-ghost btn-sm" onclick="QB.showToast('Opening support...','info')">
                <i class="fas fa-headset"></i> Help
              </button>
            </div>
          ` : `
            <span style="font-size:0.78rem;color:var(--text-muted);">Cancelled by user</span>
            <button class="btn btn-outline btn-sm" onclick="openReorder(${JSON.stringify(order.items).replace(/"/g, '&quot;')})">
              <i class="fas fa-redo"></i> Reorder
            </button>
          `}
        </div>
      </div>
    `).join('')}
  `
}
