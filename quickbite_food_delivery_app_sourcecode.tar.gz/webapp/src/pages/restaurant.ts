/**
 * QuickBite - Restaurant Detail Page
 * Full menu with categories, items, add to cart, reviews
 */
import { pageShell } from './layout'

const RESTAURANTS: Record<string, any> = {
  '1': { name:'Burger Palace', cuisine:'American · Burgers', rating:4.5, reviews:1243, time:'20-30', fee:2.99, dist:'1.2', emoji:'🍔', address:'123 Burger Ave, New York', phone:'+1 (212) 555-0101', isOpen:true, tags:['Dine-in','Takeaway','Delivery'], priceRange:'$$', categories:[
    { name:'Popular', items:[
      { id:'b1', name:'Classic Cheeseburger', price:8.99, desc:'Juicy beef patty with melted American cheese, fresh lettuce, tomato, and special sauce on a brioche bun', isVeg:false, rating:4.6, calories:520, popular:true, image:'🍔' },
      { id:'b2', name:'BBQ Bacon Burger', price:11.99, desc:'Smoky BBQ sauce with crispy bacon, caramelized onions, and cheddar cheese', isVeg:false, rating:4.8, calories:680, popular:true, image:'🥓' },
      { id:'b3', name:'Crispy Fries', price:3.99, desc:'Golden crispy fries seasoned with our signature spice blend', isVeg:true, rating:4.4, calories:320, popular:true, image:'🍟' },
    ]},
    { name:'Burgers', items:[
      { id:'b1', name:'Classic Cheeseburger', price:8.99, desc:'Juicy beef patty with melted American cheese, fresh lettuce, tomato, and special sauce on a brioche bun', isVeg:false, rating:4.6, calories:520, popular:false, image:'🍔' },
      { id:'b2', name:'BBQ Bacon Burger', price:11.99, desc:'Smoky BBQ sauce with crispy bacon, caramelized onions, and cheddar cheese', isVeg:false, rating:4.8, calories:680, popular:false, image:'🥓' },
      { id:'b3', name:'Veggie Delight', price:9.99, desc:'Fresh veggie patty with lettuce, avocado, and herb aioli', isVeg:true, rating:4.3, calories:420, popular:false, image:'🥬' },
      { id:'b4', name:'Double Stack', price:13.99, desc:'Two beef patties stacked high with double cheese and all the toppings', isVeg:false, rating:4.7, calories:820, popular:false, image:'🍔' },
      { id:'b5', name:'Spicy Jalapeño Burger', price:10.99, desc:'Fiery jalapeños with pepper jack cheese and chipotle mayo', isVeg:false, rating:4.5, calories:600, popular:false, image:'🌶️' },
    ]},
    { name:'Sides', items:[
      { id:'s1', name:'Crispy Fries', price:3.99, desc:'Golden crispy fries seasoned with our signature spice blend', isVeg:true, rating:4.4, calories:320, popular:false, image:'🍟' },
      { id:'s2', name:'Onion Rings', price:4.49, desc:'Beer-battered onion rings with ranch dipping sauce', isVeg:true, rating:4.2, calories:380, popular:false, image:'🧅' },
      { id:'s3', name:'Coleslaw', price:2.99, desc:'Creamy homemade coleslaw with a hint of apple cider', isVeg:true, rating:4.0, calories:180, popular:false, image:'🥗' },
      { id:'s4', name:'Mac & Cheese', price:5.99, desc:'Creamy macaroni with four-cheese blend', isVeg:true, rating:4.6, calories:450, popular:false, image:'🧀' },
    ]},
    { name:'Drinks', items:[
      { id:'d1', name:'Classic Cola', price:2.49, desc:'Chilled classic cola served with ice', isVeg:true, rating:4.0, calories:150, popular:false, image:'🥤' },
      { id:'d2', name:'Vanilla Milkshake', price:5.49, desc:'Thick and creamy vanilla shake made with premium ice cream', isVeg:true, rating:4.7, calories:480, popular:false, image:'🥛' },
      { id:'d3', name:'Lemonade', price:3.49, desc:'Fresh-squeezed lemonade with mint', isVeg:true, rating:4.3, calories:120, popular:false, image:'🍋' },
    ]},
    { name:'Desserts', items:[
      { id:'ds1', name:'Chocolate Brownie', price:4.99, desc:'Warm fudgy brownie with vanilla ice cream', isVeg:true, rating:4.8, calories:380, popular:false, image:'🍫' },
      { id:'ds2', name:'Cheesecake Slice', price:5.49, desc:'New York style cheesecake with berry compote', isVeg:true, rating:4.7, calories:420, popular:false, image:'🍰' },
    ]},
  ]},
  '2': { name:'Pizza Heaven', cuisine:'Italian · Pizza', rating:4.7, reviews:2156, time:'25-35', fee:1.99, dist:'0.8', emoji:'🍕', address:'456 Napoli St, Brooklyn', phone:'+1 (718) 555-0202', isOpen:true, tags:['Dine-in','Takeaway','Delivery'], priceRange:'$$', categories:[
    { name:'Popular', items:[
      { id:'p2', name:'Pepperoni', price:14.99, desc:'Loaded with premium pepperoni and mozzarella', isVeg:false, rating:4.9, calories:820, popular:true, image:'🍕' },
      { id:'p1', name:'Margherita', price:12.99, desc:'Classic tomato, fresh mozzarella and basil', isVeg:true, rating:4.8, calories:680, popular:true, image:'🍅' },
      { id:'pa1', name:'Spaghetti Bolognese', price:11.99, desc:'Rich meat sauce with al dente pasta', isVeg:false, rating:4.7, calories:680, popular:true, image:'🍝' },
    ]},
    { name:'Pizzas', items:[
      { id:'p1', name:'Margherita', price:12.99, desc:'Classic tomato, fresh mozzarella and basil', isVeg:true, rating:4.8, calories:680, popular:false, image:'🍅' },
      { id:'p2', name:'Pepperoni', price:14.99, desc:'Loaded with premium pepperoni and mozzarella', isVeg:false, rating:4.9, calories:820, popular:false, image:'🍕' },
      { id:'p3', name:'BBQ Chicken', price:15.99, desc:'Smoky BBQ base with tender chicken and red onions', isVeg:false, rating:4.6, calories:780, popular:false, image:'🍗' },
      { id:'p4', name:'Veggie Supreme', price:13.99, desc:'Loaded with seasonal fresh vegetables', isVeg:true, rating:4.5, calories:620, popular:false, image:'🥦' },
      { id:'p5', name:'Four Cheese', price:14.49, desc:'Mozzarella, cheddar, gorgonzola, and parmesan', isVeg:true, rating:4.7, calories:860, popular:false, image:'🧀' },
    ]},
    { name:'Pasta', items:[
      { id:'pa1', name:'Spaghetti Bolognese', price:11.99, desc:'Rich meat sauce with al dente spaghetti', isVeg:false, rating:4.7, calories:680, popular:false, image:'🍝' },
      { id:'pa2', name:'Penne Arrabbiata', price:10.99, desc:'Spicy tomato and chilli sauce', isVeg:true, rating:4.4, calories:580, popular:false, image:'🌶️' },
      { id:'pa3', name:'Fettuccine Alfredo', price:12.99, desc:'Creamy white sauce with grilled chicken', isVeg:false, rating:4.6, calories:740, popular:false, image:'🍜' },
    ]},
  ]},
}

// Default restaurant for other IDs
const DEFAULT_REST = RESTAURANTS['1']

function getRestaurant(id: string) {
  return RESTAURANTS[id] || { ...DEFAULT_REST, id }
}

function renderMenuItem(item: any): string {
  return `
    <div class="menu-item" id="item-${item.id}" style="display:flex;align-items:flex-start;gap:14px;padding:16px 0;border-bottom:1px solid var(--border);">
      <!-- Item Details -->
      <div style="flex:1;min-width:0;">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;">
          ${item.isVeg
            ? '<div style="width:16px;height:16px;border:1.5px solid #38A169;border-radius:3px;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;"><div style="width:8px;height:8px;border-radius:50%;background:#38A169;"></div></div>'
            : '<div style="width:16px;height:16px;border:1.5px solid #E53E3E;border-radius:3px;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;"><div style="width:8px;height:8px;border-radius:50%;background:#E53E3E;"></div></div>'
          }
          <h4 style="font-size:0.925rem;font-weight:600;color:var(--text);">${item.name}</h4>
          ${item.popular ? '<span style="background:rgba(229,62,62,0.1);color:var(--primary);padding:1px 6px;border-radius:var(--radius-full);font-size:0.65rem;font-weight:700;flex-shrink:0;">BESTSELLER</span>' : ''}
        </div>
        <p style="font-size:0.8rem;color:var(--text-muted);margin-bottom:6px;line-height:1.4;">${item.desc}</p>
        <div style="display:flex;align-items:center;gap:10px;">
          <span style="font-size:1rem;font-weight:700;color:var(--text);">$${item.price.toFixed(2)}</span>
          <span style="display:flex;align-items:center;gap:3px;font-size:0.75rem;color:#D69E2E;">
            <i class="fas fa-star"></i> ${item.rating}
          </span>
          <span style="font-size:0.72rem;color:var(--text-muted);">
            <i class="fas fa-fire" style="color:var(--secondary);"></i> ${item.calories} cal
          </span>
        </div>
      </div>

      <!-- Image + Add Button -->
      <div style="flex-shrink:0;text-align:center;">
        <div style="width:88px;height:88px;background:linear-gradient(135deg,#1a202c,#2d3748);border-radius:var(--radius);display:flex;align-items:center;justify-content:center;font-size:42px;margin-bottom:8px;position:relative;">
          ${item.image}
        </div>
        <div id="add-area-${item.id}">
          <button class="btn btn-primary btn-sm" onclick="addItem('${item.id}','${item.name.replace(/'/g,"\\'")}',${item.price},'${item.image}')" style="width:88px;padding:6px 0;">
            <i class="fas fa-plus"></i> Add
          </button>
        </div>
        <div id="qty-area-${item.id}" style="display:none;">
          <div class="qty-control" style="width:88px;justify-content:space-between;">
            <button class="qty-btn" onclick="changeItemQty('${item.id}',-1,'${item.name.replace(/'/g,"\\'")}',${item.price},'${item.image}')">−</button>
            <span class="qty-val" id="qty-val-${item.id}">1</span>
            <button class="qty-btn" onclick="changeItemQty('${item.id}',1,'${item.name.replace(/'/g,"\\'")}',${item.price},'${item.image}')">+</button>
          </div>
        </div>
      </div>
    </div>
  `
}

export function renderRestaurant(id: string): string {
  const rest = getRestaurant(id)

  const content = `
  <!-- Hero Banner -->
  <div style="background:linear-gradient(135deg,#0f1117 0%,#1a202c 50%,#2d3748 100%);padding:40px 0 0;">
    <div class="container">
      <div style="display:flex;align-items:flex-end;gap:20px;padding-bottom:0;flex-wrap:wrap;">
        <div style="width:100px;height:100px;background:rgba(255,255,255,0.1);border-radius:var(--radius-lg);display:flex;align-items:center;justify-content:center;font-size:56px;flex-shrink:0;border:2px solid rgba(255,255,255,0.1);">
          ${rest.emoji}
        </div>
        <div style="flex:1;min-width:0;padding-bottom:16px;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;flex-wrap:wrap;">
            <h1 style="color:white;font-size:1.6rem;">${rest.name}</h1>
            ${rest.isOpen ? '<span class="tag tag-success" style="font-size:0.72rem;"><i class="fas fa-circle" style="font-size:8px;color:#38A169;"></i> Open Now</span>' : '<span class="tag" style="font-size:0.72rem;background:rgba(229,62,62,0.2);color:#FC8181;"><i class="fas fa-circle" style="font-size:8px;"></i> Closed</span>'}
          </div>
          <p style="color:rgba(255,255,255,0.7);font-size:0.875rem;margin-bottom:8px;">${rest.cuisine}</p>
          <div style="display:flex;gap:16px;flex-wrap:wrap;">
            <div style="display:flex;align-items:center;gap:4px;color:rgba(255,255,255,0.8);font-size:0.82rem;">
              <i class="fas fa-star" style="color:#ECC94B;"></i>
              <strong style="color:white;">${rest.rating}</strong>
              <span>(${rest.reviews >= 1000 ? (rest.reviews/1000).toFixed(1)+'k' : rest.reviews} reviews)</span>
            </div>
            <div style="display:flex;align-items:center;gap:4px;color:rgba(255,255,255,0.8);font-size:0.82rem;">
              <i class="fas fa-clock" style="color:#68D391;"></i>
              <span>${rest.time} min delivery</span>
            </div>
            <div style="display:flex;align-items:center;gap:4px;color:rgba(255,255,255,0.8);font-size:0.82rem;">
              <i class="fas fa-motorcycle" style="color:#63B3ED;"></i>
              <span>$${rest.fee.toFixed(2)} delivery fee</span>
            </div>
            <div style="display:flex;align-items:center;gap:4px;color:rgba(255,255,255,0.8);font-size:0.82rem;">
              <i class="fas fa-map-marker-alt" style="color:#FC8181;"></i>
              <span>${rest.dist} km away</span>
            </div>
          </div>
        </div>
        <div style="display:flex;gap:8px;padding-bottom:16px;flex-shrink:0;">
          <button class="btn btn-ghost" style="background:rgba(255,255,255,0.1);color:white;border:1px solid rgba(255,255,255,0.2);" onclick="toggleFavRest()">
            <i class="far fa-heart" id="fav-icon"></i>
          </button>
          <button class="btn btn-ghost" style="background:rgba(255,255,255,0.1);color:white;border:1px solid rgba(255,255,255,0.2);" onclick="QB.showToast('Link copied!','success');navigator.clipboard?.writeText(window.location.href)">
            <i class="fas fa-share-alt"></i>
          </button>
          <button class="btn btn-ghost" style="background:rgba(255,255,255,0.1);color:white;border:1px solid rgba(255,255,255,0.2);" onclick="scrollToReviews()">
            <i class="fas fa-comment"></i> Reviews
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Main Layout -->
  <div class="container" style="padding-top:24px;">
    <div style="display:grid;grid-template-columns:1fr 320px;gap:24px;" id="main-layout">

      <!-- Left: Menu -->
      <div>
        <!-- Search Menu -->
        <div style="position:relative;margin-bottom:20px;">
          <i class="fas fa-search" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:14px;"></i>
          <input type="text" class="form-input" placeholder="Search menu items..." style="padding-left:40px;" oninput="searchMenu(this.value)">
        </div>

        <!-- Category Tabs -->
        <div style="position:sticky;top:var(--header-height);z-index:100;background:var(--bg);padding:12px 0;margin-bottom:8px;">
          <div style="display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;">
            ${rest.categories.map((cat: any, i: number) => `
              <button class="chip ${i === 0 ? 'active' : ''}" id="cat-btn-${i}" onclick="scrollToCategory(${i},'${cat.name}')">
                ${cat.name}
              </button>
            `).join('')}
          </div>
        </div>

        <!-- Menu Sections -->
        <div id="menu-content">
          ${rest.categories.map((cat: any, i: number) => `
            <div class="menu-section" id="cat-section-${i}" style="margin-bottom:24px;">
              <h3 style="font-size:1.1rem;padding:12px 0 4px;border-bottom:2px solid var(--border);color:var(--text);">
                ${cat.name}
                <span style="font-size:0.8rem;font-weight:400;color:var(--text-muted);margin-left:8px;">(${cat.items.length} items)</span>
              </h3>
              ${cat.items.map(renderMenuItem).join('')}
            </div>
          `).join('')}
        </div>

        <!-- Reviews Section -->
        <div id="reviews-section" style="margin-top:32px;padding-top:24px;border-top:2px solid var(--border);">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
            <h3><i class="fas fa-star" style="color:#ECC94B;margin-right:8px;"></i>Ratings & Reviews</h3>
            <button class="btn btn-outline btn-sm" onclick="openModal('review-modal')">
              <i class="fas fa-edit"></i> Write Review
            </button>
          </div>

          <!-- Rating Summary -->
          <div style="display:grid;grid-template-columns:auto 1fr;gap:24px;background:var(--surface);border-radius:var(--radius-lg);padding:20px;border:1px solid var(--border);margin-bottom:20px;align-items:center;">
            <div style="text-align:center;">
              <div style="font-size:3rem;font-weight:800;color:var(--text);">${rest.rating}</div>
              <div style="display:flex;justify-content:center;gap:2px;margin:4px 0;">
                ${[1,2,3,4,5].map(s => `<i class="fas fa-star" style="color:${s <= Math.round(rest.rating) ? '#ECC94B' : 'var(--border)'};font-size:14px;"></i>`).join('')}
              </div>
              <p style="font-size:0.78rem;color:var(--text-muted);">${rest.reviews} reviews</p>
            </div>
            <div>
              ${[5,4,3,2,1].map(s => {
                const pct = s === 5 ? 65 : s === 4 ? 20 : s === 3 ? 8 : s === 2 ? 4 : 3
                return `
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
                  <span style="font-size:0.8rem;font-weight:600;width:20px;text-align:right;color:var(--text-secondary);">${s}</span>
                  <i class="fas fa-star" style="color:#ECC94B;font-size:12px;"></i>
                  <div class="progress-bar" style="flex:1;height:6px;"><div class="progress-fill" style="width:${pct}%;"></div></div>
                  <span style="font-size:0.75rem;color:var(--text-muted);width:30px;">${pct}%</span>
                </div>`
              }).join('')}
            </div>
          </div>

          <!-- Review Cards -->
          <div id="reviews-list">
            ${[
              { name:'Sarah M.', rating:5, date:'2 days ago', comment:'Amazing food! The Classic Cheeseburger was perfectly cooked. Will definitely order again!', helpful:12 },
              { name:'James K.', rating:4, date:'1 week ago', comment:'Great burgers, fast delivery. The BBQ Bacon Burger is my favorite!', helpful:8 },
              { name:'Emily R.', rating:5, date:'2 weeks ago', comment:'Best burgers in the city. The fries are always crispy and the shakes are incredible!', helpful:15 },
            ].map(rev => `
              <div style="padding:16px;border-radius:var(--radius-lg);background:var(--surface);border:1px solid var(--border);margin-bottom:12px;">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;flex-wrap:wrap;gap:8px;">
                  <div style="display:flex;align-items:center;gap:10px;">
                    <div style="width:38px;height:38px;border-radius:50%;background:var(--primary-gradient);display:flex;align-items:center;justify-content:center;color:white;font-weight:700;font-size:0.875rem;flex-shrink:0;">
                      ${rev.name.charAt(0)}
                    </div>
                    <div>
                      <p style="font-weight:600;font-size:0.875rem;color:var(--text);">${rev.name}</p>
                      <p style="font-size:0.75rem;color:var(--text-muted);">${rev.date}</p>
                    </div>
                  </div>
                  <div style="display:flex;gap:2px;">
                    ${[1,2,3,4,5].map(s => `<i class="fas fa-star" style="color:${s <= rev.rating ? '#ECC94B' : 'var(--border)'};font-size:13px;"></i>`).join('')}
                  </div>
                </div>
                <p style="font-size:0.875rem;color:var(--text-secondary);margin-bottom:10px;">${rev.comment}</p>
                <button style="background:none;border:1px solid var(--border);border-radius:var(--radius-full);padding:4px 12px;font-size:0.75rem;cursor:pointer;color:var(--text-muted);transition:var(--transition);" onmouseenter="this.style.borderColor='var(--primary)';this.style.color='var(--primary)'" onmouseleave="this.style.borderColor='var(--border)';this.style.color='var(--text-muted)'" onclick="this.innerHTML='<i class=\\'fas fa-thumbs-up\\'></i> Helpful (${rev.helpful + 1})'">
                  <i class="fas fa-thumbs-up"></i> Helpful (${rev.helpful})
                </button>
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <!-- Right: Cart Summary / Sticky -->
      <div id="cart-sidebar">
        <div style="position:sticky;top:80px;">
          <div class="card" id="cart-summary-card">
            <div class="card-body">
              <h3 style="margin-bottom:16px;display:flex;align-items:center;gap:8px;">
                <i class="fas fa-shopping-cart" style="color:var(--primary);"></i>
                Your Order
                <span id="cart-item-count" style="background:var(--primary);color:white;width:20px;height:20px;border-radius:50%;font-size:11px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;margin-left:auto;">0</span>
              </h3>
              <div id="sidebar-cart-items" style="min-height:80px;">
                <div style="text-align:center;padding:24px 0;color:var(--text-muted);">
                  <i class="fas fa-shopping-basket" style="font-size:32px;margin-bottom:8px;display:block;opacity:0.3;"></i>
                  <p style="font-size:0.875rem;">Add items to your cart</p>
                </div>
              </div>
              <div id="cart-totals" style="display:none;">
                <div style="border-top:1px solid var(--border);padding-top:12px;margin-top:8px;">
                  <div style="display:flex;justify-content:space-between;font-size:0.875rem;color:var(--text-secondary);margin-bottom:6px;">
                    <span>Subtotal</span><span id="subtotal-val">$0.00</span>
                  </div>
                  <div style="display:flex;justify-content:space-between;font-size:0.875rem;color:var(--text-secondary);margin-bottom:6px;">
                    <span>Delivery fee</span><span>$${rest.fee.toFixed(2)}</span>
                  </div>
                  <div style="display:flex;justify-content:space-between;font-size:0.875rem;color:var(--text-secondary);margin-bottom:12px;">
                    <span>Taxes (8%)</span><span id="tax-val">$0.00</span>
                  </div>
                  <div style="display:flex;justify-content:space-between;font-size:1.05rem;font-weight:700;color:var(--text);padding-top:10px;border-top:1px solid var(--border);">
                    <span>Total</span><span id="total-val">$0.00</span>
                  </div>
                </div>
                <button class="btn btn-primary btn-full" style="margin-top:16px;" onclick="window.location.href='/checkout'">
                  <i class="fas fa-lock"></i> Proceed to Checkout
                </button>
                <button class="btn btn-ghost btn-full btn-sm" style="margin-top:8px;" onclick="window.location.href='/cart'">
                  <i class="fas fa-shopping-cart"></i> View Full Cart
                </button>
              </div>
            </div>
          </div>

          <!-- Restaurant Info Card -->
          <div class="card" style="margin-top:16px;">
            <div class="card-body">
              <h4 style="margin-bottom:12px;font-size:0.9rem;"><i class="fas fa-info-circle" style="color:var(--primary);margin-right:6px;"></i>Restaurant Info</h4>
              <div style="font-size:0.82rem;color:var(--text-secondary);">
                <div style="display:flex;gap:10px;margin-bottom:8px;">
                  <i class="fas fa-map-marker-alt" style="color:var(--primary);width:16px;flex-shrink:0;margin-top:2px;"></i>
                  <span>${rest.address}</span>
                </div>
                <div style="display:flex;gap:10px;margin-bottom:8px;">
                  <i class="fas fa-phone" style="color:var(--success);width:16px;flex-shrink:0;"></i>
                  <a href="tel:${rest.phone}" style="color:var(--info);">${rest.phone}</a>
                </div>
                <div style="display:flex;gap:10px;margin-bottom:8px;">
                  <i class="fas fa-clock" style="color:var(--warning);width:16px;flex-shrink:0;"></i>
                  <span>Open: 10:00 AM - 11:00 PM</span>
                </div>
                <div style="display:flex;gap:10px;">
                  <i class="fas fa-motorcycle" style="color:var(--info);width:16px;flex-shrink:0;"></i>
                  <span>Min order: $10.00</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Review Modal -->
  <div class="modal-overlay" id="review-modal">
    <div class="modal">
      <div class="modal-header">
        <h3><i class="fas fa-star" style="color:#ECC94B;margin-right:8px;"></i>Write a Review</h3>
        <button class="modal-close" onclick="closeModal('review-modal')"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <p style="margin-bottom:16px;font-size:0.875rem;color:var(--text-secondary);">How was your experience at ${rest.name}?</p>
        <div style="text-align:center;margin-bottom:20px;">
          <div class="rating-input" style="justify-content:center;">
            ${[1,2,3,4,5].map(s => `<span class="rating-star" data-val="${s}" onclick="setRating(${s})">★</span>`).join('')}
          </div>
          <p id="rating-label" style="font-size:0.875rem;color:var(--text-muted);margin-top:8px;">Click to rate</p>
        </div>
        <div class="form-group">
          <label class="form-label">Your Review</label>
          <textarea class="form-input" rows="3" placeholder="Tell others about your experience..." id="review-text" style="resize:vertical;"></textarea>
        </div>
        <div class="form-group">
          <label class="form-label">Your Name</label>
          <input type="text" class="form-input" placeholder="Enter your name" id="reviewer-name">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('review-modal')">Cancel</button>
        <button class="btn btn-primary" onclick="submitReview()"><i class="fas fa-paper-plane"></i> Submit Review</button>
      </div>
    </div>
  </div>
  `

  const scripts = `
  <script>
    const DELIVERY_FEE = ${rest.fee};
    let selectedRating = 0;

    // ── Cart Sync ─────────────────────────────────────────
    function syncCart() {
      const cart = QB.cart;
      const sidebarItems = document.getElementById('sidebar-cart-items');
      const cartTotals = document.getElementById('cart-totals');
      const cartCount = document.getElementById('cart-item-count');

      if (cart.length === 0) {
        sidebarItems.innerHTML = '<div style="text-align:center;padding:24px 0;color:var(--text-muted);"><i class="fas fa-shopping-basket" style="font-size:32px;margin-bottom:8px;display:block;opacity:0.3;"></i><p style="font-size:0.875rem;">Add items to your cart</p></div>';
        cartTotals.style.display = 'none';
        cartCount.textContent = '0';
        return;
      }

      cartCount.textContent = cart.reduce((s,i) => s + i.qty, 0);
      cartTotals.style.display = 'block';

      sidebarItems.innerHTML = cart.map(item => \`
        <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border);">
          <span style="font-size:22px;">\${item.image}</span>
          <div style="flex:1;min-width:0;">
            <p style="font-size:0.82rem;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">\${item.name}</p>
            <p style="font-size:0.78rem;color:var(--text-muted);">$\${item.price.toFixed(2)} each</p>
          </div>
          <div class="qty-control" style="transform:scale(0.85);transform-origin:right;">
            <button class="qty-btn" onclick="changeItemQty('\${item.id}',-1,'\${item.name}',\${item.price},'\${item.image}')">−</button>
            <span class="qty-val">\${item.qty}</span>
            <button class="qty-btn" onclick="changeItemQty('\${item.id}',1,'\${item.name}',\${item.price},'\${item.image}')">+</button>
          </div>
        </div>
      \`).join('');

      const subtotal = QB.cartTotal;
      const tax = subtotal * 0.08;
      const total = subtotal + DELIVERY_FEE + tax;
      document.getElementById('subtotal-val').textContent = '$' + subtotal.toFixed(2);
      document.getElementById('tax-val').textContent = '$' + tax.toFixed(2);
      document.getElementById('total-val').textContent = '$' + total.toFixed(2);
    }

    function addItem(id, name, price, image) {
      QB.addToCart({ id, name, price, image: image || '🍽️' });
      document.getElementById('add-area-' + id).style.display = 'none';
      document.getElementById('qty-area-' + id).style.display = 'block';
      syncCart();
    }

    function changeItemQty(id, delta, name, price, image) {
      QB.updateQty(id, delta);
      const newQty = (QB.cart.find(i => i.id === id) || {}).qty || 0;
      if (newQty === 0) {
        document.getElementById('add-area-' + id).style.display = 'block';
        document.getElementById('qty-area-' + id).style.display = 'none';
      } else {
        const qv = document.getElementById('qty-val-' + id);
        if (qv) qv.textContent = newQty;
      }
      syncCart();
    }

    // ── Category Scroll ───────────────────────────────────
    function scrollToCategory(idx, name) {
      document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
      document.getElementById('cat-btn-' + idx)?.classList.add('active');
      const section = document.getElementById('cat-section-' + idx);
      if (section) {
        const offset = section.getBoundingClientRect().top + window.scrollY - 130;
        window.scrollTo({ top: offset, behavior: 'smooth' });
      }
    }

    // ── Search Menu ───────────────────────────────────────
    function searchMenu(q) {
      const items = document.querySelectorAll('.menu-item');
      const sections = document.querySelectorAll('.menu-section');
      items.forEach(item => {
        const name = item.querySelector('h4').textContent.toLowerCase();
        const desc = item.querySelector('p').textContent.toLowerCase();
        item.style.display = (!q || name.includes(q.toLowerCase()) || desc.includes(q.toLowerCase())) ? '' : 'none';
      });
    }

    // ── Reviews ───────────────────────────────────────────
    function scrollToReviews() {
      document.getElementById('reviews-section')?.scrollIntoView({ behavior:'smooth' });
    }

    function setRating(val) {
      selectedRating = val;
      const labels = ['Terrible', 'Poor', 'Average', 'Good', 'Excellent'];
      document.getElementById('rating-label').textContent = labels[val-1] + ' (' + val + '/5)';
      document.querySelectorAll('.rating-star').forEach((s, i) => {
        s.classList.toggle('active', i < val);
        s.style.color = i < val ? '#ECC94B' : 'var(--border)';
      });
    }

    function submitReview() {
      if (!selectedRating) { QB.showToast('Please select a rating!', 'error'); return; }
      const text = document.getElementById('review-text').value.trim();
      const name = document.getElementById('reviewer-name').value.trim() || 'Anonymous';
      if (!text) { QB.showToast('Please write a review!', 'error'); return; }
      const reviewEl = document.getElementById('reviews-list');
      const newReview = \`
        <div style="padding:16px;border-radius:var(--radius-lg);background:rgba(56,161,105,0.05);border:1px solid rgba(56,161,105,0.2);margin-bottom:12px;animation:fadeIn 0.3s ease;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
            <div style="display:flex;align-items:center;gap:10px;">
              <div style="width:38px;height:38px;border-radius:50%;background:var(--primary-gradient);display:flex;align-items:center;justify-content:center;color:white;font-weight:700;">\${name.charAt(0).toUpperCase()}</div>
              <div><p style="font-weight:600;font-size:0.875rem;">\${name}</p><p style="font-size:0.75rem;color:var(--text-muted);">Just now</p></div>
            </div>
            <div style="display:flex;gap:2px;">\${Array.from({length:5}).map((_,i)=>'<i class="fas fa-star" style="color:'+(i<selectedRating?'#ECC94B':'var(--border)')+';font-size:13px;"></i>').join('')}</div>
          </div>
          <p style="font-size:0.875rem;color:var(--text-secondary);">\${text}</p>
        </div>
      \`;
      reviewEl.insertAdjacentHTML('afterbegin', newReview);
      closeModal('review-modal');
      QB.showToast('Review submitted! Thank you 🌟', 'success');
    }

    function toggleFavRest() {
      const icon = document.getElementById('fav-icon');
      const isFav = icon.classList.contains('fas');
      icon.className = isFav ? 'far fa-heart' : 'fas fa-heart';
      icon.style.color = isFav ? '' : '#E53E3E';
      QB.showToast(isFav ? 'Removed from favorites' : '❤️ Added to favorites!', 'success');
    }

    // ── Mobile Layout ─────────────────────────────────────
    function handleResize() {
      const sidebar = document.getElementById('cart-sidebar');
      const layout = document.getElementById('main-layout');
      if (window.innerWidth <= 768) {
        layout.style.gridTemplateColumns = '1fr';
        sidebar.style.display = 'none';
      } else {
        layout.style.gridTemplateColumns = '1fr 320px';
        sidebar.style.display = '';
      }
    }
    window.addEventListener('resize', handleResize);
    handleResize();

    // ── Init ───────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', () => {
      // Pre-fill qty controls from saved cart
      const cart = QB.cart;
      cart.forEach(item => {
        const addArea = document.getElementById('add-area-' + item.id);
        const qtyArea = document.getElementById('qty-area-' + item.id);
        const qtyVal = document.getElementById('qty-val-' + item.id);
        if (addArea && qtyArea && item.qty > 0) {
          addArea.style.display = 'none';
          qtyArea.style.display = 'block';
          if (qtyVal) qtyVal.textContent = item.qty;
        }
      });
      syncCart();
    });
  </script>
  `

  return pageShell(rest.name + ' Menu', content, 'restaurant', scripts)
}
