/**
 * QuickBite - Admin Panel
 * Dashboard with analytics, restaurant management, menu management, order management
 */
import { pageShell } from './layout'

export function renderAdmin(section: string = 'dashboard'): string {
  const content = `
  <style>
    .admin-layout { display:grid; grid-template-columns:240px 1fr; min-height:calc(100vh - 64px); }
    .admin-sidebar { background:var(--surface); border-right:1px solid var(--border); padding:20px 0; position:sticky; top:64px; height:calc(100vh - 64px); overflow-y:auto; }
    .admin-content { padding:24px; overflow:auto; }
    .stat-card { background:var(--surface); border-radius:var(--radius-lg); padding:20px; border:1px solid var(--border); transition:var(--transition); }
    .stat-card:hover { transform:translateY(-2px); box-shadow:var(--shadow-md); }
    .admin-table { width:100%; border-collapse:collapse; }
    .admin-table th { padding:12px 16px; text-align:left; font-size:0.78rem; font-weight:600; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.5px; background:var(--surface-2); border-bottom:1px solid var(--border); }
    .admin-table td { padding:14px 16px; border-bottom:1px solid var(--border); font-size:0.875rem; color:var(--text); vertical-align:middle; }
    .admin-table tr:hover td { background:var(--surface-2); }
    @media (max-width:768px) {
      .admin-layout { grid-template-columns:1fr; }
      .admin-sidebar { display:none; }
    }
  </style>

  <div class="admin-layout">
    <!-- Sidebar -->
    <div class="admin-sidebar">
      <div style="padding:0 16px 16px;border-bottom:1px solid var(--border);margin-bottom:8px;">
        <div style="display:flex;align-items:center;gap:10px;">
          <div style="width:36px;height:36px;background:var(--primary-gradient);border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;color:white;font-size:16px;">👑</div>
          <div>
            <p style="font-weight:700;font-size:0.875rem;">Admin Panel</p>
            <p style="font-size:0.72rem;color:var(--text-muted);">QuickBite Dashboard</p>
          </div>
        </div>
      </div>

      ${[
        { id:'dashboard', icon:'fa-chart-line', label:'Dashboard' },
        { id:'orders', icon:'fa-receipt', label:'Orders', badge:'18' },
        { id:'restaurants', icon:'fa-store', label:'Restaurants' },
        { id:'menu', icon:'fa-utensils', label:'Menu Items' },
        { id:'users', icon:'fa-users', label:'Users' },
        { id:'promo', icon:'fa-tags', label:'Promo Codes' },
        { id:'reviews', icon:'fa-star', label:'Reviews' },
        { id:'settings', icon:'fa-cog', label:'Settings' },
      ].map(item => `
        <div id="admin-nav-${item.id}" onclick="switchAdminSection('${item.id}')"
          style="display:flex;align-items:center;gap:10px;padding:12px 16px;cursor:pointer;transition:var(--transition);${item.id === section ? 'background:rgba(229,62,62,0.08);border-left:3px solid var(--primary);' : 'border-left:3px solid transparent;'}">
          <i class="fas ${item.icon}" style="width:16px;color:${item.id === section ? 'var(--primary)' : 'var(--text-muted)'};"></i>
          <span style="font-size:0.875rem;font-weight:600;color:${item.id === section ? 'var(--primary)' : 'var(--text)'};">${item.label}</span>
          ${item.badge ? `<span style="margin-left:auto;background:var(--primary);color:white;padding:1px 7px;border-radius:var(--radius-full);font-size:0.7rem;font-weight:700;">${item.badge}</span>` : ''}
        </div>
      `).join('')}

      <div style="padding:16px;margin-top:auto;border-top:1px solid var(--border);margin-top:20px;">
        <a href="/" class="btn btn-ghost btn-full btn-sm" style="justify-content:center;">
          <i class="fas fa-arrow-left"></i> Back to App
        </a>
      </div>
    </div>

    <!-- Content Area -->
    <div class="admin-content">

      <!-- ── DASHBOARD ─────────────────────────────────────── -->
      <div id="admin-section-dashboard" ${section !== 'dashboard' ? 'style="display:none"' : ''}>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
          <div>
            <h2 style="font-size:1.4rem;">Dashboard</h2>
            <p style="color:var(--text-muted);font-size:0.875rem;">Welcome back, Admin! Here's what's happening.</p>
          </div>
          <div style="display:flex;gap:8px;align-items:center;">
            <select class="form-input" style="padding:8px 12px;font-size:0.82rem;width:auto;">
              <option>Last 7 days</option>
              <option>Last 30 days</option>
              <option>Last 3 months</option>
            </select>
            <button class="btn btn-primary btn-sm" onclick="QB.showToast('Report exported!','success')">
              <i class="fas fa-download"></i> Export
            </button>
          </div>
        </div>

        <!-- Stats Row -->
        <div class="grid-4" style="margin-bottom:24px;">
          ${[
            { icon:'fa-dollar-sign', label:'Total Sales', val:'$45,678', change:'+12.5%', up:true, color:'#38A169', bg:'rgba(56,161,105,0.1)' },
            { icon:'fa-shopping-bag', label:'Total Orders', val:'1,243', change:'+8.2%', up:true, color:'#3182CE', bg:'rgba(49,130,206,0.1)' },
            { icon:'fa-users', label:'Active Users', val:'8,921', change:'+15.3%', up:true, color:'#805AD5', bg:'rgba(128,90,213,0.1)' },
            { icon:'fa-store', label:'Restaurants', val:'48', change:'+3 new', up:true, color:'var(--primary)', bg:'rgba(229,62,62,0.1)' },
          ].map(s => `
            <div class="stat-card">
              <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:12px;">
                <div style="width:44px;height:44px;border-radius:var(--radius);background:${s.bg};display:flex;align-items:center;justify-content:center;">
                  <i class="fas ${s.icon}" style="color:${s.color};font-size:18px;"></i>
                </div>
                <span style="font-size:0.75rem;font-weight:600;color:${s.up ? 'var(--success)' : 'var(--primary)'};background:${s.up ? 'rgba(56,161,105,0.1)' : 'rgba(229,62,62,0.1)'};padding:3px 8px;border-radius:var(--radius-full);">
                  <i class="fas fa-arrow-${s.up ? 'up' : 'down'}"></i> ${s.change}
                </span>
              </div>
              <h3 style="font-size:1.6rem;font-weight:800;color:var(--text);margin-bottom:4px;">${s.val}</h3>
              <p style="font-size:0.78rem;color:var(--text-muted);">${s.label}</p>
            </div>
          `).join('')}
        </div>

        <!-- Charts Row -->
        <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;margin-bottom:24px;">
          <!-- Revenue Chart -->
          <div class="card">
            <div class="card-body">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                <h4>Revenue Overview</h4>
                <div style="display:flex;gap:6px;">
                  <button class="chip active" id="chart-daily" onclick="switchChart('daily')" style="font-size:0.72rem;padding:3px 10px;">Daily</button>
                  <button class="chip" id="chart-monthly" onclick="switchChart('monthly')" style="font-size:0.72rem;padding:3px 10px;">Monthly</button>
                </div>
              </div>
              <!-- Bar Chart Visualization -->
              <div style="height:200px;display:flex;align-items:flex-end;gap:8px;padding-bottom:20px;position:relative;">
                <div style="position:absolute;left:0;right:0;bottom:20px;height:1px;background:var(--border);"></div>
                <div style="position:absolute;left:0;right:0;bottom:70px;height:1px;background:var(--border);opacity:0.5;"></div>
                <div style="position:absolute;left:0;right:0;bottom:120px;height:1px;background:var(--border);opacity:0.5;"></div>
                ${[65,82,58,91,74,95,88,72,85,78,92,87].map((h, i) => {
                  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
                  return `
                    <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;">
                      <div style="width:100%;background:var(--primary-gradient);border-radius:4px 4px 0 0;height:${h * 1.6}px;transition:height 0.8s ease;position:relative;cursor:pointer;"
                        onmouseenter="this.querySelector('.chart-tooltip').style.display='block'"
                        onmouseleave="this.querySelector('.chart-tooltip').style.display='none'">
                        <div class="chart-tooltip" style="display:none;position:absolute;top:-30px;left:50%;transform:translateX(-50%);background:#1a202c;color:white;padding:4px 8px;border-radius:6px;font-size:0.7rem;white-space:nowrap;z-index:10;">
                          $${(h * 400).toLocaleString()}
                        </div>
                      </div>
                      <span style="font-size:0.6rem;color:var(--text-muted);">${months[i]}</span>
                    </div>
                  `
                }).join('')}
              </div>
            </div>
          </div>

          <!-- Order Status Pie -->
          <div class="card">
            <div class="card-body">
              <h4 style="margin-bottom:16px;">Order Status</h4>
              <!-- Donut chart simulation -->
              <div style="position:relative;width:140px;height:140px;margin:0 auto 16px;">
                <svg viewBox="0 0 36 36" style="width:140px;height:140px;transform:rotate(-90deg);">
                  <circle cx="18" cy="18" r="15.9" fill="none" stroke="var(--border)" stroke-width="3"/>
                  <circle cx="18" cy="18" r="15.9" fill="none" stroke="#38A169" stroke-width="3" stroke-dasharray="62 38" stroke-dashoffset="0"/>
                  <circle cx="18" cy="18" r="15.9" fill="none" stroke="#3182CE" stroke-width="3" stroke-dasharray="20 80" stroke-dashoffset="-62"/>
                  <circle cx="18" cy="18" r="15.9" fill="none" stroke="#D69E2E" stroke-width="3" stroke-dasharray="10 90" stroke-dashoffset="-82"/>
                  <circle cx="18" cy="18" r="15.9" fill="none" stroke="#E53E3E" stroke-width="3" stroke-dasharray="8 92" stroke-dashoffset="-92"/>
                </svg>
                <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center;">
                  <p style="font-size:1.3rem;font-weight:800;color:var(--text);">1,243</p>
                  <p style="font-size:0.65rem;color:var(--text-muted);">orders</p>
                </div>
              </div>
              ${[
                { label:'Delivered', pct:62, color:'#38A169' },
                { label:'Out for Delivery', pct:20, color:'#3182CE' },
                { label:'Preparing', pct:10, color:'#D69E2E' },
                { label:'Cancelled', pct:8, color:'#E53E3E' },
              ].map(s => `
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                  <div style="width:10px;height:10px;border-radius:50%;background:${s.color};flex-shrink:0;"></div>
                  <span style="font-size:0.78rem;flex:1;color:var(--text-secondary);">${s.label}</span>
                  <span style="font-size:0.78rem;font-weight:700;color:var(--text);">${s.pct}%</span>
                </div>
              `).join('')}
            </div>
          </div>
        </div>

        <!-- Recent Orders + Top Restaurants -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
          <!-- Recent Orders -->
          <div class="card">
            <div class="card-body">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                <h4>Recent Orders</h4>
                <button class="btn btn-ghost btn-sm" onclick="switchAdminSection('orders')">View All →</button>
              </div>
              <table class="admin-table">
                <thead><tr><th>Order</th><th>Restaurant</th><th>Amount</th><th>Status</th></tr></thead>
                <tbody>
                  ${[
                    { id:'QB123456', rest:'Burger Palace', amount:'$23.48', status:'Preparing', color:'#D69E2E' },
                    { id:'QB123457', rest:'Pizza Heaven', amount:'$16.98', status:'Delivered', color:'#38A169' },
                    { id:'QB123458', rest:'Sushi World', amount:'$44.97', status:'Out for Delivery', color:'#3182CE' },
                    { id:'QB123459', rest:'Taco Fiesta', amount:'$12.96', status:'Confirmed', color:'#805AD5' },
                    { id:'QB123460', rest:'Curry House', amount:'$31.45', status:'Delivered', color:'#38A169' },
                  ].map(o => `
                    <tr>
                      <td style="font-family:monospace;font-size:0.78rem;font-weight:700;color:var(--primary);">${o.id}</td>
                      <td>${o.rest}</td>
                      <td style="font-weight:700;">${o.amount}</td>
                      <td><span style="background:${o.color}20;color:${o.color};padding:3px 8px;border-radius:var(--radius-full);font-size:0.72rem;font-weight:600;">${o.status}</span></td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>

          <!-- Top Restaurants -->
          <div class="card">
            <div class="card-body">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                <h4>Top Restaurants</h4>
                <button class="btn btn-ghost btn-sm" onclick="switchAdminSection('restaurants')">View All →</button>
              </div>
              ${[
                { name:'Burger Palace', emoji:'🍔', orders:234, revenue:'$4,521', rating:4.5 },
                { name:'Pizza Heaven', emoji:'🍕', orders:189, revenue:'$3,892', rating:4.7 },
                { name:'Curry House', emoji:'🍛', orders:167, revenue:'$5,234', rating:4.7 },
                { name:'Sushi World', emoji:'🍱', orders:143, revenue:'$6,178', rating:4.8 },
                { name:'Taco Fiesta', emoji:'🌮', orders:121, revenue:'$2,341', rating:4.3 },
              ].map((r, i) => `
                <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border);">
                  <span style="font-size:0.78rem;font-weight:700;color:var(--text-muted);width:20px;">#${i+1}</span>
                  <span style="font-size:22px;">${r.emoji}</span>
                  <div style="flex:1;min-width:0;">
                    <p style="font-weight:600;font-size:0.875rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${r.name}</p>
                    <p style="font-size:0.72rem;color:var(--text-muted);">${r.orders} orders · ⭐${r.rating}</p>
                  </div>
                  <span style="font-weight:700;font-size:0.875rem;color:var(--success);">${r.revenue}</span>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>

      <!-- ── ORDERS ─────────────────────────────────────── -->
      <div id="admin-section-orders" style="display:none;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
          <h2 style="font-size:1.4rem;">Orders Management</h2>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <input type="text" class="form-input" placeholder="Search orders..." style="padding:8px 14px;width:200px;font-size:0.82rem;" oninput="filterAdminOrders(this.value)">
            <select class="form-input" style="padding:8px;font-size:0.82rem;width:auto;" onchange="filterOrderStatus(this.value)">
              <option value="all">All Status</option>
              <option value="preparing">Preparing</option>
              <option value="delivery">Out for Delivery</option>
              <option value="delivered">Delivered</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>

        <div class="card">
          <div style="overflow-x:auto;">
            <table class="admin-table" id="orders-table">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Customer</th>
                  <th>Restaurant</th>
                  <th>Items</th>
                  <th>Amount</th>
                  <th>Payment</th>
                  <th>Time</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${[
                  { id:'QB123456', customer:'Sarah M.', rest:'Burger Palace', items:3, amount:'$23.48', payment:'UPI', time:'2 min ago', status:'Preparing' },
                  { id:'QB123457', customer:'James K.', rest:'Pizza Heaven', items:1, amount:'$16.98', payment:'Card', time:'5 min ago', status:'Out for Delivery' },
                  { id:'QB123458', customer:'Emily R.', rest:'Sushi World', items:2, amount:'$44.97', payment:'COD', time:'12 min ago', status:'Delivered' },
                  { id:'QB123459', customer:'Mike T.', rest:'Taco Fiesta', items:4, amount:'$21.96', payment:'UPI', time:'18 min ago', status:'Confirmed' },
                  { id:'QB123460', customer:'Lisa P.', rest:'Curry House', items:3, amount:'$31.45', payment:'Card', time:'25 min ago', status:'Delivered' },
                  { id:'QB123461', customer:'Tom B.', rest:'Green Bowl', items:2, amount:'$27.98', payment:'UPI', time:'35 min ago', status:'Cancelled' },
                  { id:'QB123462', customer:'Anna L.', rest:'Burger Palace', items:2, amount:'$14.98', payment:'COD', time:'1 hr ago', status:'Delivered' },
                ].map(o => {
                  const colors: Record<string,string> = { Preparing:'#D69E2E', 'Out for Delivery':'#3182CE', Delivered:'#38A169', Confirmed:'#805AD5', Cancelled:'#E53E3E' }
                  const color = colors[o.status] || '#718096'
                  return `
                    <tr>
                      <td style="font-family:monospace;font-size:0.78rem;font-weight:700;color:var(--primary);">${o.id}</td>
                      <td>${o.customer}</td>
                      <td>${o.rest}</td>
                      <td>${o.items} items</td>
                      <td style="font-weight:700;">${o.amount}</td>
                      <td><span class="tag" style="font-size:0.7rem;">${o.payment}</span></td>
                      <td style="color:var(--text-muted);font-size:0.78rem;">${o.time}</td>
                      <td>
                        <select style="background:${color}15;color:${color};border:1px solid ${color}30;border-radius:var(--radius-full);padding:4px 10px;font-size:0.72rem;font-weight:700;cursor:pointer;" onchange="updateOrderStatus('${o.id}',this.value,this)">
                          <option ${o.status==='Confirmed'?'selected':''} value="Confirmed">Confirmed</option>
                          <option ${o.status==='Preparing'?'selected':''} value="Preparing">Preparing</option>
                          <option ${o.status==='Out for Delivery'?'selected':''} value="Out for Delivery">Out for Delivery</option>
                          <option ${o.status==='Delivered'?'selected':''} value="Delivered">Delivered</option>
                          <option ${o.status==='Cancelled'?'selected':''} value="Cancelled">Cancelled</option>
                        </select>
                      </td>
                      <td>
                        <div style="display:flex;gap:4px;">
                          <button class="btn btn-ghost btn-sm" style="padding:4px 8px;" onclick="viewOrder('${o.id}')"><i class="fas fa-eye"></i></button>
                          <button class="btn btn-ghost btn-sm" style="padding:4px 8px;color:var(--primary);" onclick="QB.showToast('Printing receipt...','info')"><i class="fas fa-print"></i></button>
                        </div>
                      </td>
                    </tr>
                  `
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- ── RESTAURANTS ────────────────────────────────── -->
      <div id="admin-section-restaurants" style="display:none;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
          <h2 style="font-size:1.4rem;">Restaurants</h2>
          <button class="btn btn-primary" onclick="openModal('add-restaurant-modal')"><i class="fas fa-plus"></i> Add Restaurant</button>
        </div>
        <div class="card">
          <div style="overflow-x:auto;">
            <table class="admin-table">
              <thead><tr><th>Restaurant</th><th>Cuisine</th><th>Rating</th><th>Orders</th><th>Revenue</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                ${[
                  { name:'Burger Palace', emoji:'🍔', cuisine:'American', rating:4.5, orders:234, revenue:'$4,521', active:true },
                  { name:'Pizza Heaven', emoji:'🍕', cuisine:'Italian', rating:4.7, orders:189, revenue:'$3,892', active:true },
                  { name:'Sushi World', emoji:'🍱', cuisine:'Japanese', rating:4.8, orders:143, revenue:'$6,178', active:true },
                  { name:'Taco Fiesta', emoji:'🌮', cuisine:'Mexican', rating:4.3, orders:121, revenue:'$2,341', active:false },
                  { name:'Green Bowl', emoji:'🥗', cuisine:'Healthy', rating:4.6, orders:98, revenue:'$2,102', active:true },
                  { name:'Curry House', emoji:'🍛', cuisine:'Indian', rating:4.7, orders:167, revenue:'$5,234', active:true },
                ].map(r => `
                  <tr>
                    <td>
                      <div style="display:flex;align-items:center;gap:10px;">
                        <span style="font-size:24px;">${r.emoji}</span>
                        <span style="font-weight:600;">${r.name}</span>
                      </div>
                    </td>
                    <td>${r.cuisine}</td>
                    <td><span style="color:#D69E2E;font-weight:700;">⭐ ${r.rating}</span></td>
                    <td>${r.orders}</td>
                    <td style="font-weight:700;color:var(--success);">${r.revenue}</td>
                    <td>
                      <span style="background:${r.active ? 'rgba(56,161,105,0.1)' : 'rgba(229,62,62,0.1)'};color:${r.active ? '#38A169' : '#E53E3E'};padding:4px 10px;border-radius:var(--radius-full);font-size:0.72rem;font-weight:600;">
                        ${r.active ? '● Active' : '● Inactive'}
                      </span>
                    </td>
                    <td>
                      <div style="display:flex;gap:4px;">
                        <button class="btn btn-ghost btn-sm" style="padding:4px 8px;" onclick="QB.showToast('Editing ${r.name}...','info')"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-ghost btn-sm" style="padding:4px 8px;color:var(--primary);" onclick="QB.showToast('${r.name} toggled','success')"><i class="fas fa-power-off"></i></button>
                        <button class="btn btn-ghost btn-sm" style="padding:4px 8px;color:var(--primary);" onclick="QB.showToast('Restaurant deleted','info')"><i class="fas fa-trash"></i></button>
                      </div>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- ── MENU ──────────────────────────────────────── -->
      <div id="admin-section-menu" style="display:none;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
          <h2 style="font-size:1.4rem;">Menu Items</h2>
          <div style="display:flex;gap:8px;">
            <select class="form-input" style="padding:8px;font-size:0.82rem;width:auto;">
              <option>All Restaurants</option>
              <option>Burger Palace</option>
              <option>Pizza Heaven</option>
              <option>Curry House</option>
            </select>
            <button class="btn btn-primary" onclick="openModal('add-menu-modal')"><i class="fas fa-plus"></i> Add Item</button>
          </div>
        </div>
        <div class="grid-3">
          ${[
            { name:'Classic Cheeseburger', rest:'Burger Palace', price:8.99, emoji:'🍔', status:true, orders:156 },
            { name:'Pepperoni Pizza', rest:'Pizza Heaven', price:14.99, emoji:'🍕', status:true, orders:203 },
            { name:'Butter Chicken', rest:'Curry House', price:14.99, emoji:'🍛', status:true, orders:189 },
            { name:'California Roll', rest:'Sushi World', price:12.99, emoji:'🍱', status:true, orders:87 },
            { name:'Buddha Bowl', rest:'Green Bowl', price:14.99, emoji:'🥗', status:false, orders:43 },
            { name:'Veggie Delight', rest:'Burger Palace', price:9.99, emoji:'🥬', status:true, orders:67 },
          ].map(item => `
            <div class="card" style="overflow:hidden;">
              <div style="height:100px;background:linear-gradient(135deg,#1a202c,#2d3748);display:flex;align-items:center;justify-content:center;font-size:48px;position:relative;">
                ${item.emoji}
                ${!item.status ? '<div style="position:absolute;inset:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;color:white;font-size:0.75rem;font-weight:700;">UNAVAILABLE</div>' : ''}
              </div>
              <div class="card-body">
                <h4 style="font-size:0.9rem;margin-bottom:2px;">${item.name}</h4>
                <p style="font-size:0.75rem;color:var(--text-muted);margin-bottom:8px;">${item.rest}</p>
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                  <span style="font-weight:700;color:var(--primary);">$${item.price.toFixed(2)}</span>
                  <span style="font-size:0.72rem;color:var(--text-muted);">${item.orders} orders</span>
                </div>
                <div style="display:flex;gap:6px;">
                  <button class="btn btn-ghost btn-sm" style="flex:1;" onclick="QB.showToast('Editing item...','info')"><i class="fas fa-edit"></i></button>
                  <button class="btn btn-ghost btn-sm" style="flex:1;color:${item.status ? '#D69E2E' : '#38A169'};" onclick="QB.showToast('Status toggled!','success')"><i class="fas fa-${item.status ? 'toggle-on' : 'toggle-off'}"></i></button>
                  <button class="btn btn-ghost btn-sm" style="flex:1;color:var(--primary);" onclick="QB.showToast('Item deleted','info')"><i class="fas fa-trash"></i></button>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- ── USERS ────────────────────────────────────── -->
      <div id="admin-section-users" style="display:none;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
          <h2 style="font-size:1.4rem;">Users</h2>
          <input type="text" class="form-input" placeholder="Search users..." style="width:220px;padding:8px 14px;font-size:0.82rem;">
        </div>
        <div class="card">
          <div style="overflow-x:auto;">
            <table class="admin-table">
              <thead><tr><th>User</th><th>Email</th><th>Phone</th><th>Orders</th><th>Spent</th><th>Joined</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                ${[
                  { name:'Sarah Mitchell', email:'sarah@example.com', phone:'+1 555-0101', orders:23, spent:'$284', joined:'Jan 2024', active:true },
                  { name:'James Kumar', email:'james@example.com', phone:'+1 555-0102', orders:15, spent:'$189', joined:'Feb 2024', active:true },
                  { name:'Emily Rose', email:'emily@example.com', phone:'+1 555-0103', orders:42, spent:'$612', joined:'Dec 2023', active:true },
                  { name:'Mike Thompson', email:'mike@example.com', phone:'+1 555-0104', orders:8, spent:'$96', joined:'Mar 2024', active:false },
                  { name:'Lisa Parker', email:'lisa@example.com', phone:'+1 555-0105', orders:31, spent:'$423', joined:'Nov 2023', active:true },
                ].map(u => `
                  <tr>
                    <td>
                      <div style="display:flex;align-items:center;gap:10px;">
                        <div style="width:32px;height:32px;border-radius:50%;background:var(--primary-gradient);display:flex;align-items:center;justify-content:center;color:white;font-weight:700;font-size:0.875rem;flex-shrink:0;">${u.name.charAt(0)}</div>
                        <span style="font-weight:600;">${u.name}</span>
                      </div>
                    </td>
                    <td style="color:var(--text-muted);">${u.email}</td>
                    <td style="color:var(--text-muted);">${u.phone}</td>
                    <td>${u.orders}</td>
                    <td style="font-weight:700;color:var(--success);">${u.spent}</td>
                    <td style="color:var(--text-muted);font-size:0.78rem;">${u.joined}</td>
                    <td>
                      <span style="background:${u.active ? 'rgba(56,161,105,0.1)' : 'rgba(229,62,62,0.1)'};color:${u.active ? '#38A169' : '#E53E3E'};padding:3px 8px;border-radius:var(--radius-full);font-size:0.7rem;font-weight:600;">
                        ${u.active ? 'Active' : 'Blocked'}
                      </span>
                    </td>
                    <td>
                      <div style="display:flex;gap:4px;">
                        <button class="btn btn-ghost btn-sm" style="padding:4px 8px;" onclick="QB.showToast('Viewing user...','info')"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-ghost btn-sm" style="padding:4px 8px;color:var(--primary);" onclick="QB.showToast('User status toggled','success')"><i class="fas fa-ban"></i></button>
                      </div>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- ── PROMO CODES ─────────────────────────────── -->
      <div id="admin-section-promo" style="display:none;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
          <h2 style="font-size:1.4rem;">Promo Codes</h2>
          <button class="btn btn-primary" onclick="openModal('add-promo-modal')"><i class="fas fa-plus"></i> New Promo</button>
        </div>
        <div class="card">
          <div style="overflow-x:auto;">
            <table class="admin-table">
              <thead><tr><th>Code</th><th>Discount</th><th>Type</th><th>Usage</th><th>Expiry</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                ${[
                  { code:'QUICKBITE10', discount:'10%', type:'All orders', usage:'245/1000', expiry:'31 Dec 2025', active:true },
                  { code:'FIRST50', discount:'50%', type:'First order only', usage:'89/500', expiry:'31 Dec 2025', active:true },
                  { code:'SAVE20', discount:'20%', type:'Min $30 order', usage:'156/500', expiry:'30 Jun 2025', active:true },
                  { code:'WELCOME30', discount:'30%', type:'New users', usage:'423/500', expiry:'31 Mar 2025', active:false },
                ].map(p => `
                  <tr>
                    <td style="font-family:monospace;font-weight:700;color:var(--primary);letter-spacing:1px;">${p.code}</td>
                    <td style="font-weight:700;">${p.discount}</td>
                    <td style="font-size:0.78rem;color:var(--text-muted);">${p.type}</td>
                    <td>
                      <div style="display:flex;align-items:center;gap:8px;">
                        <span style="font-size:0.78rem;color:var(--text-muted);">${p.usage}</span>
                        <div style="width:60px;height:4px;background:var(--border);border-radius:2px;">
                          <div style="width:${(parseInt(p.usage)/parseInt(p.usage.split('/')[1])*100)}%;height:100%;background:var(--primary);border-radius:2px;"></div>
                        </div>
                      </div>
                    </td>
                    <td style="font-size:0.78rem;color:var(--text-muted);">${p.expiry}</td>
                    <td>
                      <span style="background:${p.active ? 'rgba(56,161,105,0.1)' : 'rgba(229,62,62,0.1)'};color:${p.active ? '#38A169' : '#E53E3E'};padding:3px 8px;border-radius:var(--radius-full);font-size:0.7rem;font-weight:600;">
                        ${p.active ? 'Active' : 'Expired'}
                      </span>
                    </td>
                    <td>
                      <div style="display:flex;gap:4px;">
                        <button class="btn btn-ghost btn-sm" style="padding:4px 8px;" onclick="QB.showToast('Editing promo...','info')"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-ghost btn-sm" style="padding:4px 8px;color:var(--primary);" onclick="QB.showToast('Promo deleted','info')"><i class="fas fa-trash"></i></button>
                      </div>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Other sections placeholder -->
      ${['reviews','settings'].map(s => `
        <div id="admin-section-${s}" style="display:none;">
          <h2 style="font-size:1.4rem;margin-bottom:16px;">${s.charAt(0).toUpperCase() + s.slice(1)}</h2>
          <div class="card"><div class="card-body" style="text-align:center;padding:60px;">
            <div style="font-size:48px;margin-bottom:12px;">🚧</div>
            <h3>Coming Soon</h3>
            <p style="color:var(--text-muted);">This section is under development</p>
          </div></div>
        </div>
      `).join('')}
    </div>
  </div>

  <!-- Add Restaurant Modal -->
  <div class="modal-overlay" id="add-restaurant-modal">
    <div class="modal" style="max-width:600px;">
      <div class="modal-header">
        <h3><i class="fas fa-store" style="color:var(--primary);margin-right:8px;"></i>Add Restaurant</h3>
        <button class="modal-close" onclick="closeModal('add-restaurant-modal')"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          <div class="form-group" style="margin-bottom:0;"><label class="form-label">Restaurant Name</label><input type="text" class="form-input" placeholder="e.g. Burger Palace"></div>
          <div class="form-group" style="margin-bottom:0;"><label class="form-label">Cuisine Type</label><input type="text" class="form-input" placeholder="e.g. American, Burgers"></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px;">
          <div class="form-group" style="margin-bottom:0;"><label class="form-label">Delivery Time</label><input type="text" class="form-input" placeholder="e.g. 20-30 min"></div>
          <div class="form-group" style="margin-bottom:0;"><label class="form-label">Delivery Fee</label><input type="number" class="form-input" placeholder="e.g. 2.99" step="0.01"></div>
        </div>
        <div class="form-group" style="margin-top:12px;"><label class="form-label">Address</label><input type="text" class="form-input" placeholder="Full address"></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          <div class="form-group" style="margin-bottom:0;"><label class="form-label">Phone</label><input type="tel" class="form-input" placeholder="+1 (555) 000-0000"></div>
          <div class="form-group" style="margin-bottom:0;"><label class="form-label">Emoji Icon</label><input type="text" class="form-input" placeholder="e.g. 🍔" maxlength="2"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('add-restaurant-modal')">Cancel</button>
        <button class="btn btn-primary" onclick="QB.showToast('Restaurant added!','success');closeModal('add-restaurant-modal')"><i class="fas fa-plus"></i> Add Restaurant</button>
      </div>
    </div>
  </div>

  <!-- Add Menu Item Modal -->
  <div class="modal-overlay" id="add-menu-modal">
    <div class="modal">
      <div class="modal-header">
        <h3>Add Menu Item</h3>
        <button class="modal-close" onclick="closeModal('add-menu-modal')"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Restaurant</label><select class="form-input"><option>Burger Palace</option><option>Pizza Heaven</option><option>Curry House</option></select></div>
        <div class="form-group"><label class="form-label">Item Name</label><input type="text" class="form-input" placeholder="e.g. Classic Cheeseburger"></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          <div class="form-group" style="margin-bottom:0;"><label class="form-label">Price ($)</label><input type="number" class="form-input" placeholder="9.99" step="0.01"></div>
          <div class="form-group" style="margin-bottom:0;"><label class="form-label">Calories</label><input type="number" class="form-input" placeholder="520"></div>
        </div>
        <div class="form-group" style="margin-top:12px;"><label class="form-label">Description</label><textarea class="form-input" rows="2" placeholder="Brief description..."></textarea></div>
        <div style="display:flex;gap:12px;align-items:center;">
          <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:0.875rem;"><input type="checkbox" style="accent-color:var(--primary);">Vegetarian</label>
          <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:0.875rem;"><input type="checkbox" style="accent-color:var(--primary);">Popular/Bestseller</label>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('add-menu-modal')">Cancel</button>
        <button class="btn btn-primary" onclick="QB.showToast('Menu item added!','success');closeModal('add-menu-modal')"><i class="fas fa-plus"></i> Add Item</button>
      </div>
    </div>
  </div>
  `

  const scripts = `
  <script>
    function switchAdminSection(id) {
      const sections = ['dashboard','orders','restaurants','menu','users','promo','reviews','settings'];
      sections.forEach(s => {
        const el = document.getElementById('admin-section-' + s);
        if (el) el.style.display = s === id ? 'block' : 'none';
        const nav = document.getElementById('admin-nav-' + s);
        if (nav) {
          nav.style.background = s === id ? 'rgba(229,62,62,0.08)' : '';
          nav.style.borderLeft = s === id ? '3px solid var(--primary)' : '3px solid transparent';
          nav.querySelector('i').style.color = s === id ? 'var(--primary)' : 'var(--text-muted)';
          nav.querySelector('span').style.color = s === id ? 'var(--primary)' : 'var(--text)';
        }
      });
    }

    function updateOrderStatus(id, status, select) {
      const colors = { Confirmed:'#805AD5', Preparing:'#D69E2E', 'Out for Delivery':'#3182CE', Delivered:'#38A169', Cancelled:'#E53E3E' };
      const color = colors[status] || '#718096';
      select.style.background = color + '15';
      select.style.color = color;
      select.style.borderColor = color + '30';
      QB.showToast('Order ' + id + ' status updated to ' + status, 'success');
    }

    function viewOrder(id) {
      QB.showToast('Viewing order ' + id, 'info');
    }

    function filterAdminOrders(q) {
      const rows = document.querySelectorAll('#orders-table tbody tr');
      rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = !q || text.includes(q.toLowerCase()) ? '' : 'none';
      });
    }

    function filterOrderStatus(status) {
      const rows = document.querySelectorAll('#orders-table tbody tr');
      rows.forEach(row => {
        const sel = row.querySelector('select');
        row.style.display = status === 'all' || (sel && sel.value === status) ? '' : 'none';
      });
    }

    function switchChart(type) {
      document.querySelectorAll('[id^="chart-"]').forEach(b => b.classList.remove('active'));
      document.getElementById('chart-' + type)?.classList.add('active');
    }

    // Check admin access
    document.addEventListener('DOMContentLoaded', () => {
      // In production, check auth here
    });
  </script>
  `

  return pageShell('Admin Panel', content, 'admin', scripts)
}
