/**
 * QuickBite - Order Tracking Page
 * Real-time order tracking with animated progress bar and map
 */
import { pageShell } from './layout'

export function renderTracking(orderId: string = ''): string {
  const content = `
  <div class="container" style="padding-top:24px;padding-bottom:40px;max-width:700px;">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px;">
      <button onclick="history.back()" style="width:36px;height:36px;border-radius:50%;border:1.5px solid var(--border);background:var(--surface);cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--text);">
        <i class="fas fa-arrow-left"></i>
      </button>
      <h2 style="font-size:1.4rem;">Order Tracking</h2>
    </div>

    <!-- Order ID Banner -->
    <div style="background:var(--primary-gradient);border-radius:var(--radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
      <div>
        <p style="color:rgba(255,255,255,0.8);font-size:0.78rem;margin-bottom:2px;">ORDER ID</p>
        <p style="color:white;font-weight:800;font-size:1.1rem;letter-spacing:1px;" id="order-id-show">${orderId || 'QB123456'}</p>
      </div>
      <div style="text-align:right;">
        <p style="color:rgba(255,255,255,0.8);font-size:0.78rem;margin-bottom:2px;">ESTIMATED ARRIVAL</p>
        <p style="color:white;font-weight:700;font-size:1rem;" id="eta-display">~28 min</p>
      </div>
    </div>

    <!-- Current Status -->
    <div class="card" style="margin-bottom:20px;overflow:visible;">
      <div class="card-body" style="padding:24px;">
        <div style="text-align:center;margin-bottom:24px;">
          <div id="status-icon" style="width:80px;height:80px;border-radius:50%;background:var(--primary-gradient);display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:36px;box-shadow:0 8px 24px rgba(229,62,62,0.3);animation:pulse 2s infinite;">
            🍳
          </div>
          <h3 id="status-title" style="font-size:1.2rem;margin-bottom:4px;">Preparing Your Order</h3>
          <p id="status-sub" style="color:var(--text-secondary);font-size:0.875rem;">The restaurant is preparing your delicious meal</p>
        </div>

        <!-- Overall Progress Bar -->
        <div style="margin-bottom:24px;">
          <div style="display:flex;justify-content:space-between;font-size:0.75rem;color:var(--text-muted);margin-bottom:6px;">
            <span>Order Progress</span>
            <span id="progress-pct">40%</span>
          </div>
          <div class="progress-bar" style="height:10px;">
            <div class="progress-fill" id="main-progress" style="width:40%;"></div>
          </div>
        </div>

        <!-- Step-by-Step Progress -->
        <div id="steps-timeline" style="position:relative;">
          <!-- Vertical line -->
          <div style="position:absolute;left:20px;top:24px;bottom:24px;width:2px;background:var(--border);z-index:0;"></div>
          <div style="position:absolute;left:20px;top:24px;width:2px;background:var(--primary-gradient);z-index:1;transition:height 1s ease;" id="timeline-line" style="height:0%;"></div>

          ${[
            { id:'confirmed', icon:'fa-check-circle', title:'Order Confirmed', sub:'We received your order', emoji:'✅' },
            { id:'preparing', icon:'fa-utensils', title:'Preparing', sub:'Restaurant is cooking your food', emoji:'🍳' },
            { id:'ready', icon:'fa-box', title:'Ready for Pickup', sub:'Your order is packed & ready', emoji:'📦' },
            { id:'delivery', icon:'fa-motorcycle', title:'Out for Delivery', sub:'Rider is on the way to you', emoji:'🛵' },
            { id:'delivered', icon:'fa-home', title:'Delivered', sub:'Enjoy your meal!', emoji:'🎉' },
          ].map((step, i) => `
            <div style="display:flex;align-items:flex-start;gap:16px;margin-bottom:20px;position:relative;z-index:2;" id="step-${step.id}">
              <div style="width:40px;height:40px;border-radius:50%;background:var(--surface-2);border:2px solid var(--border);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all 0.5s;" id="step-icon-${step.id}">
                <i class="fas ${step.icon}" style="font-size:16px;color:var(--text-muted);" id="step-i-${step.id}"></i>
              </div>
              <div style="padding-top:8px;flex:1;">
                <p style="font-weight:700;font-size:0.9rem;color:var(--text-muted);transition:color 0.3s;" id="step-title-${step.id}">${step.title}</p>
                <p style="font-size:0.78rem;color:var(--text-muted);margin-top:2px;transition:color 0.3s;" id="step-sub-${step.id}">${step.sub}</p>
                <p id="step-time-${step.id}" style="font-size:0.72rem;color:var(--primary);font-weight:600;margin-top:2px;display:none;"></p>
              </div>
              <div id="step-badge-${step.id}" style="display:none;flex-shrink:0;margin-top:6px;">
                <span style="font-size:18px;">${step.emoji}</span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    </div>

    <!-- Delivery Info -->
    <div class="card" style="margin-bottom:16px;">
      <div class="card-body">
        <h4 style="margin-bottom:16px;display:flex;align-items:center;gap:8px;"><i class="fas fa-motorcycle" style="color:var(--primary);"></i>Delivery Agent</h4>
        <div style="display:flex;align-items:center;gap:14px;">
          <div style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;color:white;font-size:22px;flex-shrink:0;">🧑</div>
          <div style="flex:1;">
            <p style="font-weight:700;font-size:0.95rem;color:var(--text);">Rajan Kumar</p>
            <div style="display:flex;align-items:center;gap:4px;margin-top:2px;">
              ${[1,2,3,4,5].map(s => `<i class="fas fa-star" style="color:#ECC94B;font-size:11px;"></i>`).join('')}
              <span style="font-size:0.75rem;color:var(--text-muted);margin-left:4px;">4.9 (2.3k trips)</span>
            </div>
            <p style="font-size:0.78rem;color:var(--text-muted);margin-top:2px;"><i class="fas fa-motorcycle" style="color:var(--primary);"></i> Honda Activa · MH 01 AB 1234</p>
          </div>
          <div style="display:flex;flex-direction:column;gap:8px;">
            <a href="tel:+919876543210" class="btn btn-primary btn-sm" style="display:flex;align-items:center;gap:6px;" onclick="event.preventDefault();QB.showToast('Calling rider...','info')">
              <i class="fas fa-phone"></i> Call
            </a>
            <button class="btn btn-outline btn-sm" onclick="openModal('chat-modal')">
              <i class="fas fa-comment"></i> Chat
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Map Placeholder -->
    <div class="card" style="margin-bottom:16px;">
      <div style="height:200px;background:linear-gradient(135deg,#2d3748,#1a202c);border-radius:var(--radius-lg);display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;">
        <!-- Simulated map -->
        <div style="position:absolute;inset:0;opacity:0.3;">
          <div style="position:absolute;top:30%;left:20%;width:60%;height:1px;background:#4A5568;transform:rotate(-8deg);"></div>
          <div style="position:absolute;top:50%;left:10%;width:80%;height:1px;background:#4A5568;transform:rotate(2deg);"></div>
          <div style="position:absolute;top:70%;left:5%;width:90%;height:1px;background:#4A5568;transform:rotate(-3deg);"></div>
          <div style="position:absolute;left:35%;top:10%;width:1px;height:80%;background:#4A5568;transform:rotate(5deg);"></div>
          <div style="position:absolute;left:60%;top:5%;width:1px;height:90%;background:#4A5568;transform:rotate(-2deg);"></div>
        </div>
        <!-- Rider pin -->
        <div id="rider-pin" style="position:absolute;font-size:28px;transition:all 2s ease;animation:riderMove 8s infinite alternate;" >🛵</div>
        <!-- Destination pin -->
        <div style="position:absolute;bottom:30px;right:60px;font-size:28px;">🏠</div>
        <!-- Restaurant pin -->
        <div style="position:absolute;top:30px;left:40px;font-size:28px;">🍔</div>
        <div style="color:rgba(255,255,255,0.5);font-size:0.8rem;font-weight:600;text-align:center;">
          <i class="fas fa-map" style="font-size:20px;display:block;margin-bottom:4px;opacity:0.5;"></i>
          Live Tracking Map
        </div>
      </div>
    </div>

    <!-- Order Items Summary -->
    <div class="card" style="margin-bottom:16px;">
      <div class="card-body">
        <h4 style="margin-bottom:12px;font-size:0.9rem;display:flex;align-items:center;gap:8px;"><i class="fas fa-receipt" style="color:var(--primary);"></i>Your Order</h4>
        <div id="tracking-items">
          <!-- Populated by JS -->
        </div>
        <div style="border-top:1px solid var(--border);margin-top:12px;padding-top:12px;display:flex;justify-content:space-between;font-weight:700;">
          <span>Total Paid</span>
          <span id="tracking-total" style="color:var(--primary);">$0.00</span>
        </div>
      </div>
    </div>

    <!-- Help Section -->
    <div class="card">
      <div class="card-body" style="display:flex;justify-content:space-around;flex-wrap:wrap;gap:12px;">
        ${[
          { icon:'fa-phone', label:'Call Support', onclick:"QB.showToast('Connecting to support...','info')" },
          { icon:'fa-undo', label:'Cancel Order', onclick:"cancelOrder()" },
          { icon:'fa-share-alt', label:'Share ETA', onclick:"QB.showToast('ETA link copied!','success')" },
        ].map(a => `
          <button class="btn btn-ghost btn-sm" onclick="${a.onclick}" style="flex-direction:column;gap:4px;padding:12px 16px;">
            <i class="fas ${a.icon}" style="font-size:18px;color:var(--primary);"></i>
            <span style="font-size:0.75rem;">${a.label}</span>
          </button>
        `).join('')}
      </div>
    </div>
  </div>

  <!-- Chat Support Modal -->
  <div class="modal-overlay" id="chat-modal">
    <div class="modal" style="max-width:420px;">
      <div class="modal-header">
        <h3 style="display:flex;align-items:center;gap:8px;"><span style="font-size:20px;">🧑</span> Chat with Rajan</h3>
        <div style="display:flex;align-items:center;gap:8px;">
          <span style="display:flex;align-items:center;gap:4px;font-size:0.75rem;color:var(--success);"><i class="fas fa-circle" style="font-size:8px;"></i> Online</span>
          <button class="modal-close" onclick="closeModal('chat-modal')"><i class="fas fa-times"></i></button>
        </div>
      </div>
      <div style="height:280px;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:12px;background:var(--surface-2);" id="chat-messages">
        <div style="display:flex;justify-content:flex-start;">
          <div style="background:var(--surface);border-radius:0 var(--radius-lg) var(--radius-lg) var(--radius-lg);padding:10px 14px;max-width:75%;font-size:0.875rem;box-shadow:var(--shadow-sm);">
            Hi! I'm on my way with your order. Will be there in ~15 minutes! 😊
          </div>
        </div>
        <div style="display:flex;justify-content:flex-end;">
          <div style="background:var(--primary-gradient);border-radius:var(--radius-lg) 0 var(--radius-lg) var(--radius-lg);padding:10px 14px;max-width:75%;font-size:0.875rem;color:white;">
            Great, thanks! Please call when you arrive.
          </div>
        </div>
      </div>
      <div style="padding:12px 16px;border-top:1px solid var(--border);display:flex;gap:8px;">
        <input type="text" class="form-input" placeholder="Type a message..." id="chat-input" onkeydown="if(event.key==='Enter')sendMessage()" style="flex:1;border-radius:var(--radius-full);padding:8px 16px;">
        <button class="btn btn-primary" onclick="sendMessage()" style="border-radius:50%;width:40px;height:40px;padding:0;flex-shrink:0;">
          <i class="fas fa-paper-plane"></i>
        </button>
      </div>
      <!-- Quick Replies -->
      <div style="padding:8px 16px 12px;display:flex;gap:6px;flex-wrap:wrap;border-top:1px solid var(--border);">
        ${["I'll be at the gate 🚪","Please call on arrival 📞","Where are you? 📍"].map(msg => `
          <button class="chip" style="font-size:0.72rem;" onclick="quickReply('${msg}')">${msg}</button>
        `).join('')}
      </div>
    </div>
  </div>
  `

  const scripts = `
  <style>
    @keyframes pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.05)} }
    @keyframes riderMove {
      0% { left:20%; top:40%; }
      25% { left:35%; top:50%; }
      50% { left:50%; top:45%; }
      75% { left:60%; top:55%; }
      100% { left:70%; top:50%; }
    }
  </style>
  <script>
    const STEPS = ['confirmed','preparing','ready','delivery','delivered'];
    const STEP_DATA = {
      confirmed: { icon:'fa-check-circle', title:'Order Confirmed', sub:'We received your order', status:'Order placed at ', color:'var(--success)', progress:20, mainEmoji:'✅', mainTitle:'Order Confirmed!', mainSub:'Your order has been confirmed by the restaurant' },
      preparing: { icon:'fa-fire', title:'Preparing', sub:'Restaurant is cooking your food', status:'Preparing since ', color:'#ED8936', progress:40, mainEmoji:'🍳', mainTitle:'Preparing Your Order', mainSub:'The restaurant is preparing your delicious meal' },
      ready: { icon:'fa-box', title:'Ready for Pickup', sub:'Your order is packed & ready', status:'Ready at ', color:'#3182CE', progress:60, mainEmoji:'📦', mainTitle:'Order is Ready!', mainSub:'Your order is packed. Rider is picking it up' },
      delivery: { icon:'fa-motorcycle', title:'Out for Delivery', sub:'Rider is heading to you', status:'Picked up at ', color:'var(--primary)', progress:80, mainEmoji:'🛵', mainTitle:'Out for Delivery!', mainSub:'Rajan is on the way with your order' },
      delivered: { icon:'fa-check-circle', title:'Delivered', sub:'Enjoy your meal!', status:'Delivered at ', color:'var(--success)', progress:100, mainEmoji:'🎉', mainTitle:'Order Delivered!', mainSub:'Your order has been delivered. Enjoy your meal!' },
    };

    let currentStepIdx = 1; // Start at 'preparing'
    const orderId = '${orderId}' || localStorage.getItem('qb_last_order') || 'QB' + Date.now().toString().slice(-6);
    document.getElementById('order-id-show').textContent = orderId;

    function activateStep(idx) {
      const stepId = STEPS[idx];
      const data = STEP_DATA[stepId];

      // Update main status
      document.getElementById('status-icon').textContent = data.mainEmoji;
      document.getElementById('status-title').textContent = data.mainTitle;
      document.getElementById('status-sub').textContent = data.mainSub;
      document.getElementById('main-progress').style.width = data.progress + '%';
      document.getElementById('progress-pct').textContent = data.progress + '%';

      // Remaining ETA
      const remaining = Math.max(0, 28 - (idx * 7));
      document.getElementById('eta-display').textContent = remaining > 0 ? '~' + remaining + ' min' : 'Arrived!';

      // Update all steps
      STEPS.forEach((sid, i) => {
        const stepEl = document.getElementById('step-icon-' + sid);
        const stepTitle = document.getElementById('step-title-' + sid);
        const stepSub = document.getElementById('step-sub-' + sid);
        const stepBadge = document.getElementById('step-badge-' + sid);
        const stepTime = document.getElementById('step-time-' + sid);
        const d = STEP_DATA[sid];

        if (i < idx) {
          // Completed
          stepEl.style.background = d.color;
          stepEl.style.borderColor = d.color;
          stepEl.querySelector('i').style.color = 'white';
          stepEl.querySelector('i').className = 'fas fa-check';
          stepTitle.style.color = 'var(--text)';
          stepBadge.style.display = 'block';
          if (stepTime) { stepTime.style.display = 'block'; stepTime.textContent = new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}); }
        } else if (i === idx) {
          // Active
          stepEl.style.background = 'var(--primary-gradient)';
          stepEl.style.borderColor = 'var(--primary)';
          stepEl.querySelector('i').style.color = 'white';
          stepEl.querySelector('i').className = 'fas ' + d.icon;
          stepTitle.style.color = 'var(--text)';
          stepSub.style.color = 'var(--text-secondary)';
          stepBadge.style.display = 'block';
          stepEl.style.animation = 'pulse 2s infinite';
        } else {
          // Pending
          stepEl.style.background = 'var(--surface-2)';
          stepEl.style.borderColor = 'var(--border)';
          stepEl.querySelector('i').style.color = 'var(--text-muted)';
          stepEl.querySelector('i').className = 'fas ' + d.icon;
          stepTitle.style.color = 'var(--text-muted)';
          stepSub.style.color = 'var(--text-muted)';
          stepBadge.style.display = 'none';
        }
      });

      // Timeline line
      const pct = (idx / (STEPS.length - 1)) * 100;
      document.getElementById('timeline-line').style.height = pct + '%';
    }

    // Auto-advance simulation
    function startTracking() {
      activateStep(currentStepIdx);

      const intervals = [8000, 12000, 15000, 25000]; // ms delays between steps
      let delay = 0;
      for (let i = currentStepIdx + 1; i < STEPS.length; i++) {
        delay += intervals[i - currentStepIdx - 1] || 10000;
        ((step) => {
          setTimeout(() => {
            currentStepIdx = step;
            activateStep(step);
            const msgs = ['Order confirmed! 🎉', 'Preparation started! 🍳', 'Order ready for pickup! 📦', 'Rider picked up your order! 🛵', 'Order delivered! 🎉 Enjoy!'];
            QB.showToast(msgs[step], 'success');
            if (step === STEPS.length - 1) {
              setTimeout(() => { window.location.href = '/orders'; }, 4000);
            }
          }, delay);
        })(i);
      }
    }

    // Render tracking items
    function renderTrackingItems() {
      const cart = QB.cart;
      const el = document.getElementById('tracking-items');
      if (!el) return;

      // Use last known cart or demo items
      const items = cart.length > 0 ? cart : [
        { name:'Classic Cheeseburger', price:8.99, qty:2, image:'🍔' },
        { name:'Crispy Fries', price:3.99, qty:1, image:'🍟' },
        { name:'Vanilla Milkshake', price:5.49, qty:1, image:'🥛' },
      ];

      el.innerHTML = items.map(item => \`
        <div style="display:flex;align-items:center;gap:10px;padding:6px 0;">
          <span style="font-size:20px;">\${item.image}</span>
          <span style="flex:1;font-size:0.82rem;color:var(--text);">\${item.name}</span>
          <span style="font-size:0.75rem;color:var(--text-muted);">x\${item.qty}</span>
          <span style="font-size:0.82rem;font-weight:700;color:var(--text);">$\${(item.price * item.qty).toFixed(2)}</span>
        </div>
      \`).join('');

      const total = items.reduce((s,i) => s + i.price * i.qty, 0) + 2.99;
      document.getElementById('tracking-total').textContent = '$' + total.toFixed(2);
    }

    function cancelOrder() {
      if (currentStepIdx >= 3) {
        QB.showToast('Cannot cancel - rider is already on the way!', 'error');
        return;
      }
      if (confirm('Are you sure you want to cancel this order?')) {
        QB.showToast('Order cancellation requested', 'info');
        setTimeout(() => { window.location.href = '/orders'; }, 1500);
      }
    }

    // Chat
    function sendMessage() {
      const input = document.getElementById('chat-input');
      const msg = input.value.trim();
      if (!msg) return;
      const chatEl = document.getElementById('chat-messages');
      chatEl.innerHTML += \`
        <div style="display:flex;justify-content:flex-end;">
          <div style="background:var(--primary-gradient);border-radius:var(--radius-lg) 0 var(--radius-lg) var(--radius-lg);padding:10px 14px;max-width:75%;font-size:0.875rem;color:white;">\${msg}</div>
        </div>
      \`;
      input.value = '';
      chatEl.scrollTop = chatEl.scrollHeight;

      // Auto-reply
      const replies = ['Got it! 👍', 'On my way! 🛵', 'Will be there soon! 😊', 'Understood! 🙏'];
      setTimeout(() => {
        chatEl.innerHTML += \`
          <div style="display:flex;justify-content:flex-start;">
            <div style="background:var(--surface);border-radius:0 var(--radius-lg) var(--radius-lg) var(--radius-lg);padding:10px 14px;max-width:75%;font-size:0.875rem;box-shadow:var(--shadow-sm);">\${replies[Math.floor(Math.random()*replies.length)]}</div>
          </div>
        \`;
        chatEl.scrollTop = chatEl.scrollHeight;
      }, 1500);
    }

    function quickReply(msg) {
      document.getElementById('chat-input').value = msg;
      sendMessage();
    }

    document.addEventListener('DOMContentLoaded', () => {
      renderTrackingItems();
      startTracking();
    });
  </script>
  `

  return pageShell('Track Order', content, 'tracking', scripts)
}
