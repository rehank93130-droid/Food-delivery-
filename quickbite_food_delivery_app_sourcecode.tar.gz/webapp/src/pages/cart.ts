/**
 * QuickBite - Cart Page
 * Full cart management with promo codes, delivery options, order summary
 */
import { pageShell } from './layout'

export function renderCart(): string {
  const content = `
  <div class="container" style="padding-top:24px;padding-bottom:40px;">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px;">
      <button onclick="history.back()" style="width:36px;height:36px;border-radius:50%;border:1.5px solid var(--border);background:var(--surface);cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--text);transition:var(--transition);" onmouseenter="this.style.background='var(--surface-2)'" onmouseleave="this.style.background='var(--surface)'">
        <i class="fas fa-arrow-left"></i>
      </button>
      <h2 style="font-size:1.4rem;">Your Cart</h2>
      <span id="cart-count-badge" style="background:var(--primary);color:white;padding:2px 10px;border-radius:var(--radius-full);font-size:0.8rem;font-weight:700;"></span>
    </div>

    <!-- Empty Cart -->
    <div id="empty-cart" style="text-align:center;padding:80px 20px;display:none;">
      <div style="font-size:80px;margin-bottom:20px;">🛒</div>
      <h3 style="margin-bottom:8px;">Your cart is empty</h3>
      <p style="color:var(--text-muted);margin-bottom:24px;">Add some delicious items to get started!</p>
      <button class="btn btn-primary btn-lg" onclick="window.location.href='/'">
        <i class="fas fa-utensils"></i> Browse Restaurants
      </button>
    </div>

    <!-- Cart Content -->
    <div id="cart-content" style="display:grid;grid-template-columns:1fr 380px;gap:24px;">

      <!-- Left: Cart Items + Delivery -->
      <div>
        <!-- Delivery Address -->
        <div class="card" style="margin-bottom:16px;">
          <div class="card-body">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
              <h4 style="display:flex;align-items:center;gap:8px;"><i class="fas fa-map-marker-alt" style="color:var(--primary);"></i>Delivery Address</h4>
              <button class="btn btn-ghost btn-sm" onclick="openModal('address-modal')"><i class="fas fa-edit"></i> Change</button>
            </div>
            <div id="selected-address" style="background:var(--surface-2);border-radius:var(--radius);padding:12px;border:1.5px solid var(--primary);">
              <div style="display:flex;align-items:flex-start;gap:10px;">
                <i class="fas fa-home" style="color:var(--primary);margin-top:2px;"></i>
                <div>
                  <p style="font-weight:600;font-size:0.875rem;color:var(--text);">Home</p>
                  <p style="font-size:0.82rem;color:var(--text-muted);">123 Main St, Apt 4B, New York, NY 10001</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Cart Items -->
        <div class="card" style="margin-bottom:16px;">
          <div class="card-body">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
              <h4 style="display:flex;align-items:center;gap:8px;"><i class="fas fa-utensils" style="color:var(--primary);"></i>Order Items</h4>
              <button class="btn btn-ghost btn-sm" style="color:var(--primary);" onclick="clearCartConfirm()">
                <i class="fas fa-trash-alt"></i> Clear All
              </button>
            </div>
            <div id="cart-items-list">
              <!-- Populated by JS -->
            </div>
          </div>
        </div>

        <!-- Add More Items -->
        <div style="text-align:center;margin-bottom:16px;">
          <button class="btn btn-outline" onclick="window.location.href='/'">
            <i class="fas fa-plus"></i> Add More Items
          </button>
        </div>

        <!-- Delivery Options -->
        <div class="card" style="margin-bottom:16px;">
          <div class="card-body">
            <h4 style="margin-bottom:16px;display:flex;align-items:center;gap:8px;"><i class="fas fa-shipping-fast" style="color:var(--primary);"></i>Delivery Options</h4>
            <div style="display:flex;flex-direction:column;gap:10px;">
              ${[
                { id:'standard', label:'Standard Delivery', time:'25-35 min', fee:'$2.99', icon:'fa-motorcycle' },
                { id:'express', label:'Express Delivery', time:'15-20 min', fee:'$5.99', icon:'fa-bolt' },
                { id:'scheduled', label:'Scheduled Delivery', time:'Choose time', fee:'$2.49', icon:'fa-calendar-alt' },
              ].map((opt, i) => `
                <label style="display:flex;align-items:center;gap:12px;padding:14px;border-radius:var(--radius);border:1.5px solid var(--border);cursor:pointer;transition:var(--transition);background:var(--surface);" id="delivery-opt-${opt.id}" onclick="selectDelivery('${opt.id}')" onmouseenter="if(document.getElementById('del-${opt.id}').checked==false)this.style.borderColor='var(--primary)'" onmouseleave="if(document.getElementById('del-${opt.id}').checked==false)this.style.borderColor='var(--border)'">
                  <input type="radio" name="delivery" id="del-${opt.id}" value="${opt.id}" ${i === 0 ? 'checked' : ''} style="accent-color:var(--primary);">
                  <div style="width:36px;height:36px;border-radius:var(--radius-sm);background:rgba(229,62,62,0.1);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                    <i class="fas ${opt.icon}" style="color:var(--primary);font-size:16px;"></i>
                  </div>
                  <div style="flex:1;">
                    <p style="font-weight:600;font-size:0.875rem;color:var(--text);">${opt.label}</p>
                    <p style="font-size:0.78rem;color:var(--text-muted);"><i class="fas fa-clock" style="color:var(--warning);"></i> ${opt.time}</p>
                  </div>
                  <span style="font-weight:700;color:var(--text);font-size:0.875rem;">${opt.fee}</span>
                </label>
              `).join('')}
            </div>
          </div>
        </div>

        <!-- Cooking Instructions -->
        <div class="card">
          <div class="card-body">
            <h4 style="margin-bottom:12px;display:flex;align-items:center;gap:8px;"><i class="fas fa-comment-alt" style="color:var(--primary);"></i>Cooking Instructions</h4>
            <textarea class="form-input" rows="3" placeholder="E.g., No onions, extra spicy, well-done, etc. (optional)" id="cooking-notes" style="resize:none;"></textarea>
          </div>
        </div>
      </div>

      <!-- Right: Order Summary -->
      <div>
        <div style="position:sticky;top:80px;">
          <div class="card">
            <div class="card-body">
              <h3 style="margin-bottom:20px;font-size:1.1rem;"><i class="fas fa-receipt" style="color:var(--primary);margin-right:8px;"></i>Order Summary</h3>

              <!-- Price Breakdown -->
              <div id="price-breakdown">
                <div style="display:flex;justify-content:space-between;font-size:0.875rem;color:var(--text-secondary);margin-bottom:10px;">
                  <span>Items (<span id="summary-count">0</span>)</span>
                  <span id="summary-subtotal">$0.00</span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:0.875rem;color:var(--text-secondary);margin-bottom:10px;">
                  <span>Delivery fee</span>
                  <span id="summary-delivery">$2.99</span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:0.875rem;color:var(--text-secondary);margin-bottom:10px;">
                  <span>Taxes (8%)</span>
                  <span id="summary-tax">$0.00</span>
                </div>
                <div id="discount-row" style="display:none;flex-direction:row;justify-content:space-between;font-size:0.875rem;color:var(--success);margin-bottom:10px;">
                  <span><i class="fas fa-tag"></i> Promo discount</span>
                  <span id="discount-amount">-$0.00</span>
                </div>
              </div>

              <div style="border-top:1px solid var(--border);padding-top:12px;margin-bottom:20px;">
                <div style="display:flex;justify-content:space-between;font-size:1.1rem;font-weight:700;color:var(--text);">
                  <span>Total</span>
                  <span id="summary-total" style="color:var(--primary);">$0.00</span>
                </div>
                <p style="font-size:0.75rem;color:var(--text-muted);margin-top:4px;">Inclusive of all taxes</p>
              </div>

              <!-- Promo Code -->
              <div style="margin-bottom:20px;">
                <label class="form-label">Promo Code</label>
                <div style="display:flex;gap:8px;">
                  <div class="input-group" style="flex:1;">
                    <i class="fas fa-tag input-icon"></i>
                    <input type="text" class="form-input" placeholder="QUICKBITE10" id="promo-input" style="text-transform:uppercase;letter-spacing:1px;">
                  </div>
                  <button class="btn btn-outline" onclick="applyPromo()" id="promo-btn">Apply</button>
                </div>
                <div id="promo-feedback" style="margin-top:6px;font-size:0.78rem;"></div>
                <!-- Quick Promo Suggestions -->
                <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">
                  ${['FIRST50','SAVE20','WELCOME30'].map(code => `
                    <button class="chip" style="font-size:0.72rem;padding:3px 10px;" onclick="quickApplyPromo('${code}')">${code}</button>
                  `).join('')}
                </div>
              </div>

              <!-- Savings Bar -->
              <div id="savings-info" style="display:none;background:rgba(56,161,105,0.1);border-radius:var(--radius);padding:10px;margin-bottom:16px;border:1px solid rgba(56,161,105,0.2);">
                <p style="font-size:0.8rem;color:var(--success);font-weight:600;text-align:center;">
                  <i class="fas fa-check-circle"></i> You're saving <strong id="savings-amount">$0.00</strong> on this order! 🎉
                </p>
              </div>

              <!-- Checkout Button -->
              <button class="btn btn-success btn-full btn-lg" onclick="proceedToCheckout()" id="checkout-btn">
                <i class="fas fa-lock"></i> Proceed to Checkout
              </button>

              <!-- Trust Badges -->
              <div style="display:flex;justify-content:center;gap:16px;margin-top:16px;flex-wrap:wrap;">
                <span style="font-size:0.72rem;color:var(--text-muted);display:flex;align-items:center;gap:4px;">
                  <i class="fas fa-shield-alt" style="color:var(--success);"></i> Secure Payment
                </span>
                <span style="font-size:0.72rem;color:var(--text-muted);display:flex;align-items:center;gap:4px;">
                  <i class="fas fa-undo" style="color:var(--info);"></i> Easy Refund
                </span>
                <span style="font-size:0.72rem;color:var(--text-muted);display:flex;align-items:center;gap:4px;">
                  <i class="fas fa-clock" style="color:var(--warning);"></i> 30-min Guarantee
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Address Modal -->
  <div class="modal-overlay" id="address-modal">
    <div class="modal">
      <div class="modal-header">
        <h3><i class="fas fa-map-marker-alt" style="color:var(--primary);margin-right:8px;"></i>Select Delivery Address</h3>
        <button class="modal-close" onclick="closeModal('address-modal')"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        ${[
          { type:'Home', icon:'fa-home', addr:'123 Main St, Apt 4B, New York, NY 10001' },
          { type:'Work', icon:'fa-building', addr:'456 Park Ave, Floor 12, New York, NY 10022' },
          { type:'Mom\'s Place', icon:'fa-heart', addr:'789 Oak Rd, Queens, NY 11375' },
        ].map(a => `
          <div style="padding:14px;border-radius:var(--radius);border:1.5px solid var(--border);cursor:pointer;margin-bottom:10px;transition:var(--transition);" onclick="selectAddress('${a.type}','${a.addr}')" onmouseenter="this.style.borderColor='var(--primary)';this.style.background='rgba(229,62,62,0.02)'" onmouseleave="this.style.borderColor='var(--border)';this.style.background=''">
            <div style="display:flex;align-items:center;gap:10px;">
              <div style="width:36px;height:36px;border-radius:var(--radius-sm);background:rgba(229,62,62,0.1);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <i class="fas ${a.icon}" style="color:var(--primary);"></i>
              </div>
              <div>
                <p style="font-weight:600;font-size:0.875rem;">${a.type}</p>
                <p style="font-size:0.78rem;color:var(--text-muted);">${a.addr}</p>
              </div>
            </div>
          </div>
        `).join('')}
        <button class="btn btn-outline btn-full" style="margin-top:4px;" onclick="closeModal('address-modal');QB.showToast('Add new address feature coming soon!','info')">
          <i class="fas fa-plus"></i> Add New Address
        </button>
      </div>
    </div>
  </div>

  <!-- Clear Cart Confirm Modal -->
  <div class="modal-overlay" id="clear-modal">
    <div class="modal">
      <div class="modal-header">
        <h3>Clear Cart?</h3>
        <button class="modal-close" onclick="closeModal('clear-modal')"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        <p>Are you sure you want to remove all items from your cart?</p>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('clear-modal')">Cancel</button>
        <button class="btn btn-primary" onclick="clearCartAction()" style="background:var(--primary);">
          <i class="fas fa-trash"></i> Clear Cart
        </button>
      </div>
    </div>
  </div>
  `

  const scripts = `
  <script>
    let deliveryFee = 2.99;
    let promoDiscount = 0;
    let promoCode = '';

    function renderCartItems() {
      const cart = QB.cart;
      const emptyCart = document.getElementById('empty-cart');
      const cartContent = document.getElementById('cart-content');
      const badge = document.getElementById('cart-count-badge');

      if (cart.length === 0) {
        emptyCart.style.display = 'block';
        cartContent.style.display = 'none';
        badge.textContent = '0 items';
        return;
      }

      emptyCart.style.display = 'none';
      cartContent.style.display = 'grid';
      badge.textContent = QB.cartCount + ' item' + (QB.cartCount !== 1 ? 's' : '');

      const list = document.getElementById('cart-items-list');
      list.innerHTML = cart.map(item => \`
        <div style="display:flex;align-items:center;gap:14px;padding:14px 0;border-bottom:1px solid var(--border);" id="cart-row-\${item.id}">
          <div style="width:64px;height:64px;background:linear-gradient(135deg,#1a202c,#2d3748);border-radius:var(--radius);display:flex;align-items:center;justify-content:center;font-size:32px;flex-shrink:0;">\${item.image}</div>
          <div style="flex:1;min-width:0;">
            <p style="font-weight:600;font-size:0.9rem;color:var(--text);">\${item.name}</p>
            <p style="font-size:0.8rem;color:var(--text-muted);margin-top:2px;">$\${item.price.toFixed(2)} each</p>
          </div>
          <div style="display:flex;align-items:center;gap:12px;">
            <div class="qty-control">
              <button class="qty-btn" onclick="updateCartQty('\${item.id}',-1)">−</button>
              <span class="qty-val">\${item.qty}</span>
              <button class="qty-btn" onclick="updateCartQty('\${item.id}',1)">+</button>
            </div>
            <span style="font-weight:700;font-size:0.9rem;color:var(--text);min-width:56px;text-align:right;">$\${(item.price * item.qty).toFixed(2)}</span>
            <button onclick="removeItem('\${item.id}')" style="width:28px;height:28px;border-radius:50%;background:rgba(229,62,62,0.1);border:none;color:var(--primary);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:13px;transition:var(--transition);" onmouseenter="this.style.background='var(--primary)';this.style.color='white'" onmouseleave="this.style.background='rgba(229,62,62,0.1)';this.style.color='var(--primary)'">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>
      \`).join('');

      updateSummary();
    }

    function updateCartQty(id, delta) {
      QB.updateQty(id, delta);
      renderCartItems();
    }

    function removeItem(id) {
      const row = document.getElementById('cart-row-' + id);
      if (row) { row.style.opacity = '0'; row.style.transform = 'translateX(-100%)'; row.style.transition = 'all 0.3s'; }
      setTimeout(() => { QB.removeFromCart(id); renderCartItems(); }, 300);
    }

    function updateSummary() {
      const subtotal = QB.cartTotal;
      const tax = subtotal * 0.08;
      const discount = subtotal * (promoDiscount / 100);
      const total = subtotal + deliveryFee + tax - discount;

      document.getElementById('summary-count').textContent = QB.cartCount;
      document.getElementById('summary-subtotal').textContent = '$' + subtotal.toFixed(2);
      document.getElementById('summary-delivery').textContent = '$' + deliveryFee.toFixed(2);
      document.getElementById('summary-tax').textContent = '$' + tax.toFixed(2);
      document.getElementById('summary-total').textContent = '$' + total.toFixed(2);

      if (promoDiscount > 0) {
        document.getElementById('discount-row').style.display = 'flex';
        document.getElementById('discount-amount').textContent = '-$' + discount.toFixed(2);
        document.getElementById('savings-info').style.display = 'block';
        document.getElementById('savings-amount').textContent = '$' + discount.toFixed(2);
      }
    }

    async function applyPromo() {
      const code = document.getElementById('promo-input').value.trim().toUpperCase();
      if (!code) { QB.showToast('Please enter a promo code', 'error'); return; }
      const btn = document.getElementById('promo-btn');
      btn.innerHTML = '<div class="spinner" style="width:16px;height:16px;border-width:2px;"></div>';
      btn.disabled = true;

      try {
        const res = await fetch('/api/promo', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({code})
        });
        const data = await res.json();
        const fb = document.getElementById('promo-feedback');
        if (data.success) {
          promoDiscount = data.discount;
          promoCode = code;
          fb.innerHTML = '<span style="color:var(--success);"><i class="fas fa-check-circle"></i> ' + data.message + '</span>';
          updateSummary();
          QB.showToast('🎉 Promo applied! ' + data.discount + '% off!', 'success');
        } else {
          fb.innerHTML = '<span style="color:var(--primary);"><i class="fas fa-times-circle"></i> ' + data.message + '</span>';
          QB.showToast('Invalid promo code', 'error');
        }
      } catch (e) {
        QB.showToast('Error applying promo', 'error');
      }
      btn.innerHTML = 'Apply';
      btn.disabled = false;
    }

    function quickApplyPromo(code) {
      document.getElementById('promo-input').value = code;
      applyPromo();
    }

    function selectDelivery(type) {
      const fees = { standard:2.99, express:5.99, scheduled:2.49 };
      deliveryFee = fees[type];
      document.querySelectorAll('[id^="delivery-opt-"]').forEach(el => {
        el.style.borderColor = 'var(--border)';
        el.style.background = '';
      });
      const opt = document.getElementById('delivery-opt-' + type);
      if (opt) { opt.style.borderColor = 'var(--primary)'; opt.style.background = 'rgba(229,62,62,0.03)'; }
      updateSummary();
    }

    function selectAddress(type, addr) {
      document.getElementById('selected-address').innerHTML = \`
        <div style="display:flex;align-items:flex-start;gap:10px;">
          <i class="fas fa-map-marker-alt" style="color:var(--primary);margin-top:2px;"></i>
          <div><p style="font-weight:600;font-size:0.875rem;color:var(--text);">\${type}</p><p style="font-size:0.82rem;color:var(--text-muted);">\${addr}</p></div>
        </div>
      \`;
      closeModal('address-modal');
      QB.showToast('Address updated!', 'success');
    }

    function clearCartConfirm() { openModal('clear-modal'); }
    function clearCartAction() {
      QB.clearCart();
      closeModal('clear-modal');
      renderCartItems();
      QB.showToast('Cart cleared', 'info');
    }

    function proceedToCheckout() {
      if (QB.cartCount === 0) { QB.showToast('Your cart is empty!', 'error'); return; }
      const notes = document.getElementById('cooking-notes').value;
      if (notes) localStorage.setItem('qb_notes', notes);
      localStorage.setItem('qb_delivery_fee', deliveryFee);
      localStorage.setItem('qb_promo_discount', promoDiscount);
      window.location.href = '/checkout';
    }

    // Init
    document.addEventListener('DOMContentLoaded', () => {
      renderCartItems();
      selectDelivery('standard');
      // Mobile layout
      if (window.innerWidth <= 768) {
        document.getElementById('cart-content').style.gridTemplateColumns = '1fr';
      }
    });
    window.addEventListener('resize', () => {
      const cc = document.getElementById('cart-content');
      if (cc) cc.style.gridTemplateColumns = window.innerWidth <= 768 ? '1fr' : '1fr 380px';
    });
  </script>
  `

  return pageShell('Your Cart', content, 'cart', scripts)
}
