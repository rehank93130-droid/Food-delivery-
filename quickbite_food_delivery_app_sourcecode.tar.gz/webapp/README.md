# 🍔 QuickBite - Food Delivery App

A modern, professional, and fully functional Food Delivery App built with **Hono + TypeScript + Cloudflare Pages** architecture.

## 🌐 Live App URL
**https://3000-ifvgflaks5gk01jf2e522-d0b9e1e2.sandbox.novita.ai**

## ✅ Completed Features

### 👤 User Authentication
- Email/Password login & signup
- Phone + OTP verification (demo: use 123456)
- Social login (Google, Facebook, Apple)
- Password strength meter
- Forgot password flow
- JWT-based auth simulation

### 🏠 Home Page
- Hero banner with dynamic greetings
- Stats bar (200+ restaurants, 5000+ items)
- Promotional banners with copyable promo codes
- Food category carousel (10 categories)
- Restaurant grid with filter chips (Veg, Rating, Fast, Free, Budget, Offers)
- Sort by relevance, rating, time, fee
- Recently ordered items
- App download CTA

### 🔍 Search Page
- Live search with instant results
- 8 filter chips
- Sort by relevance/rating/distance/fee
- Grid/list view toggle
- Trending searches
- No results state with clear all

### 🍽️ Restaurant Detail Page
- Full restaurant info (rating, reviews, delivery time, fee)
- Sticky category navigation tabs
- Menu search
- Veg/non-veg indicators
- Bestseller badges
- Add to cart with quantity controls
- Sticky cart sidebar (desktop)
- Rating summary with star breakdown
- Write review with rating input
- Chat/call restaurant

### 🛒 Cart Page
- Full cart management (add/remove/update qty)
- Animated item removal
- Delivery address selector
- 3 delivery options (Standard/Express/Scheduled)
- Cooking instructions text area
- **Promo code system** (try: QUICKBITE10, FIRST50, SAVE20, WELCOME30)
- Live price breakdown (subtotal, delivery, tax, discount)
- Savings badge
- Trust badges

### 💳 Checkout Page
- Step progress indicator
- UPI payment (Google Pay, PhonePe, Paytm, custom UPI ID)
- Credit/Debit card with real-time formatting & card type detection
- Cash on Delivery
- Order success modal with order ID
- Save card option

### 📍 Order Tracking
- Real-time animated progress tracker (5 steps)
- Auto-advancing simulation
- Animated progress bar
- Estimated arrival countdown
- Delivery agent profile with ratings
- Call/Chat with rider
- Map visualization with animated rider
- Quick reply chat system
- Order items summary
- Cancel order option

### 📋 Order History
- Active orders banner with live status
- Past orders with items preview
- Reorder functionality
- Rate & review past orders
- Order status badges
- Help/support buttons

### 👤 User Profile
- Edit profile (name, email, phone, DOB, gender)
- Avatar upload
- Saved addresses (add/edit/delete)
- Payment methods (cards, UPI)
- Notification preferences with toggles
- App preferences (food type, language, dark mode)
- Security (change password, 2FA setup, delete account)
- Sign out

### 👑 Admin Panel
- **Dashboard**: Revenue chart, order status donut chart, stats cards, recent orders, top restaurants
- **Orders Management**: Full table with status update dropdown, search/filter
- **Restaurants**: Table with toggle active/inactive, add/edit/delete
- **Menu Items**: Card grid with availability toggle
- **Users**: Table with block/unblock
- **Promo Codes**: Usage progress bars, enable/disable
- **Reviews & Settings**: Placeholder sections

### 🌙 Dark Mode
- Full dark/light theme toggle
- CSS custom properties theming
- Persisted in localStorage

### 📱 Mobile-First Responsive
- Bottom navigation bar on mobile
- Responsive grid layouts
- Mobile-optimized touch targets
- Collapsible sidebars

### ✨ Extra Features
- Toast notification system (success/error/info)
- Location picker modal
- Smooth CSS animations (fadeIn, slideUp, bounceIn, stagger)
- Skeleton loading indicators
- Cart persistence with localStorage
- User session persistence

## 🗂️ Project Structure
```
webapp/
├── src/
│   ├── index.tsx          # Main Hono app + API routes + mock data
│   ├── renderer.tsx       # JSX renderer
│   └── pages/
│       ├── layout.ts      # Shared CSS, header, global JS, pageShell
│       ├── auth.ts        # Login + Signup pages
│       ├── home.ts        # Home page with listings
│       ├── search.ts      # Search with filters
│       ├── restaurant.ts  # Restaurant detail + menu
│       ├── cart.ts        # Shopping cart
│       ├── checkout.ts    # Payment page
│       ├── tracking.ts    # Order tracking
│       ├── orders.ts      # Order history
│       ├── profile.ts     # User profile
│       └── admin.ts       # Admin panel
├── public/                # Static assets
├── dist/                  # Build output
├── ecosystem.config.cjs   # PM2 config
├── wrangler.jsonc         # Cloudflare config
├── vite.config.ts         # Vite + Hono build config
└── package.json
```

## 🔗 Navigation URLs
| Page | URL |
|------|-----|
| Home | `/` |
| Login | `/login` |
| Signup | `/signup` |
| Search | `/search?q=burger` |
| Restaurant | `/restaurant/1` through `/restaurant/6` |
| Cart | `/cart` |
| Checkout | `/checkout` |
| Order Tracking | `/tracking` |
| Order History | `/orders` |
| User Profile | `/profile` |
| Admin Panel | `/admin` |

## 🎁 Demo Promo Codes
| Code | Discount |
|------|----------|
| `QUICKBITE10` | 10% off |
| `FIRST50` | 50% off |
| `SAVE20` | 20% off |
| `WELCOME30` | 30% off |

## 🚀 Tech Stack
- **Framework**: Hono v4 (TypeScript)
- **Runtime**: Cloudflare Workers / Pages
- **Build Tool**: Vite + @hono/vite-build
- **Dev Server**: PM2 + Wrangler
- **Styling**: Custom CSS with CSS Variables (no framework)
- **Icons**: Font Awesome 6
- **Fonts**: Inter (Google Fonts)
- **Storage**: localStorage (browser-side state)
- **No external database required** (mock data in-memory)

## 🛠️ Development
```bash
# Install dependencies
npm install

# Build
npm run build

# Start dev server
pm2 start ecosystem.config.cjs

# Stop server
pm2 stop quickbite
```

## 📅 Last Updated
February 28, 2026
