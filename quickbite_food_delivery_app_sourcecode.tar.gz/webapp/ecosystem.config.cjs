// ecosystem.config.cjs - PM2 configuration for QuickBite
module.exports = {
  apps: [
    {
      name: 'quickbite',
      script: 'npx',
      args: 'wrangler pages dev dist --ip 0.0.0.0 --port 3000',
      env: {
        NODE_ENV: 'development',
        PORT: 3000
      },
      watch: false,
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_restarts: 5,
    }
  ]
}
